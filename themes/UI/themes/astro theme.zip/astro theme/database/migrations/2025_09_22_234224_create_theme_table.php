<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('theme')) {
            Schema::create('theme', function (Blueprint $table) {
                $table->id();
                $table->string('key')->nullable()->unique();
                $table->text('value')->nullable();
                
                // Theme specific columns
                $table->text('background_image')->nullable();
                $table->string('background_source', 20)->nullable();
                
                // Logo columns
                $table->text('small_logo')->nullable();
                $table->text('large_logo')->nullable();
                
                // Quick links columns
                $table->boolean('quick_links_enabled')->default(true);
                $table->json('quick_links')->nullable();
                
                // NEW: Nest background columns
                $table->json('nest_backgrounds')->nullable();
                $table->decimal('nest_gradient_opacity', 3, 2)->default(0.15);
                
                // NEW: Navigation links columns
                $table->json('navigation_links')->nullable();
                
                // NEW: Announcements system column
                $table->boolean('announcements_enabled')->default(true); // Removed ->after()
                
                $table->unsignedBigInteger('updated_by')->nullable();
                $table->timestamps();
            });
        } else {
            // Add missing columns if table exists but columns are missing
            $columnsToAdd = [
                'small_logo' => function (Blueprint $table) {
                    $table->text('small_logo')->nullable()->after('background_source');
                },
                'large_logo' => function (Blueprint $table) {
                    $table->text('large_logo')->nullable()->after('small_logo');
                },
                'quick_links_enabled' => function (Blueprint $table) {
                    $table->boolean('quick_links_enabled')->default(true)->after('large_logo');
                },
                'quick_links' => function (Blueprint $table) {
                    $table->json('quick_links')->nullable()->after('quick_links_enabled');
                },
                'nest_backgrounds' => function (Blueprint $table) {
                    $table->json('nest_backgrounds')->nullable()->after('quick_links');
                },
                'nest_gradient_opacity' => function (Blueprint $table) {
                    $table->decimal('nest_gradient_opacity', 3, 2)->default(0.15)->after('nest_backgrounds');
                },
                'navigation_links' => function (Blueprint $table) {
                    $table->json('navigation_links')->nullable()->after('nest_gradient_opacity');
                },
                // NEW: Announcements system column
                'announcements_enabled' => function (Blueprint $table) {
                    $table->boolean('announcements_enabled')->default(true)->after('navigation_links');
                }
            ];
            
            foreach ($columnsToAdd as $column => $callback) {
                if (!Schema::hasColumn('theme', $column)) {
                    Schema::table('theme', $callback);
                }
            }
        }

        // Create announcements table if it doesn't exist
        if (!Schema::hasTable('announcements')) {
            Schema::create('announcements', function (Blueprint $table) {
                $table->id();
                $table->string('title');
                $table->text('content');
                $table->enum('type', ['info', 'warning', 'success', 'error', 'primary'])->default('info');
                $table->boolean('is_active')->default(true);
                $table->boolean('is_dismissible')->default(true);
                $table->timestamp('starts_at')->nullable();
                $table->timestamp('ends_at')->nullable();
                $table->json('target_nodes')->nullable();
                $table->json('target_users')->nullable();
                $table->enum('target_scope', ['all', 'nodes', 'users'])->default('all');
                $table->integer('display_order')->default(0);
                $table->unsignedBigInteger('created_by');
                $table->timestamps();
                
                // Indexes for better performance
                $table->index(['is_active', 'starts_at', 'ends_at']);
                $table->index('display_order');
                $table->index('created_by');
            });
        }

        // Ensure there is at least one row in theme table
        try {
            if (DB::table('theme')->count() === 0) {
                DB::table('theme')->insert([
                    'key' => 'theme.background_image',
                    'value' => null,
                    'background_image' => null,
                    'background_source' => 'default',
                    'small_logo' => null,
                    'large_logo' => null,
                    'quick_links_enabled' => true,
                    'quick_links' => json_encode([
                        [
                            'title' => 'Terms of Service',
                            'icon' => 'file-contract',
                            'url' => 'https://example.com/terms-of-services',
                            'target' => '_blank',
                            'rel' => 'noopener noreferrer'
                        ],
                        [
                            'title' => 'Billing Panel',
                            'icon' => 'credit-card',
                            'url' => 'https://billing.example.com/',
                            'target' => '_blank',
                            'rel' => 'noopener noreferrer'
                        ],
                        [
                            'title' => 'Discord',
                            'icon' => 'comments',
                            'url' => 'https://github.com/HAPPY-NODE',
                            'target' => '_blank',
                            'rel' => 'noopener noreferrer'
                        ],
                        [
                            'title' => 'Privacy Policy',
                            'icon' => 'shield-alt',
                            'url' => 'https://example.com/privacy-policy',
                            'target' => '_blank',
                            'rel' => 'noopener noreferrer'
                        ]
                    ]),
                    'nest_backgrounds' => json_encode([
                        // Default nest backgrounds can be set here
                        1 => 'https://wallpapers.com/images/hd/minecraft-shaders-2560-x-1390-n0hzf5cc2eli3lfq.jpg',
                        5 => '/images/eggs/terraria.png'
                    ]),
                    'nest_gradient_opacity' => 0.15,
                    'navigation_links' => json_encode([
                        // Default navigation structure
                        [
                            'id' => 'dashboard',
                            'type' => 'link',
                            'name' => 'Dashboard',
                            'icon' => 'home',
                            'link' => '/',
                            'target' => '_self',
                            'enabled' => true,
                            'order' => 0,
                            'category' => 'main'
                        ],
                        [
                            'id' => 'admin',
                            'type' => 'link',
                            'name' => 'Admin',
                            'icon' => 'cogs',
                            'link' => '/admin',
                            'target' => '_blank',
                            'enabled' => true,
                            'order' => 1,
                            'category' => 'main',
                            'requires_root' => true
                        ],
                        [
                            'id' => 'account',
                            'type' => 'link',
                            'name' => 'Account',
                            'icon' => 'user',
                            'link' => '/account',
                            'target' => '_self',
                            'enabled' => true,
                            'order' => 2,
                            'category' => 'main'
                        ],
                        // Server navigation links
                        [
                            'id' => 'server-console',
                            'type' => 'link',
                            'name' => 'Console',
                            'icon' => 'terminal',
                            'link' => '/server/{id}',
                            'target' => '_self',
                            'enabled' => true,
                            'order' => 0,
                            'category' => 'server'
                        ],
                        [
                            'id' => 'server-files',
                            'type' => 'link',
                            'name' => 'Files',
                            'icon' => 'folder',
                            'link' => '/server/{id}/files',
                            'target' => '_self',
                            'enabled' => true,
                            'order' => 1,
                            'category' => 'server'
                        ],
                        [
                            'id' => 'server-databases',
                            'type' => 'link',
                            'name' => 'Databases',
                            'icon' => 'database',
                            'link' => '/server/{id}/databases',
                            'target' => '_self',
                            'enabled' => true,
                            'order' => 2,
                            'category' => 'server'
                        ],
                        [
                            'id' => 'server-schedules',
                            'type' => 'link',
                            'name' => 'Schedules',
                            'icon' => 'clock',
                            'link' => '/server/{id}/schedules',
                            'target' => '_self',
                            'enabled' => true,
                            'order' => 3,
                            'category' => 'server'
                        ],
                        [
                            'id' => 'server-users',
                            'type' => 'link',
                            'name' => 'Users',
                            'icon' => 'users',
                            'link' => '/server/{id}/users',
                            'target' => '_self',
                            'enabled' => true,
                            'order' => 4,
                            'category' => 'server'
                        ],
                        [
                            'id' => 'server-backups',
                            'type' => 'link',
                            'name' => 'Backups',
                            'icon' => 'archive',
                            'link' => '/server/{id}/backups',
                            'target' => '_self',
                            'enabled' => true,
                            'order' => 5,
                            'category' => 'server'
                        ],
                        [
                            'id' => 'server-network',
                            'type' => 'link',
                            'name' => 'Network',
                            'icon' => 'network-wired',
                            'link' => '/server/{id}/network',
                            'target' => '_self',
                            'enabled' => true,
                            'order' => 6,
                            'category' => 'server'
                        ],
                        [
                            'id' => 'server-settings',
                            'type' => 'link',
                            'name' => 'Settings',
                            'icon' => 'cog',
                            'link' => '/server/{id}/settings',
                            'target' => '_self',
                            'enabled' => true,
                            'order' => 7,
                            'category' => 'server'
                        ],
                        [
                            'id' => 'server-startup',
                            'type' => 'link',
                            'name' => 'Startup',
                            'icon' => 'sliders-h',
                            'link' => '/server/{id}/startup',
                            'target' => '_self',
                            'enabled' => true,
                            'order' => 8,
                            'category' => 'server'
                        ],
                        [
                            'id' => 'server-activity',
                            'type' => 'link',
                            'name' => 'Activity',
                            'icon' => 'chart-bar',
                            'link' => '/server/{id}/activity',
                            'target' => '_self',
                            'enabled' => true,
                            'order' => 9,
                            'category' => 'server'
                        ]
                    ]),
                    'announcements_enabled' => true,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            } else {
                // Update existing row to include announcements_enabled if it doesn't exist
                $existing = DB::table('theme')->first();
                if ($existing && !isset($existing->announcements_enabled)) {
                    DB::table('theme')->update([
                        'announcements_enabled' => true,
                        'updated_at' => now(),
                    ]);
                }
            }
        } catch (\Throwable $e) {
            // Ignore errors
        }

        // Add sample announcement if announcements table is empty
        try {
            if (DB::table('announcements')->count() === 0) {
                DB::table('announcements')->insert([
                    [
                        'title' => 'Welcome to Our Panel!',
                        'content' => 'We are excited to have you here. Explore all the features and let us know if you need any help.',
                        'type' => 'info',
                        'is_active' => true,
                        'is_dismissible' => true,
                        'starts_at' => null,
                        'ends_at' => null,
                        'target_nodes' => null,
                        'target_users' => null,
                        'target_scope' => 'all',
                        'display_order' => 0,
                        'created_by' => 1, // Assuming admin user with ID 1 exists
                        'created_at' => now(),
                        'updated_at' => now(),
                    ]
                ]);
            }
        } catch (\Throwable $e) {
            // Ignore errors - sample data is optional
        }
    }

    public function down(): void
    {
        // Drop announcements table if it exists
        Schema::dropIfExists('announcements');
        
        // Drop theme table if it exists
        Schema::dropIfExists('theme');
    }
};