import React, { useEffect, useState } from 'react';
import { Server } from '@/api/server/getServer';
import getServers from '@/api/getServers';
import ServerRow from '@/components/dashboard/ServerRow';
import Spinner from '@/components/elements/Spinner';
import PageContentBlock from '@/components/elements/PageContentBlock';
import useFlash from '@/plugins/useFlash';
import { useStoreState } from 'easy-peasy';
import { usePersistedState } from '@/plugins/usePersistedState';
import Switch from '@/components/elements/Switch';
import tw from 'twin.macro';
import styled from 'styled-components/macro';
import useSWR from 'swr';
import { PaginatedResult } from '@/api/http';
import Pagination from '@/components/elements/Pagination';
import { useLocation, Link } from 'react-router-dom';
import { 
  FaTh, 
  FaList, 
  FaServer, 
  FaUsers, 
  FaFileContract, 
  FaCreditCard, 
  FaComments, 
  FaShieldAlt,
  FaPlus,
  FaSearch,
  FaFilter,
  FaSync,
  FaRocket,
  FaNetworkWired,
  FaChartLine,
  FaExternalLinkAlt
} from 'react-icons/fa';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { 
  faFileContract as faFileContractSolid, 
  faCreditCard as faCreditCardSolid,
  faComments as faCommentsSolid,
  faShieldAlt as faShieldAltSolid
} from '@fortawesome/free-solid-svg-icons';
import http from '@/api/http';

const DashboardHeader = styled.div`
  ${tw`mb-8 text-center`}
  
  h1 {
    ${tw`text-3xl md:text-4xl font-bold text-gray-100 mb-3`}
    background: linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
  }
  
  p {
    ${tw`text-gray-400 text-lg`}
  }
`;

const ServerGrid = styled.div`
  ${tw`grid gap-6 mt-8`}
  grid-template-columns: repeat(auto-fill, minmax(420px, 1fr));
  
  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`;

const ServerList = styled.div`
  ${tw`flex flex-col gap-4 mt-8`}
`;

const ControlsContainer = styled.div`
  ${tw`flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6 p-6 rounded-2xl backdrop-blur-lg`}
  background: rgba(30, 30, 46, 0.7);
  border: 1px solid rgba(255, 255, 255, 0.1);
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
`;

const LeftControls = styled.div`
  ${tw`flex flex-col sm:flex-row gap-4 flex-1`}
`;

const RightControls = styled.div`
  ${tw`flex items-center gap-4`}
`;

const ViewToggle = styled.div`
  ${tw`flex items-center gap-2 p-1 rounded-xl backdrop-blur-sm`}
  background: rgba(15, 23, 42, 0.6);
  border: 1px solid rgba(255, 255, 255, 0.1);
`;

const ToggleButton = styled.button<{ $active: boolean }>`
  ${tw`relative p-3 rounded-lg transition-all duration-200 flex items-center justify-center`}
  width: 44px;
  height: 44px;
  background: ${props => props.$active ? 'rgba(59, 130, 246, 0.2)' : 'transparent'};
  color: ${props => props.$active ? '#3b82f6' : '#6b7280'};
  border: ${props => props.$active ? '1px solid rgba(59, 130, 246, 0.3)' : '1px solid transparent'};
  
  &:hover {
    background: ${props => props.$active ? 'rgba(59, 130, 246, 0.3)' : 'rgba(255, 255, 255, 0.05)'};
    color: ${props => props.$active ? '#3b82f6' : '#9ca3af'};
    transform: translateY(-1px);
  }
  
  &::after {
    content: '';
    position: absolute;
    bottom: -1px;
    left: 50%;
    transform: translateX(-50%) scaleX(${props => props.$active ? 1 : 0});
    width: 20px;
    height: 2px;
    background: #3b82f6;
    border-radius: 2px;
    transition: transform 0.2s ease;
  }
`;

const AdminToggleContainer = styled.div`
  ${tw`flex items-center gap-3 px-4 py-3 rounded-xl backdrop-blur-sm transition-all duration-300`}
  background: rgba(15, 23, 42, 0.6);
  border: 1px solid rgba(255, 255, 255, 0.1);
  
  &:hover {
    border-color: rgba(59, 130, 246, 0.3);
    transform: translateY(-1px);
  }
  
  span {
    ${tw`text-sm font-medium text-gray-300`}
  }
  
  .admin-icon {
    ${tw`text-blue-400`}
  }
  
  .user-icon {
    ${tw`text-blue-400`}
  }
`;

const StatsGrid = styled.div`
  ${tw`grid grid-cols-1 md:grid-cols-4 gap-4 mb-8`}
`;

const StatsCard = styled.div`
  ${tw`p-6 rounded-2xl backdrop-blur-lg transition-all duration-300`}
  background: rgba(30, 30, 46, 0.7);
  border: 1px solid rgba(255, 255, 255, 0.1);
  
  &:hover {
    border-color: rgba(59, 130, 246, 0.3);
    transform: translateY(-2px);
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
  }
  
  h3 {
    ${tw`text-lg font-semibold text-gray-300 mb-2`}
  }
  
  .stat-value {
    ${tw`text-2xl font-bold text-gray-100`}
  }
  
  .stat-label {
    ${tw`text-gray-500 text-sm`}
  }
  
  .stat-icon {
    ${tw`text-2xl mb-3 opacity-70`}
  }
`;

// Compact Quick Actions Section
const QuickActionsSection = styled.div`
  ${tw`mb-6 rounded-xl backdrop-blur-lg overflow-hidden`}
  background: rgba(30, 30, 46, 0.7);
  border: 1px solid rgba(255, 255, 255, 0.1);
`;

const QuickActionsHeader = styled.div`
  ${tw`flex items-center justify-between p-4 border-b border-gray-700`}
`;

const QuickActionsTitle = styled.h3`
  ${tw`text-sm font-semibold text-gray-100 flex items-center gap-2`}
  
  .icon {
    ${tw`text-blue-400`}
  }
`;

const QuickActionsGrid = styled.div`
  ${tw`grid grid-cols-2 md:grid-cols-4 gap-2 p-4`}
  
  @media (max-width: 640px) {
    ${tw`grid-cols-2 gap-3`}
  }
`;

const QuickActionButton = styled.a`
  ${tw`flex items-center gap-3 p-3 rounded-lg text-gray-300 transition-all duration-200 cursor-pointer`}
  background: rgba(15, 23, 42, 0.6);
  border: 1px solid rgba(255, 255, 255, 0.1);
  text-decoration: none;
  
  &:hover {
    ${tw`text-white`};
    background: rgba(59, 130, 246, 0.15);
    border-color: rgba(59, 130, 246, 0.3);
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(59, 130, 246, 0.15);
    
    .external-icon {
      opacity: 1;
      transform: translateX(2px);
    }
  }
  
  .action-icon {
    ${tw`text-base transition-all duration-200`}
  }
  
  .action-content {
    ${tw`flex-1 min-w-0`}
  }
  
  .action-title {
    ${tw`font-medium text-gray-100 text-sm truncate`}
  }
  
  .action-desc {
    ${tw`text-gray-400 text-xs truncate`}
  }
  
  .external-icon {
    ${tw`text-gray-500 text-xs transition-all duration-200 opacity-0`}
  }
`;

const ActionButton = styled.button`
  ${tw`flex items-center gap-2 px-3 py-2 rounded-lg transition-all duration-200 font-medium text-sm`}
  background: rgba(59, 130, 246, 0.1);
  border: 1px solid rgba(59, 130, 246, 0.2);
  color: #3b82f6;
  
  &:hover {
    background: rgba(59, 130, 246, 0.2);
    border-color: rgba(59, 130, 246, 0.4);
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(59, 130, 246, 0.2);
  }
  
  &:disabled {
    ${tw`opacity-50 cursor-not-allowed`}
    transform: none;
  }
`;

const SearchContainer = styled.div`
  ${tw`relative flex-1 max-w-md`}
`;

const SearchInput = styled.input`
  ${tw`w-full pl-10 pr-4 py-3 rounded-xl backdrop-blur-sm transition-all duration-200`}
  background: rgba(15, 23, 42, 0.6);
  border: 1px solid rgba(255, 255, 255, 0.1);
  color: white;
  
  &:focus {
    outline: none;
    border-color: rgba(59, 130, 246, 0.4);
    box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.1);
  }
  
  &::placeholder {
    color: #6b7280;
  }
`;

const SearchIcon = styled.div`
  ${tw`absolute left-3 top-[35%] transform -translate-y-1/2 text-gray-400`}
`;

const EmptyState = styled.div`
  ${tw`text-center py-16 px-6 rounded-2xl backdrop-blur-lg mt-8`}
  background: rgba(30, 30, 46, 0.7);
  border: 1px solid rgba(255, 255, 255, 0.1);
  
  h3 {
    ${tw`text-xl font-semibold text-gray-300 mb-3`}
  }
  
  p {
    ${tw`text-gray-500 mb-6`}
  }
`;

const CreateServerButton = styled(Link)`
  ${tw`inline-flex items-center gap-2 px-6 py-3 rounded-xl transition-all duration-200 font-medium`}
  background: linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%);
  color: white;
  text-decoration: none;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(59, 130, 246, 0.3);
  }
`;

const RefreshButton = styled.button<{ $rotating: boolean }>`
  ${tw`p-3 rounded-xl transition-all duration-200`}
  background: rgba(15, 23, 42, 0.6);
  border: 1px solid rgba(255, 255, 255, 0.1);
  color: #6b7280;
  
  &:hover {
    background: rgba(59, 130, 246, 0.1);
    border-color: rgba(59, 130, 246, 0.3);
    color: #3b82f6;
    transform: translateY(-1px);
  }
  
  svg {
    transition: transform 0.5s ease;
    transform: ${props => props.$rotating ? 'rotate(180deg)' : 'rotate(0)'};
  }
`;

// Quick Actions interface
interface QuickAction {
  title: string;
  icon: any;
  url: string;
  target: string;
  rel: string;
  description?: string;
}

interface ThemeSettings {
  remoteQuickLinksEnabled: boolean;
  quickActions: QuickAction[];
}

// Default quick actions
const defaultQuickActions: QuickAction[] = [
  {
    title: 'Terms of Service',
    icon: faFileContractSolid,
    url: 'https://example.com/terms-of-services',
    target: '_blank',
    rel: 'noopener noreferrer',
    description: 'Read our terms and conditions'
  },
  {
    title: 'Billing Panel',
    icon: faCreditCardSolid,
    url: 'https://billing.example.com/',
    target: '_blank',
    rel: 'noopener noreferrer',
    description: 'Manage your billing and payments'
  },
  {
    title: 'Discord',
    icon: faCommentsSolid,
    url: 'https://github.com/HAPPY-NODE',
    target: '_blank',
    rel: 'noopener noreferrer',
    description: 'Join our community Discord'
  },
  {
    title: 'Privacy Policy',
    icon: faShieldAltSolid,
    url: 'https://example.com/privacy-policy',
    target: '_blank',
    rel: 'noopener noreferrer',
    description: 'Review our privacy policy'
  }
];

// Helper to load theme settings from localStorage
const loadThemeSettings = (): ThemeSettings | null => {
  try {
    const saved = localStorage.getItem('theme-settings');
    return saved ? JSON.parse(saved) : null;
  } catch (error) {
    console.warn('Failed to load theme settings:', error);
    return null;
  }
};

export default () => {
    const { search } = useLocation();
    const defaultPage = Number(new URLSearchParams(search).get('page') || '1');

    const [page, setPage] = useState(!isNaN(defaultPage) && defaultPage > 0 ? defaultPage : 1);
    const [searchQuery, setSearchQuery] = useState('');
    const [isRefreshing, setIsRefreshing] = useState(false);
    const { clearFlashes, clearAndAddHttpError } = useFlash();
    const uuid = useStoreState((state) => state.user.data!.uuid);
    const user = useStoreState((state) => state.user.data!);
    const rootAdmin = useStoreState((state) => state.user.data!.rootAdmin);
    const [showOnlyAdmin, setShowOnlyAdmin] = usePersistedState(`${uuid}:show_all_servers`, false);
    const [viewMode, setViewMode] = usePersistedState<'grid' | 'list'>(`${uuid}:server_view_mode`, 'grid');
    
    // Theme settings state
    const [themeSettings, setThemeSettings] = useState<ThemeSettings>(() => {
      const saved = loadThemeSettings();
      return saved || {
        remoteQuickLinksEnabled: true,
        quickActions: defaultQuickActions
      };
    });

    const { data: servers, error, mutate } = useSWR<PaginatedResult<Server>>(
        ['/api/client/servers', showOnlyAdmin && rootAdmin, page],
        () => getServers({ page, type: showOnlyAdmin && rootAdmin ? 'admin' : undefined })
    );

    // Filter servers based on search query
    const filteredServers = servers?.items.filter(server => 
        server.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        server.description?.toLowerCase().includes(searchQuery.toLowerCase())
    ) || [];

    useEffect(() => {
        if (!servers) return;
        if (servers.pagination.currentPage > 1 && !servers.items.length) {
            setPage(1);
        }
    }, [servers?.pagination.currentPage]);

    useEffect(() => {
        window.history.replaceState(null, document.title, `/${page <= 1 ? '' : `?page=${page}`}`);
    }, [page]);

    useEffect(() => {
        if (error) clearAndAddHttpError({ key: 'dashboard', error });
        if (!error) clearFlashes('dashboard');
    }, [error]);

    // Fetch theme settings on component mount
    useEffect(() => {
        const fetchThemeSettings = async () => {
            try {
                const response = await http.get('/api/client/theme/api');
                const data = response.data || {};
                
                setThemeSettings(prev => ({
                    ...prev,
                    remoteQuickLinksEnabled: data.quick_links_enabled !== undefined ? data.quick_links_enabled : prev.remoteQuickLinksEnabled,
                    quickActions: data.quick_links && data.quick_links.length > 0 
                        ? data.quick_links.map((link: any) => ({
                            title: link.title,
                            icon: mapIconToFa(link.icon),
                            url: link.url,
                            target: link.target || '_blank',
                            rel: link.rel || 'noopener noreferrer',
                            description: link.description || ''
                        }))
                        : prev.quickActions
                }));
            } catch (error) {
                console.warn('Failed to fetch theme settings:', error);
            }
        };

        fetchThemeSettings();
    }, []);

    const handleRefresh = async () => {
        setIsRefreshing(true);
        await mutate();
        setTimeout(() => setIsRefreshing(false), 500);
    };

    const mapIconToFa = (iconName: string) => {
        const iconMap: { [key: string]: any } = {
            'file-contract': faFileContractSolid,
            'credit-card': faCreditCardSolid,
            'comments': faCommentsSolid,
            'shield-alt': faShieldAltSolid,
        };
        return iconMap[iconName] || faFileContractSolid;
    };

    // Calculate server statistics
    const totalServers = servers?.pagination.total || 0;
    const onlineServers = servers?.items.filter(s => s.status === 'running').length || 0;
    const suspendedServers = servers?.items.filter(s => s.status === 'suspended').length || 0;

    return (
        <PageContentBlock title={'Dashboard'} showFlashKey={'dashboard'}>

            {/* Quick Actions Section */}
            {themeSettings.remoteQuickLinksEnabled && themeSettings.quickActions.length > 0 && (
                <QuickActionsSection>
                    <QuickActionsGrid>
                        {themeSettings.quickActions.map((action, index) => (
                            <QuickActionButton
                                key={index}
                                href={action.url}
                                target={action.target}
                                rel={action.rel}
                                title={action.title}
                            >
                                <FontAwesomeIcon icon={action.icon} className="action-icon" />
                                <div className="action-content">
                                    <div className="action-title">{action.title}</div>
                                    {action.description && (
                                        <div className="action-desc">{action.description}</div>
                                    )}
                                </div>
                                <FaExternalLinkAlt className="external-icon" />
                            </QuickActionButton>
                        ))}
                    </QuickActionsGrid>
                </QuickActionsSection>
            )}

            <ControlsContainer>
                <LeftControls>
                    {rootAdmin && (
                        <AdminToggleContainer>
                            {showOnlyAdmin ? (
                                <FaUsers className="admin-icon" />
                            ) : (
                                <FaServer className="user-icon" />
                            )}
                            <span>{showOnlyAdmin ? "Viewing All Servers" : 'Viewing Your Servers'}</span>
                            <Switch
                                name={'show_all_servers'}
                                defaultChecked={showOnlyAdmin}
                                onChange={() => setShowOnlyAdmin((s) => !s)}
                            />
                        </AdminToggleContainer>
                    )}
                    
                    <SearchContainer>
                        <SearchIcon>
                            <FaSearch />
                        </SearchIcon>
                        <SearchInput
                            type="text"
                            placeholder="Search servers..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                        />
                    </SearchContainer>
                </LeftControls>
                
                <RightControls>
                    <RefreshButton 
                        onClick={handleRefresh} 
                        $rotating={isRefreshing}
                        title="Refresh servers"
                    >
                        <FaSync />
                    </RefreshButton>
                    
                    <ViewToggle>
                        <ToggleButton
                            $active={viewMode === 'grid'}
                            onClick={() => setViewMode('grid')}
                            aria-label="Grid view"
                        >
                            <FaTh />
                        </ToggleButton>
                        <ToggleButton
                            $active={viewMode === 'list'}
                            onClick={() => setViewMode('list')}
                            aria-label="List view"
                        >
                            <FaList />
                        </ToggleButton>
                    </ViewToggle>
                </RightControls>
            </ControlsContainer>

            {!servers ? (
                <div className="flex justify-center items-center py-12">
                    <Spinner size={'large'} />
                </div>
            ) : (
                <Pagination data={servers} onPageSelect={setPage}>
                    {({ items }) => {
                        const displayItems = searchQuery ? filteredServers : items;
                        
                        return displayItems.length > 0 ? (
                            viewMode === 'grid' ? (
                                <ServerGrid>
                                    {displayItems.map((server, index) => (
                                        <ServerRow 
                                            key={server.uuid} 
                                            server={server} 
                                            viewMode={viewMode}
                                            index={index}
                                        />
                                    ))}
                                </ServerGrid>
                            ) : (
                                <ServerList>
                                    {displayItems.map((server, index) => (
                                        <ServerRow 
                                            key={server.uuid} 
                                            server={server} 
                                            viewMode={viewMode}
                                            index={index}
                                        />
                                    ))}
                                </ServerList>
                            )
                        ) : (
                            <EmptyState>
                                <h3>
                                    {searchQuery ? 'No servers found' : 'No servers available'}
                                </h3>
                                <p>
                                    {searchQuery 
                                        ? `No servers match "${searchQuery}". Try a different search term.`
                                        : showOnlyAdmin
                                            ? "There are no other servers to display."
                                            : "There are no servers associated with your account."
                                    }
                                </p>
                                {searchQuery && (
                                    <ActionButton onClick={() => setSearchQuery('')}>
                                        Clear Search
                                    </ActionButton>
                                )}
                            </EmptyState>
                        );
                    }}
                </Pagination>
            )}
        </PageContentBlock>
    );
};