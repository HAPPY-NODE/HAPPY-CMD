import http from '@/api/http';

export default async function getServerNestInfo(uuid: string): Promise<{ nest_id: number; egg_id: number }> {
    const { data } = await http.get(`/api/client/servers/${uuid}/nest`);
    return data.attributes;
}
