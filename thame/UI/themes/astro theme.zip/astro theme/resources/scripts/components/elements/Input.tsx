import styled, { css } from 'styled-components/macro';
import tw from 'twin.macro';

export interface Props {
    isLight?: boolean;
    hasError?: boolean;
}

const light = css<Props>`
    ${tw`bg-white text-neutral-800`};
    border: 1px solid rgba(209, 213, 219, 0.8);
    
    &:focus {
        border-color: rgba(99, 102, 241, 0.8);
        box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.2);
    }

    &:disabled {
        ${tw`bg-neutral-100`};
        border-color: rgba(209, 213, 219, 0.6);
    }
`;

const checkboxStyle = css<Props>`
    ${tw`cursor-pointer appearance-none inline-block align-middle select-none flex-shrink-0 w-4 h-4 text-primary-400 rounded-md`};
    background: rgba(31, 34, 53, 0.7);
    border: 1px solid rgba(255, 255, 255, 0.1);
    color-adjust: exact;
    background-origin: border-box;
    transition: all 0.2s ease;

    &:checked {
        background-color: currentColor;
        background-image: url("data:image/svg+xml,%3csvg viewBox='0 0 16 16' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M5.707 7.293a1 1 0 0 0-1.414 1.414l2 2a1 1 0 0 0 1.414 0l4-4a1 1 0 0 0-1.414-1.414L7 8.586 5.707 7.293z'/%3e%3c/svg%3e");
        background-size: 100% 100%;
        background-position: center;
        background-repeat: no-repeat;
        border-color: currentColor;
    }

    &:focus {
        outline: none;
        box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.3);
    }
`;

const inputStyle = css<Props>`
    // Reset to normal styling.
    resize: none;
    ${tw`appearance-none outline-none w-full min-w-0`};
    ${tw`p-3 rounded-lg text-sm transition-all duration-200`};
    background: rgba(31, 34, 53, 0.7);
    backdrop-filter: blur(5px);
    border: 1px solid rgba(255, 255, 255, 0.1);
    box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.2),
                0 1px 0 rgba(255, 255, 255, 0.05);

    & + .input-help {
        ${tw`mt-2 text-xs`};
        ${(props) => (props.hasError ? tw`text-red-300` : tw`text-neutral-300`)};
    }

    &:required,
    &:invalid {
        ${tw`shadow-none`};
    }

    &:not(:disabled):not(:read-only):focus {
        border-color: rgba(99, 102, 241, 0.6);
        box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.2),
                    inset 0 1px 3px rgba(0, 0, 0, 0.2);
        ${(props) => props.hasError && tw`border-red-400 ring-red-300`};
    }

    &:disabled {
        opacity: 0.6;
        cursor: not-allowed;
    }

    ${(props) => props.isLight && light};
    ${(props) => props.hasError && css`
        border-color: rgba(239, 68, 68, 0.6);
        box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.2),
                    0 1px 0 rgba(255, 255, 255, 0.05);
    `};
`;

const Input = styled.input<Props>`
    &:not([type='checkbox']):not([type='radio']) {
        ${inputStyle};
    }

    &[type='checkbox'],
    &[type='radio'] {
        ${checkboxStyle};

        &[type='radio'] {
            ${tw`rounded-full`};
        }
    }
`;

const Textarea = styled.textarea<Props>`
    ${inputStyle}
`;

export { Textarea };
export default Input;