import { encodePathSegments } from '@/helpers';
import { differenceInHours, format, formatDistanceToNow } from 'date-fns';
import React, { memo } from 'react';
import { FileObject } from '@/api/server/files/loadDirectory';
import FileDropdownMenu from '@/components/server/files/FileDropdownMenu';
import { ServerContext } from '@/state/server';
import { NavLink, useRouteMatch } from 'react-router-dom';
import isEqual from 'react-fast-compare';
import SelectFileCheckbox from '@/components/server/files/SelectFileCheckbox';
import { usePermissions } from '@/plugins/usePermissions';
import { join } from 'path';
import { bytesToString } from '@/lib/formatters';
import { FaFile, FaFolder as FaFolderIcon, FaArchive } from 'react-icons/fa';

const Clickable: React.FC<{ file: FileObject }> = memo(({ file, children }) => {
    const [canRead] = usePermissions(['file.read']);
    const [canReadContents] = usePermissions(['file.read-content']);
    const directory = ServerContext.useStoreState((state) => state.files.directory);

    const match = useRouteMatch();

    return (file.isFile && (!file.isEditable() || !canReadContents)) || (!file.isFile && !canRead) ? (
        <div className="flex-1 flex items-center min-w-0">{children}</div>
    ) : (
        <NavLink
            className="flex-1 flex items-center min-w-0 hover:text-indigo-300 transition-colors duration-200"
            to={`${match.url}${file.isFile ? '/edit' : ''}#${encodePathSegments(join(directory, file.name))}`}
        >
            {children}
        </NavLink>
    );
}, isEqual);

const FileObjectRow = ({ file }: { file: FileObject }) => (
    <div
        className="bg-[#17192b] grid grid-cols-12 gap-4 p-4 items-center hover:bg-gray-800/40 transition-colors duration-200 group"
        key={file.name}
        onContextMenu={(e) => {
            e.preventDefault();
            window.dispatchEvent(new CustomEvent(`pterodactyl:files:ctx:${file.key}`, { detail: e.clientX }));
        }}
    >
        {/* Checkbox */}
        <div className="col-span-1 flex items-center justify-center">
            <SelectFileCheckbox name={file.name} />
        </div>

        {/* Name with dropdown integrated */}
        <div className="col-span-5 flex items-center min-w-0">
            <Clickable file={file}>
                <div className="flex-none text-neutral-300 mr-3 text-lg">
                    {file.isFile ? (
                        file.isArchiveType() ? (
                            <FaArchive className="text-blue-400" />
                        ) : (
                            <FaFile className={file.isSymlink ? 'text-purple-400' : 'text-indigo-400'} />
                        )
                    ) : (
                        <FaFolderIcon className="text-yellow-400" />
                    )}
                </div>
                <div className="flex-1 truncate text-gray-200">{file.name}</div>
            </Clickable>
            
            {/* Dropdown positioned to the right of the filename */}
            <div className="ml-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                <FileDropdownMenu file={file} />
            </div>
        </div>

        {/* Type */}
        <div className="col-span-2 flex items-center justify-center text-sm text-gray-400 hidden md:flex">
            {file.isFile ? (file.isArchiveType() ? 'Archive' : 'File') : 'Folder'}
        </div>

        {/* Size */}
        <div className="col-span-2 flex items-center justify-end text-sm text-gray-400 hidden sm:flex">
            {file.isFile ? bytesToString(file.size) : ''}
        </div>

        {/* Modified */}
        <div
            className="col-span-2 flex items-center justify-end text-sm text-gray-400 hidden md:flex"
            title={file.modifiedAt.toString()}
        >
            {Math.abs(differenceInHours(file.modifiedAt, new Date())) > 48
                ? format(file.modifiedAt, 'MMM do, yyyy')
                : formatDistanceToNow(file.modifiedAt, { addSuffix: true })}
        </div>
    </div>
);

export default memo(FileObjectRow, (prevProps, nextProps) => {
    /* eslint-disable @typescript-eslint/no-unused-vars */
    const { isArchiveType, isEditable, ...prevFile } = prevProps.file;
    const { isArchiveType: nextIsArchiveType, isEditable: nextIsEditable, ...nextFile } = nextProps.file;
    /* eslint-enable @typescript-eslint/no-unused-vars */

    return isEqual(prevFile, nextFile);
});