import React, { useState } from 'react';
import { Subuser } from '@/state/server/subusers';
import { RiEditLine, RiLockLine, RiLockUnlockLine, RiUserLine, RiShieldKeyholeLine } from 'react-icons/ri';
import RemoveSubuserButton from '@/components/server/users/RemoveSubuserButton';
import EditSubuserModal from '@/components/server/users/EditSubuserModal';
import Can from '@/components/elements/Can';
import { useStoreState } from 'easy-peasy';
import tw, { styled } from 'twin.macro';

const UserCard = styled.div`
  ${tw`rounded-xl overflow-hidden mb-4`};
  background: rgba(31, 34, 53, 0.7);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.1);
  box-shadow: 
    0 10px 30px rgba(0, 0, 0, 0.2),
    0 0 0 1px rgba(255, 255, 255, 0.05),
    inset 0 0 20px rgba(255, 255, 255, 0.03);
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 
      0 15px 35px rgba(0, 0, 0, 0.3),
      0 0 0 1px rgba(99, 102, 241, 0.1),
      inset 0 0 20px rgba(255, 255, 255, 0.05);
  }
`;

const UserHeader = styled.div`
  ${tw`flex items-center justify-between px-5 py-3 border-b`};
  background: linear-gradient(90deg, rgba(99, 102, 241, 0.15) 0%, rgba(79, 70, 229, 0.1) 100%);
  border-color: rgba(255, 255, 255, 0.07);
`;

const UserBody = styled.div`
  ${tw`p-5`};
  background: rgba(31, 34, 53, 0.3);
`;

const UserInfo = styled.div`
  ${tw`grid grid-cols-1 md:grid-cols-3 gap-4 mb-4`};
`;

const InfoBox = styled.div`
  ${tw`p-3 rounded-lg`};
  background: rgba(31, 34, 53, 0.5);
  border: 1px solid rgba(255, 255, 255, 0.07);
`;

const Label = styled.label`
  ${tw`uppercase text-xs mt-1 text-neutral-400 block px-1 select-none transition-colors duration-150`}
`;

const ActionBar = styled.div`
  ${tw`flex justify-end space-x-3`};
`;

const Avatar = styled.div`
  ${tw`w-12 h-12 rounded-full bg-indigo-500/20 border-2 border-indigo-500/30 overflow-hidden flex items-center justify-center`};
  
  img {
    ${tw`w-full h-full object-cover`};
  }
`;

const StatusBadge = styled.span<{ enabled: boolean }>`
  ${tw`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium`};
  ${props => props.enabled 
    ? tw`bg-green-500/20 text-green-400` 
    : tw`bg-red-500/20 text-red-400`
  };
`;

const PermissionBadge = styled.span`
  ${tw`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-500/20 text-blue-400`};
`;

interface Props {
    subuser: Subuser;
}

export default ({ subuser }: Props) => {
    const uuid = useStoreState((state) => state.user!.data!.uuid);
    const [visible, setVisible] = useState(false);

    const permissionCount = subuser.permissions.filter((permission) => permission !== 'websocket.connect').length;

    return (
        <UserCard>
            <EditSubuserModal subuser={subuser} visible={visible} onModalDismissed={() => setVisible(false)} />
            <UserHeader>
                <div className="flex items-center">
                    <Avatar>
                        {subuser.image ? (
                            <img src={`${subuser.image}?s=400`} alt={subuser.email} />
                        ) : (
                            <RiUserLine className="text-indigo-300 text-xl" />
                        )}
                    </Avatar>
                    <div className="ml-3">
                        <p className="text-sm font-medium text-neutral-200">{subuser.email}</p>
                        <p className="text-xs text-neutral-400">Subuser</p>
                    </div>
                </div>
                {subuser.uuid !== uuid && (
                    <div className="flex items-center space-x-2">
                        <Can action={'user.update'}>
                            <button
                                type={'button'}
                                aria-label={'Edit subuser'}
                                className="p-2 text-neutral-400 hover:text-indigo-300 transition-colors duration-200"
                                onClick={() => setVisible(true)}
                            >
                                <RiEditLine />
                            </button>
                        </Can>
                        <Can action={'user.delete'}>
                            <RemoveSubuserButton subuser={subuser} />
                        </Can>
                    </div>
                )}
            </UserHeader>
            
            <UserBody>
                <UserInfo>
                    <InfoBox>
                        <div className="flex items-center justify-between">
                            <span className="text-sm font-medium text-neutral-300">2FA Status</span>
                            <StatusBadge enabled={subuser.twoFactorEnabled}>
                                {subuser.twoFactorEnabled ? (
                                    <RiLockLine className="mr-1 text-xs" />
                                ) : (
                                    <RiLockUnlockLine className="mr-1 text-xs" />
                                )}
                                {subuser.twoFactorEnabled ? 'Enabled' : 'Disabled'}
                            </StatusBadge>
                        </div>
                        <Label>Security</Label>
                    </InfoBox>
                    
                    <InfoBox>
                        <div className="flex items-center justify-between">
                            <span className="text-sm font-medium text-neutral-300">Permissions</span>
                            <PermissionBadge>
                                <RiShieldKeyholeLine className="mr-1 text-xs" />
                                {permissionCount}
                            </PermissionBadge>
                        </div>
                        <Label>Access Level</Label>
                    </InfoBox>
                    
                    <InfoBox>
                        <span className="text-sm font-medium text-neutral-300">User ID</span>
                        <p className="text-xs font-mono text-neutral-400 mt-1 truncate" title={subuser.uuid}>
                            {subuser.uuid}
                        </p>
                        <Label>Unique Identifier</Label>
                    </InfoBox>
                </UserInfo>
                
                <ActionBar>
                    {subuser.uuid === uuid && (
                        <span className="text-xs text-neutral-400 italic">
                            This is your account
                        </span>
                    )}
                </ActionBar>
            </UserBody>
        </UserCard>
    );
};