import styled from 'styled-components/macro';
import tw, { theme } from 'twin.macro';

const SubNavigation = styled.div`
    ${tw`w-full overflow-x-auto rounded-xl`};
    background: rgba(31, 34, 53, 0.8);
    backdrop-filter: blur(10px);
    border-bottom: 1px solid rgba(255, 255, 255, 0.07);
    box-shadow: 
        0 4px 15px rgba(0, 0, 0, 0.1),
        0 0 0 1px rgba(255, 255, 255, 0.03),
        inset 0 0 20px rgba(255, 255, 255, 0.02);

    & > div {
        ${tw`flex items-center text-sm mx-auto px-4`};
        max-width: 1200px;
        height: 50px;

        & > a,
        & > div {
            ${tw`inline-flex items-center py-3 px-4 text-neutral-300 no-underline whitespace-nowrap transition-all duration-200 relative`};
            font-weight: 500;
            
            &:not(:first-of-type) {
                ${tw`ml-1`};
            }

            &:hover {
                ${tw`text-neutral-100`};
                background: rgba(99, 102, 241, 0.1);
                border-radius: 6px;
            }

            &:active,
            &.active {
                ${tw`text-neutral-100`};
                background: rgba(99, 102, 241, 0.15);
                border-radius: 6px;
            }

            /* Add subtle glow effect for active items */
            &.active {
                box-shadow: 0 0 15px rgba(99, 102, 241, 0.2);
            }

            /* Add transition for smooth effects */
            transition: all 0.2s ease-in-out;

            /* Better spacing for icons if used */
            & > svg {
                ${tw`mr-2 w-4 h-4`};
            }
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            ${tw`px-2`};
            
            & > a,
            & > div {
                ${tw`px-3 text-xs`};
                
                & > svg {
                    ${tw`mr-1`};
                }
            }
        }
    }

    /* Custom scrollbar for the navigation */
    &::-webkit-scrollbar {
        height: 4px;
    }

    &::-webkit-scrollbar-track {
        background: rgba(31, 34, 53, 0.3);
        border-radius: 2px;
    }

    &::-webkit-scrollbar-thumb {
        background: rgba(99, 102, 241, 0.4);
        border-radius: 2px;
    }

    &::-webkit-scrollbar-thumb:hover {
        background: rgba(99, 102, 241, 0.6);
    }
`;

export default SubNavigation;