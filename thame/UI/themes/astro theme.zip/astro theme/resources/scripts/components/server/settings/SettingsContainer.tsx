import React from 'react';
import TitledGreyBox from '@/components/elements/TitledGreyBox';
import { ServerContext } from '@/state/server';
import { useStoreState } from 'easy-peasy';
import RenameServerBox from '@/components/server/settings/RenameServerBox';
import FlashMessageRender from '@/components/FlashMessageRender';
import Can from '@/components/elements/Can';
import ReinstallServerBox from '@/components/server/settings/ReinstallServerBox';
import tw, { styled } from 'twin.macro';
import Input from '@/components/elements/Input';
import Label from '@/components/elements/Label';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import isEqual from 'react-fast-compare';
import CopyOnClick from '@/components/elements/CopyOnClick';
import { ip } from '@/lib/formatters';
import { Button } from '@/components/elements/button/index';
import { RiServerLine, RiShieldKeyholeLine, RiInformationLine, RiTerminalBoxLine } from 'react-icons/ri';

const SettingsGrid = styled.div`
    ${tw`grid grid-cols-1 lg:grid-cols-3 gap-6`};
`;

const MainContent = styled.div`
    ${tw`lg:col-span-2 space-y-6`};
`;

const Sidebar = styled.div`
    ${tw`space-y-6`};
`;

const InfoCard = styled.div`
    ${tw`p-5 rounded-xl`};
    background: rgba(31, 34, 53, 0.7);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.1);
    box-shadow: 
        0 10px 30px rgba(0, 0, 0, 0.2),
        0 0 0 1px rgba(255, 255, 255, 0.05),
        inset 0 0 20px rgba(255, 255, 255, 0.03);
`;

const InfoGrid = styled.div`
    ${tw`grid grid-cols-1 md:grid-cols-2 gap-4 mt-4`};
`;

const InfoItem = styled.div`
    ${tw`p-3 rounded-lg`};
    background: rgba(31, 34, 53, 0.5);
    border: 1px solid rgba(255, 255, 255, 0.07);
`;

const InfoLabel = styled.span`
    ${tw`text-sm font-medium text-neutral-300`};
`;

const InfoValue = styled.code`
    ${tw`block mt-1 text-sm font-mono text-neutral-200 truncate`};
    background: none;
    padding: 0;
`;

const QuickAction = styled.button`
    ${tw`w-full p-4 rounded-xl text-left transition-all duration-200`};
    background: rgba(31, 34, 53, 0.7);
    border: 1px solid rgba(255, 255, 255, 0.1);
    
    &:hover {
        background: rgba(99, 102, 241, 0.15);
        border-color: rgba(99, 102, 241, 0.3);
        transform: translateY(-2px);
    }
`;

const ActionIcon = styled.div`
    ${tw`w-10 h-10 rounded-full flex items-center justify-center mb-3`};
    background: rgba(99, 102, 241, 0.15);
    color: rgba(99, 102, 241, 0.8);
`;

export default () => {
    const username = useStoreState((state) => state.user.data!.username);
    const id = ServerContext.useStoreState((state) => state.server.data!.id);
    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const node = ServerContext.useStoreState((state) => state.server.data!.node);
    const sftp = ServerContext.useStoreState((state) => state.server.data!.sftpDetails, isEqual);
    const server = ServerContext.useStoreState((state) => state.server.data!);

    return (
        <ServerContentBlock title={'Settings'}>
            <div className="flex items-center mb-6">
                <RiServerLine className="text-indigo-400 mr-3 text-2xl" />
                <h1 className="text-2xl font-bold">Server Settings</h1>
            </div>
            
            <FlashMessageRender byKey={'settings'} css={tw`mb-6`} />
            
            <SettingsGrid>
                <MainContent>
                    <Can action={'file.sftp'}>
                        <TitledGreyBox title={'SFTP Details'} icon={RiShieldKeyholeLine}>
                            <div className="space-y-4">
                                <div>
                                    <Label>Server Address</Label>
                                    <CopyOnClick text={`sftp://${ip(sftp.ip)}:${sftp.port}`}>
                                        <Input 
                                            type={'text'} 
                                            value={`sftp://${ip(sftp.ip)}:${sftp.port}`} 
                                            readOnly 
                                            className="bg-neutral-800/50"
                                        />
                                    </CopyOnClick>
                                </div>
                                <div>
                                    <Label>Username</Label>
                                    <CopyOnClick text={`${username}.${id}`}>
                                        <Input 
                                            type={'text'} 
                                            value={`${username}.${id}`} 
                                            readOnly 
                                            className="bg-neutral-800/50"
                                        />
                                    </CopyOnClick>
                                </div>
                                <div className="flex items-center justify-between p-4 rounded-lg bg-blue-500/10 border border-blue-500/20">
                                    <div className="flex-1">
                                        <p className="text-sm text-blue-300">
                                            Your SFTP password is the same as the password you use to access this panel.
                                        </p>
                                    </div>
                                    <div className="ml-4">
                                        <a href={`sftp://${username}.${id}@${ip(sftp.ip)}:${sftp.port}`}>
                                            <Button variant={Button.Variants.Secondary}>
                                                Launch SFTP
                                            </Button>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </TitledGreyBox>
                    </Can>
                    
                    <TitledGreyBox title={'Server Information'} icon={RiInformationLine}>
                        <InfoGrid>
                            <InfoItem>
                                <InfoLabel>Server ID</InfoLabel>
                                <CopyOnClick text={uuid}>
                                    <InfoValue>{uuid}</InfoValue>
                                </CopyOnClick>
                            </InfoItem>
                            <InfoItem>
                                <InfoLabel>Allocation Limit</InfoLabel>
                                <InfoValue>{server.featureLimits.allocations}</InfoValue>
                            </InfoItem>
                            <InfoItem>
                                <InfoLabel>Backup Limit</InfoLabel>
                                <InfoValue>{server.featureLimits.backups}</InfoValue>
                            </InfoItem>
                            <InfoItem>
                                <InfoLabel>Database Limit</InfoLabel>
                                <InfoValue>{server.featureLimits.databases}</InfoValue>
                            </InfoItem>
                        </InfoGrid>
                    </TitledGreyBox>
                </MainContent>
                
                <Sidebar>
                    <Can action={'settings.rename'}>
                        <RenameServerBox />
                    </Can>
                    
                    <Can action={'settings.reinstall'}>
                        <ReinstallServerBox />
                    </Can>
                </Sidebar>
            </SettingsGrid>
        </ServerContentBlock>
    );
};