import React, { useEffect, useMemo, useState, useRef } from 'react';
import { ServerContext } from '@/state/server';
import { SocketEvent, SocketRequest } from '@/components/server/events';
import useWebsocketEvent from '@/plugins/useWebsocketEvent';
import StatBlock from '@/components/server/console/StatBlock';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { 
    faClock, 
    faMemory, 
    faMicrochip, 
    faHdd, 
    faCloudDownloadAlt, 
    faCloudUploadAlt, 
    faUser, 
    faCaretDown,
    faNetworkWired,
    faServer
} from '@fortawesome/free-solid-svg-icons';
import { bytesToString, ip, mbToBytes } from '@/lib/formatters';
import classNames from 'classnames';
import tw from 'twin.macro';
import styled from 'styled-components/macro';
import UptimeDuration from '@/components/server/UptimeDuration';
import { motion, AnimatePresence } from 'framer-motion';

const StatsContainer = styled.div`
    ${tw`grid grid-cols-1 gap-4`}
`;

const StatsGrid = styled.div`
    ${tw`grid grid-cols-1 gap-4`}
`;

const ResourceUsage = styled.div<{ $percentage: number; $color: string }>`
    ${tw`flex items-center justify-between text-sm mt-3`}
    
    .usage-text {
        ${tw`font-semibold text-xs`}
        color: ${props => props.$color};
        text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
    }
    
    .usage-bar-container {
        ${tw`h-2 rounded-full bg-gray-800 flex-1 ml-3 overflow-hidden relative`}
        box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.3);
        
        .usage-bar {
            ${tw`absolute left-0 top-0 h-full rounded-full transition-all duration-1000 ease-out`}
            width: ${props => Math.max(props.$percentage, 2)}%;
            background: ${props => props.$color};
            box-shadow: 
                0 0 8px ${props => props.$color}80,
                inset 0 1px 0 rgba(255, 255, 255, 0.2);
            
            &::after {
                content: '';
                ${tw`absolute right-0 top-0 w-1 h-full opacity-70`}
                background: linear-gradient(90deg, transparent 0%, rgba(255, 255, 255, 0.4) 100%);
            }
        }
    }
`;

const PlayerDropdown = styled(motion.div)`
    ${tw`absolute z-50 mt-3 w-full bg-gradient-to-b from-[#1a1a2e] to-[#16213e] rounded-2xl shadow-2xl py-2 max-h-60 overflow-y-auto border border-gray-700 backdrop-blur-xl`};
    transform-origin: top;
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
    border: 1px solid rgba(255, 255, 255, 0.1);
`;

const PlayerItem = styled.div`
    ${tw`px-4 py-3 text-sm text-gray-200 transition-all duration-300 border-b border-gray-700 last:border-b-0 hover:bg-[#2d2d44] hover:text-white cursor-default flex items-center gap-3 hover:pl-5`};
    
    .player-icon {
        ${tw`w-2 h-2 rounded-full bg-green-400 flex-shrink-0 transition-all duration-300`}
        box-shadow: 0 0 12px #10b981;
    }
    
    &:hover .player-icon {
        transform: scale(1.3);
        box-shadow: 0 0 16px #10b981;
    }
`;

const PlayerHeader = styled.div`
    ${tw`flex items-center justify-between w-full cursor-pointer`}
    
    .player-count {
        ${tw`flex items-center gap-2`}
        
        .online {
            ${tw`font-bold text-white text-xl`}
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }
        
        .max {
            ${tw`text-neutral-400 text-sm`}
        }
        
        .chevron {
            ${tw`text-neutral-400 text-xs transition-transform duration-300 ml-1`}
        }
    }
`;

const Limit = styled.div<{ $isCritical?: boolean }>`
    ${tw`flex items-baseline justify-between w-full transition-all duration-300`}
    
    .main-value {
        ${tw`text-white text-lg font-bold transition-all duration-300`}
        ${props => props.$isCritical && tw`text-red-400`}
        text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
    }
    
    .limit-value {
        ${tw`text-neutral-400 text-sm ml-2 transition-all duration-300`}
        ${props => props.$isCritical && tw`text-red-300`}
    }
`;

const StatusIndicator = styled.div<{ $status: string }>`
    ${tw`absolute -top-1 -right-1 w-3 h-3 rounded-full border-2 border-[#1a1a2e] z-20`}
    background: ${props => 
        props.$status === 'running' ? '#10b981' :
        props.$status === 'stopped' ? '#ef4444' :
        props.$status === 'starting' ? '#f59e0b' : '#6b7280'};
    box-shadow: 0 0 10px ${props => 
        props.$status === 'running' ? '#10b981' :
        props.$status === 'stopped' ? '#ef4444' :
        props.$status === 'starting' ? '#f59e0b' : '#6b7280'}80;
`;

const getResourceColor = (value: number, max: number | null) => {
    const delta = !max ? 0 : value / max;
    if (delta > 0.9) return '#ef4444';
    if (delta > 0.8) return '#f59e0b';
    return '#10b981';
};

const getStatColor = (value: number, max: number | null) => {
    const delta = !max ? 0 : value / max;
    if (delta > 0.9) return '#ef4444';
    if (delta > 0.8) return '#f59e0b';
    return '#3b82f6';
};

const ServerDetailsBlock = ({ className }: { className?: string }) => {
    const [stats, setStats] = useState({ memory: 0, cpu: 0, disk: 0, uptime: 0, tx: 0, rx: 0 });
    const [players, setPlayers] = useState<any>(null);
    const [showPlayerList, setShowPlayerList] = useState(false);
    const dropdownRef = useRef<HTMLDivElement>(null);

    const status = ServerContext.useStoreState((state) => state.status.value);
    const connected = ServerContext.useStoreState((state) => state.socket.connected);
    const instance = ServerContext.useStoreState((state) => state.socket.instance);
    const limits = ServerContext.useStoreState((state) => state.server.data!.limits);
    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);

    const textLimits = useMemo(() => ({
        cpu: limits?.cpu ? `${limits.cpu}%` : null,
        memory: limits?.memory ? bytesToString(mbToBytes(limits.memory)) : null,
        disk: limits?.disk ? bytesToString(mbToBytes(limits.disk)) : null,
    }), [limits]);

    // Calculate resource percentages
    const resourcePercentages = useMemo(() => ({
        memory: limits?.memory ? (stats.memory / mbToBytes(limits.memory)) * 100 : 0,
        disk: limits?.disk ? (stats.disk / mbToBytes(limits.disk)) * 100 : 0,
        cpu: limits?.cpu ? (stats.cpu / limits.cpu) * 100 : 0,
    }), [stats, limits]);

    // Check if resources are critical
    const isResourceCritical = useMemo(() => ({
        cpu: resourcePercentages.cpu > 90,
        memory: resourcePercentages.memory > 90,
        disk: resourcePercentages.disk > 90,
    }), [resourcePercentages]);

    useEffect(() => {
        if (!connected || !instance) return;
        instance.send(SocketRequest.SEND_STATS);
    }, [connected, instance]);

    useWebsocketEvent(SocketEvent.STATS, (data: string) => {
        try {
            const parsed = JSON.parse(data);
            setStats({
                memory: parsed.memory_bytes,
                cpu: parsed.cpu_absolute,
                disk: parsed.disk_bytes,
                tx: parsed.network.tx_bytes,
                rx: parsed.network.rx_bytes,
                uptime: parsed.uptime || 0,
            });
        } catch (_) {}
    });

    // Fetch players periodically
    useEffect(() => {
        const fetchPlayers = async () => {
            try {
                const res = await fetch(`/api/client/servers/${uuid}/players`, { headers: { Accept: 'application/json' } });
                if (!res.ok) return;
                const data = await res.json();
                setPlayers(data.players);
            } catch {}
        };
        fetchPlayers();
        const interval = setInterval(fetchPlayers, 30000);
        return () => clearInterval(interval);
    }, [uuid]);

    // Click outside dropdown
    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
                setShowPlayerList(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    return (
        <StatsContainer 
            className={classNames(className)}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: "easeOut" }}
        >
            
            <StatsGrid>
                {/* Resources - Main Focus */}
                <StatBlock 
                    icon={faMicrochip} 
                    title="CPU Usage"
                    color={getStatColor(stats.cpu, limits.cpu)}
                    copyOnClick={`${stats.cpu.toFixed(1)}%`}
                >
                    <div className="w-full">
                        <Limit $isCritical={isResourceCritical.cpu}>
                            <span className="main-value">{stats.cpu.toFixed(1)}%</span>
                            <span className="limit-value">/ {textLimits.cpu || '∞'}</span>
                        </Limit>
                        <ResourceUsage 
                            $percentage={resourcePercentages.cpu} 
                            $color={getResourceColor(stats.cpu, limits.cpu)}
                        >
                            <span className="usage-text">{resourcePercentages.cpu.toFixed(0)}% used</span>
                            <div className="usage-bar-container">
                                <div className="usage-bar" />
                            </div>
                        </ResourceUsage>
                    </div>
                </StatBlock>

                <StatBlock 
                    icon={faMemory} 
                    title="Memory Usage"
                    color={getStatColor(stats.memory/1024, limits.memory*1024)}
                    copyOnClick={bytesToString(stats.memory)}
                >
                    <div className="w-full">
                        <Limit $isCritical={isResourceCritical.memory}>
                            <span className="main-value">{bytesToString(stats.memory)}</span>
                            <span className="limit-value">/ {textLimits.memory || '∞'}</span>
                        </Limit>
                        <ResourceUsage 
                            $percentage={resourcePercentages.memory} 
                            $color={getResourceColor(stats.memory/1024, limits.memory*1024)}
                        >
                            <span className="usage-text">{resourcePercentages.memory.toFixed(0)}% used</span>
                            <div className="usage-bar-container">
                                <div className="usage-bar" />
                            </div>
                        </ResourceUsage>
                    </div>
                </StatBlock>

                <StatBlock 
                    icon={faHdd} 
                    title="Disk Usage"
                    color={getStatColor(stats.disk/1024, limits.disk*1024)}
                    copyOnClick={bytesToString(stats.disk)}
                >
                    <div className="w-full">
                        <Limit $isCritical={isResourceCritical.disk}>
                            <span className="main-value">{bytesToString(stats.disk)}</span>
                            <span className="limit-value">/ {textLimits.disk || '∞'}</span>
                        </Limit>
                        <ResourceUsage 
                            $percentage={resourcePercentages.disk} 
                            $color={getResourceColor(stats.disk/1024, limits.disk*1024)}
                        >
                            <span className="usage-text">{resourcePercentages.disk.toFixed(0)}% used</span>
                            <div className="usage-bar-container">
                                <div className="usage-bar" />
                            </div>
                        </ResourceUsage>
                    </div>
                </StatBlock>

                    {/* Players with Enhanced Dropdown */}
                    <div className="relative" ref={dropdownRef}>
                        <div 
                            className="cursor-pointer" 
                            onClick={() => players?.online > 0 && setShowPlayerList(!showPlayerList)}
                        >
                            <StatBlock 
                                icon={faUser} 
                                title="Online Players"
                                color={players?.online > 0 ? '#10b981' : undefined}
                            >
                                <PlayerHeader>
                                    <div className="player-count">
                                        <span className="online">{players?.online || 0}</span>
                                        <span className="max">/ {players?.max || 0}</span>
                                        {players?.online > 0 && (
                                            <FontAwesomeIcon 
                                                icon={faCaretDown} 
                                                className={`chevron ${showPlayerList ? 'rotate-180' : ''}`} 
                                            />
                                        )}
                                    </div>
                                </PlayerHeader>
                            </StatBlock>
                        </div>
                        
                        <AnimatePresence>
                            {showPlayerList && players?.online > 0 && (
                                <PlayerDropdown
                                    initial={{ opacity: 0, scale: 0.95, y: -10 }}
                                    animate={{ opacity: 1, scale: 1, y: 0 }}
                                    exit={{ opacity: 0, scale: 0.95, y: -10 }}
                                    transition={{ duration: 0.2 }}
                                >
                                    <div className="px-4 py-2 text-xs font-semibold text-gray-300 border-b border-gray-700 mb-1 bg-gradient-to-r from-gray-800 to-transparent">
                                        Online Players ({players.online})
                                    </div>
                                    {players.list.map((p: any) => (
                                        <PlayerItem key={p.uuid}>
                                            <div className="player-icon" />
                                            <span className="truncate font-medium">{p.name_clean}</span>
                                        </PlayerItem>
                                    ))}
                                </PlayerDropdown>
                            )}
                        </AnimatePresence>
                    </div>
            </StatsGrid>
        </StatsContainer>
    );
};

export default ServerDetailsBlock;