import React, { useState } from 'react';
import { RiInformationLine, RiCloseLine } from 'react-icons/ri';
import { Dialog } from '@/components/elements/dialog';
import { Button } from '@/components/elements/button/index';
import tw, { styled } from 'twin.macro';

const MetaButton = styled.button`
  ${tw`flex items-center px-3 py-1 rounded-lg text-xs transition-colors duration-200`};
  background: rgba(31, 34, 53, 0.5);
  border: 1px solid rgba(255, 255, 255, 0.1);
  color: rgba(255, 255, 255, 0.7);
  
  &:hover {
    background: rgba(99, 102, 241, 0.15);
    color: rgba(255, 255, 255, 0.9);
  }
`;

const MetaContent = styled.pre`
  ${tw`p-4 rounded-lg font-mono text-sm leading-relaxed overflow-x-auto whitespace-pre-wrap`};
  background: rgba(0, 0, 0, 0.3);
  border: 1px solid rgba(255, 255, 255, 0.07);
  max-height: 60vh;
`;

const MetaGrid = styled.div`
  ${tw`grid grid-cols-2 gap-4 mt-4`};
`;

const MetaItem = styled.div`
  ${tw`p-3 rounded-lg`};
  background: rgba(31, 34, 53, 0.5);
  border: 1px solid rgba(255, 255, 255, 0.07);
`;

const MetaLabel = styled.div`
  ${tw`text-xs font-medium text-neutral-300 mb-1`};
`;

const MetaValue = styled.div`
  ${tw`text-sm font-mono text-neutral-200`};
`;

export default ({ meta }: { meta: Record<string, unknown> }) => {
    const [open, setOpen] = useState(false);

    const formatMetaValue = (value: unknown): string => {
        if (value === null) return 'null';
        if (typeof value === 'object') return JSON.stringify(value, null, 2);
        return String(value);
    };

    const isSimpleObject = (obj: unknown): boolean => {
        if (typeof obj !== 'object' || obj === null) return false;
        return Object.keys(obj).every(key => 
            typeof obj[key] === 'string' || 
            typeof obj[key] === 'number' || 
            typeof obj[key] === 'boolean' ||
            obj[key] === null
        );
    };

    return (
        <>
            <Dialog open={open} onClose={() => setOpen(false)} hideCloseIcon title="Event Metadata" size="lg">
                {isSimpleObject(meta) ? (
                    <MetaGrid>
                        {Object.entries(meta).map(([key, value]) => (
                            <MetaItem key={key}>
                                <MetaLabel>{key}</MetaLabel>
                                <MetaValue>{formatMetaValue(value)}</MetaValue>
                            </MetaItem>
                        ))}
                    </MetaGrid>
                ) : (
                    <MetaContent>{JSON.stringify(meta, null, 2)}</MetaContent>
                )}
                <Dialog.Footer>
                    <Button.Text onClick={() => setOpen(false)}>Close</Button.Text>
                </Dialog.Footer>
            </Dialog>
            <MetaButton
                aria-describedby="View additional event metadata"
                onClick={() => setOpen(true)}
            >
                <RiInformationLine className="mr-1" />
                Details
            </MetaButton>
        </>
    );
};