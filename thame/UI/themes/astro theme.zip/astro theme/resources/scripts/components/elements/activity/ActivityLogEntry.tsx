import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Tooltip from '@/components/elements/tooltip/Tooltip';
import Translate from '@/components/elements/Translate';
import { format, formatDistanceToNowStrict } from 'date-fns';
import { ActivityLog } from '@definitions/user';
import ActivityLogMetaButton from '@/components/elements/activity/ActivityLogMetaButton';
import classNames from 'classnames';
import Avatar from '@/components/Avatar';
import useLocationHash from '@/plugins/useLocationHash';
import { getObjectKeys, isObject } from '@/lib/objects';
import { RiTerminalBoxLine, RiFolderOpenLine, RiUserLine, RiTimeLine, RiMapPinLine, RiInformationLine } from 'react-icons/ri';
import tw, { styled } from 'twin.macro';

const ActivityCard = styled.div`
  ${tw`p-4 rounded-xl mb-3 transition-all duration-200`};
  background: rgba(31, 34, 53, 0.7);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.1);
  box-shadow: 
    0 4px 15px rgba(0, 0, 0, 0.15), 
    0 0 0 1px rgba(255, 255, 255, 0.05),
    inset 0 0 20px rgba(255, 255, 255, 0.03);
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 
      0 8px 25px rgba(0, 0, 0, 0.25),
      0 0 0 1px rgba(99, 102, 241, 0.1),
      inset 0 0 20px rgba(255, 255, 255, 0.05);
  }
`;

const UserInfo = styled.div`
  ${tw`flex items-center`};
`;

const ActivityContent = styled.div`
  ${tw`mt-3`};
`;

const ActivityMeta = styled.div`
  ${tw`flex items-center justify-between mt-3 pt-3 border-t border-neutral-700`};
`;

const MetaItem = styled.div`
  ${tw`flex items-center text-sm`};
`;

const EventTypeBadge = styled.span<{ type: string }>`
  ${tw`px-2 py-1 rounded-full text-xs font-medium`};
  ${props => {
    if (props.type.includes('sftp')) return tw`bg-blue-500/20 text-blue-400`;
    if (props.type.includes('api')) return tw`bg-purple-500/20 text-purple-400`;
    if (props.type.includes('create')) return tw`bg-green-500/20 text-green-400`;
    if (props.type.includes('delete')) return tw`bg-red-500/20 text-red-400`;
    if (props.type.includes('update')) return tw`bg-yellow-500/20 text-yellow-400`;
    return tw`bg-neutral-500/20 text-neutral-400`;
  }};
`;

const Description = styled.p`
  ${tw`text-sm text-neutral-300 mt-2 break-words line-clamp-2`};
  
  & strong {
    ${tw`text-neutral-50 font-semibold`};
  }
`;

const IconsContainer = styled.div`
  ${tw`flex space-x-2 ml-3`};
  
  & svg {
    ${tw`w-4 h-4`};
  }
`;

interface Props {
    activity: ActivityLog;
    children?: React.ReactNode;
}

function wrapProperties(value: unknown): any {
    if (value === null || typeof value === 'string' || typeof value === 'number') {
        return `<strong>${String(value)}</strong>`;
    }

    if (isObject(value)) {
        return getObjectKeys(value).reduce((obj, key) => {
            if (key === 'count' || (typeof key === 'string' && key.endsWith('_count'))) {
                return { ...obj, [key]: value[key] };
            }
            return { ...obj, [key]: wrapProperties(value[key]) };
        }, {} as Record<string, unknown>);
    }

    if (Array.isArray(value)) {
        return value.map(wrapProperties);
    }

    return value;
}

export default ({ activity, children }: Props) => {
    const { pathTo } = useLocationHash();
    const actor = activity.relationships.actor;
    const properties = wrapProperties(activity.properties);
    const [showFullDescription, setShowFullDescription] = useState(false);

    const getEventType = (event: string) => {
        if (event.includes('sftp')) return 'SFTP';
        if (event.includes('api')) return 'API';
        if (event.includes('create')) return 'Create';
        if (event.includes('delete')) return 'Delete';
        if (event.includes('update')) return 'Update';
        if (event.includes('start')) return 'Start';
        if (event.includes('stop')) return 'Stop';
        if (event.includes('restart')) return 'Restart';
        return 'Event';
    };

    const toggleDescription = () => {
        setShowFullDescription(!showFullDescription);
    };

    return (
        <ActivityCard>
            <div className="flex items-start justify-between">
                <UserInfo>
                    <div className="flex items-center">
                        <div className="w-10 h-10 rounded-full bg-neutral-700/50 flex items-center justify-center mr-3">
                            <Avatar name={actor?.uuid || 'system'} />
                        </div>
                        <div>
                            <Tooltip placement="top" content={actor?.email || 'System User'}>
                                <span className="font-medium text-neutral-200">{actor?.username || 'System'}</span>
                            </Tooltip>
                            <div className="flex items-center mt-1">
                                <EventTypeBadge type={activity.event}>
                                    {getEventType(activity.event)}
                                </EventTypeBadge>
                                <Link
                                    to={`#${pathTo({ event: activity.event })}`}
                                    className="ml-2 text-xs text-indigo-400 hover:text-indigo-300 transition-colors"
                                >
                                    {activity.event}
                                </Link>
                            </div>
                        </div>
                    </div>
                </UserInfo>
                
                <IconsContainer>
                    {activity.isApi && (
                        <Tooltip placement="top" content="Using API Key">
                            <RiTerminalBoxLine className="text-purple-400" />
                        </Tooltip>
                    )}
                    {activity.event.startsWith('server:sftp.') && (
                        <Tooltip placement="top" content="Using SFTP">
                            <RiFolderOpenLine className="text-blue-400" />
                        </Tooltip>
                    )}
                    {children}
                </IconsContainer>
            </div>
            
            <ActivityContent>
                <Description className={showFullDescription ? '' : 'line-clamp-2'}>
                    <Translate ns={'activity'} values={properties} i18nKey={activity.event.replace(':', '.')} />
                </Description>
                
                {activity.event.length > 100 && (
                    <button 
                        onClick={toggleDescription}
                        className="text-xs text-indigo-400 hover:text-indigo-300 mt-1"
                    >
                        {showFullDescription ? 'Show less' : 'Show more'}
                    </button>
                )}
            </ActivityContent>
            
            <ActivityMeta>
                <div className="flex items-center space-x-4">
                    {activity.ip && (
                        <MetaItem>
                            <RiMapPinLine className="text-neutral-400 mr-1" />
                            <span className="text-xs text-neutral-400">{activity.ip}</span>
                        </MetaItem>
                    )}
                    <MetaItem>
                        <RiTimeLine className="text-neutral-400 mr-1" />
                        <Tooltip placement="right" content={format(activity.timestamp, 'MMM do, yyyy H:mm:ss')}>
                            <span className="text-xs text-neutral-400">
                                {formatDistanceToNowStrict(activity.timestamp, { addSuffix: true })}
                            </span>
                        </Tooltip>
                    </MetaItem>
                </div>
                
                {activity.hasAdditionalMetadata && <ActivityLogMetaButton meta={activity.properties} />}
            </ActivityMeta>
        </ActivityCard>
    );
};