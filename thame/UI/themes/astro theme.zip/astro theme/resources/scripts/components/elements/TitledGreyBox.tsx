import React, { memo } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { IconProp } from '@fortawesome/fontawesome-svg-core';
import tw, { styled } from 'twin.macro';
import isEqual from 'react-fast-compare';

interface Props {
    icon?: IconProp;
    title: string | React.ReactNode;
    className?: string;
    children: React.ReactNode;
}

const GlassCard = styled.div`
    ${tw`rounded-xl overflow-hidden`};
    background: rgba(31, 34, 53, 0.7);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.1);
    box-shadow: 
        0 10px 30px rgba(0, 0, 0, 0.2),
        0 0 0 1px rgba(255, 255, 255, 0.05),
        inset 0 0 20px rgba(255, 255, 255, 0.03);
    transition: all 0.3s ease;
    
    &:hover {
        transform: translateY(-2px);
        box-shadow: 
            0 15px 35px rgba(0, 0, 0, 0.3),
            0 0 0 1px rgba(99, 102, 241, 0.1),
            inset 0 0 20px rgba(255, 255, 255, 0.05);
    }
`;

const TitleBar = styled.div`
    ${tw`p-4 border-b`};
    background: linear-gradient(90deg, rgb(0 78 255 / 15%) 0%, rgb(0 55 255 / 10%) 100%);
    border-color: rgba(255, 255, 255, 0.07);
    
    p {
        ${tw`text-sm font-semibold tracking-wide`};
        background: linear-gradient(90deg, #EEE 0%, #CCC 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
    }
`;

const ContentArea = styled.div`
    ${tw`p-5`};
    background: rgba(31, 34, 53, 0.3);
`;

const TitledGreyBox = ({ icon, title, children, className }: Props) => (
    <GlassCard className={className}>
        <TitleBar>
            {typeof title === 'string' ? (
                <p>
                    {icon && <FontAwesomeIcon icon={icon} tw="mr-3 text-indigo-300" />}
                    {title}
                </p>
            ) : (
                title
            )}
        </TitleBar>
        <ContentArea>{children}</ContentArea>
    </GlassCard>
);

export default memo(TitledGreyBox, isEqual);