import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faFileAlt, faFileArchive, faFileImport, faFolder } from '@fortawesome/free-solid-svg-icons';
import { encodePathSegments } from '@/helpers';
import { differenceInHours, format, formatDistanceToNow } from 'date-fns';
import React, { memo } from 'react';
import { FileObject } from '@/api/server/files/loadDirectory';
import FileDropdownMenu from '@/components/server/files/FileDropdownMenu';
import { ServerContext } from '@/state/server';
import { NavLink, useRouteMatch } from 'react-router-dom';
import tw from 'twin.macro';
import isEqual from 'react-fast-compare';
import SelectFileCheckbox from '@/components/server/files/SelectFileCheckbox';
import { usePermissions } from '@/plugins/usePermissions';
import { join } from 'path';
import { bytesToString } from '@/lib/formatters';
import styles from './style.module.css';

const Clickable: React.FC<{ file: FileObject }> = memo(({ file, children }) => {
    const [canRead] = usePermissions(['file.read']);
    const [canReadContents] = usePermissions(['file.read-content']);
    const directory = ServerContext.useStoreState((state) => state.files.directory);

    const match = useRouteMatch();

    return (file.isFile && (!file.isEditable() || !canReadContents)) || (!file.isFile && !canRead) ? (
        <div className={styles.grid_item}>{children}</div>
    ) : (
        <NavLink
            className={styles.grid_item}
            to={`${match.url}${file.isFile ? '/edit' : ''}#${encodePathSegments(join(directory, file.name))}`}
        >
            {children}
        </NavLink>
    );
}, isEqual);

const FileObjectGrid = ({ file }: { file: FileObject }) => (
	<div
		className={styles.grid_item_wrapper}
		key={file.name}
		onContextMenu={(e) => {
			e.preventDefault();
			// send both coordinates so the dropdown can open at the mouse pointer
			window.dispatchEvent(new CustomEvent(`pterodactyl:files:ctx:${file.key}`, {
				detail: { clientX: e.clientX, clientY: e.clientY },
			}));
		}}
	>
        <div className={styles.grid_checkbox}>
            <SelectFileCheckbox name={file.name} />
        </div>
        <Clickable file={file}>
            <div className={styles.grid_icon}>
                {file.isFile ? (
                    <FontAwesomeIcon
                        icon={file.isSymlink ? faFileImport : file.isArchiveType() ? faFileArchive : faFileAlt}
                    />
                ) : (
                    <FontAwesomeIcon icon={faFolder} />
                )}
            </div>
            <div className={styles.grid_name}>{file.name}</div>
            {file.isFile && (
                <div className={styles.grid_size}>{bytesToString(file.size)}</div>
            )}
            <div className={styles.grid_modified} title={file.modifiedAt.toString()}>
                {Math.abs(differenceInHours(file.modifiedAt, new Date())) > 48
                    ? format(file.modifiedAt, 'MMM do, yyyy')
                    : formatDistanceToNow(file.modifiedAt, { addSuffix: true })}
            </div>
        </Clickable>
        <div className={styles.grid_menu}>
            <FileDropdownMenu file={file} />
        </div>
    </div>
);

export default memo(FileObjectGrid, (prevProps, nextProps) => {
    const { isArchiveType, isEditable, ...prevFile } = prevProps.file;
    const { isArchiveType: nextIsArchiveType, isEditable: nextIsEditable, ...nextFile } = nextProps.file;

    return isEqual(prevFile, nextFile);
});