import React from 'react';
import { MinecraftPlugin, PluginVersion } from './types';

interface PluginModalProps {
  plugin: MinecraftPlugin;
  compatibleVersion?: PluginVersion;
  versions: PluginVersion[];
  serverVersion: string;
  onInstall: (versionId: string, pluginName: string) => void;
  onClose: () => void;
}

export const PluginModal = ({
  plugin,
  compatibleVersion,
  versions,
  serverVersion,
  onInstall,
  onClose,
}: PluginModalProps) => {
  const formatNumber = (num: number): string => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
      <div className="bg-gray-700 rounded-lg w-full max-w-2xl mx-4 max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          {/* Header */}
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center space-x-4">
              {plugin.icon_url ? (
                <img
                  src={plugin.icon_url}
                  alt={plugin.title}
                  className="w-12 h-12 rounded object-cover"
                />
              ) : (
                <div className="w-12 h-12 bg-blue-600 rounded flex items-center justify-center">
                  <i className="fas fa-cube text-gray-50 text-lg"></i>
                </div>
              )}
              <div>
                <h2 className="text-xl font-bold text-gray-50">{plugin.title}</h2>
                <p className="text-gray-400">by {plugin.author}</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-50 transition-colors"
            >
              <i className="fas fa-times text-lg"></i>
            </button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 mb-4">
            <div className="bg-gray-650 rounded p-3 text-center">
              <div className="text-lg font-bold text-gray-50 mb-1">
                {formatNumber(plugin.downloads)}
              </div>
              <div className="text-gray-400 text-sm">Downloads</div>
            </div>
            <div className="bg-gray-650 rounded p-3 text-center">
              <div className="text-lg font-bold text-gray-50 mb-1">
                {new Date(plugin.updated || plugin.date_created).getFullYear()}
              </div>
              <div className="text-gray-400 text-sm">Last Updated</div>
            </div>
            <div className="bg-gray-650 rounded p-3 text-center">
              <div className="text-lg font-bold text-gray-50 mb-1">
                {versions.length}
              </div>
              <div className="text-gray-400 text-sm">Versions</div>
            </div>
          </div>

          {/* Description */}
          <div className="mb-4">
            <h3 className="text-lg font-semibold text-gray-50 mb-2">Description</h3>
            <p className="text-gray-300 leading-relaxed">
              {plugin.description || 'No description available.'}
            </p>
          </div>

          {/* Installation */}
          <div className="mb-4">
            <h3 className="text-lg font-semibold text-gray-50 mb-2">Installation</h3>
            <div className="bg-gray-650 rounded p-4 border border-gray-600">
              <div className="flex items-center justify-between mb-3">
                {compatibleVersion ? (
                  <span className="text-green-400 font-semibold">
                    ✓ Compatible with server version {serverVersion}
                  </span>
                ) : (
                  <span className="text-red-400 font-semibold">
                    ✗ No compatible version found for {serverVersion}
                  </span>
                )}
              </div>

              {compatibleVersion ? (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">Latest Compatible Version:</span>
                    <span className="text-gray-50 font-semibold">
                      {compatibleVersion.version_number}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">Release Date:</span>
                    <span className="text-gray-50">
                      {new Date(compatibleVersion.date_published).toLocaleDateString()}
                    </span>
                  </div>
                  <button
                    onClick={() => onInstall(compatibleVersion.id, plugin.slug)}
                    className="w-full py-2 bg-green-600 hover:bg-green-500 rounded font-semibold transition-colors flex items-center justify-center space-x-2 mt-3"
                  >
                    <i className="fas fa-download text-gray-50"></i>
                    <span className="text-gray-50">Install Plugin</span>
                  </button>
                </div>
              ) : (
                <p className="text-gray-400 text-sm">
                  No version of this plugin is compatible with your server version ({serverVersion}).
                </p>
              )}
            </div>
          </div>

          {/* Version List */}
          {versions.length > 0 && (
            <div>
              <h3 className="text-lg font-semibold text-gray-50 mb-2">All Versions</h3>
              <div className="bg-gray-650 rounded p-4 border border-gray-600 max-h-48 overflow-y-auto">
                <div className="space-y-2">
                  {versions.slice(0, 10).map((version) => (
                    <div
                      key={version.id}
                      className="flex items-center justify-between py-2 px-3 bg-gray-600/20 rounded"
                    >
                      <div>
                        <span className="text-gray-50 font-medium">
                          {version.version_number}
                        </span>
                        <span className="text-gray-400 text-xs ml-2">
                          {version.game_versions.join(', ')}
                        </span>
                      </div>
                      <span className="text-gray-400 text-xs">
                        {new Date(version.date_published).toLocaleDateString()}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};