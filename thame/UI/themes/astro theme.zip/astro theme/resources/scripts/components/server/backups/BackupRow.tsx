import React from 'react';
import { 
    RiArchiveLine, 
    RiMoreFill, 
    RiLockLine, 
    RiCheckboxCircleLine, 
    RiCloseCircleLine,
    RiTimeLine
} from 'react-icons/ri';
import { format, formatDistanceToNow } from 'date-fns';
import Spinner from '@/components/elements/Spinner';
import { bytesToString } from '@/lib/formatters';
import Can from '@/components/elements/Can';
import useWebsocketEvent from '@/plugins/useWebsocketEvent';
import BackupContextMenu from '@/components/server/backups/BackupContextMenu';
import tw, { styled } from 'twin.macro';
import getServerBackups from '@/api/swr/getServerBackups';
import { ServerBackup } from '@/api/server/types';
import { SocketEvent } from '@/components/server/events';

const BackupCard = styled.div<{ $isSuccessful?: boolean }>`
    ${tw`rounded-xl overflow-hidden`};
    background: rgba(31, 34, 53, 0.7);
    backdrop-filter: blur(10px);
    border: 1px solid ${props => props.$isSuccessful ? 'rgba(255, 255, 255, 0.1)' : 'rgba(239, 68, 68, 0.3)'};
    box-shadow: 
        0 10px 30px rgba(0, 0, 0, 0.2),
        0 0 0 1px rgba(255, 255, 255, 0.05),
        inset 0 0 20px rgba(255, 255, 255, 0.03);
    transition: all 0.3s ease;
    
    &:hover {
        transform: translateY(-2px);
        box-shadow: 
            0 15px 35px rgba(0, 0, 0, 0.3),
            0 0 0 1px rgba(99, 102, 241, 0.1),
            inset 0 0 20px rgba(255, 255, 255, 0.05);
    }
`;

const BackupHeader = styled.div<{ $isSuccessful?: boolean, $isLocked?: boolean }>`
    ${tw`flex items-center justify-between px-5 py-3 border-b`};
    background: ${props => {
        if (!props.$isSuccessful) return 'rgba(239, 68, 68, 0.15)';
        return props.$isLocked 
            ? 'linear-gradient(90deg, rgba(234, 179, 8, 0.15) 0%, rgba(202, 138, 4, 0.1) 100%)' 
            : 'linear-gradient(90deg, rgba(34, 197, 94, 0.15) 0%, rgba(22, 163, 74, 0.1) 100%)';
    }};
    border-color: rgba(255, 255, 255, 0.07);
`;

const BackupBody = styled.div`
    ${tw`p-5`};
    background: rgba(31, 34, 53, 0.3);
`;

const BackupInfo = styled.div`
    ${tw`grid grid-cols-1 md:grid-cols-3 gap-4 mb-4`};
`;

const InfoBox = styled.div`
    ${tw`p-3 rounded-lg`};
    background: rgba(31, 34, 53, 0.5);
    border: 1px solid rgba(255, 255, 255, 0.07);
`;

const Label = styled.label`
    ${tw`uppercase text-xs mt-1 text-neutral-400 block px-1 select-none transition-colors duration-150`}
`;

const StatusBadge = styled.span<{ $status: 'success' | 'failed' | 'pending' | 'locked' }>`
    ${tw`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium`};
    ${props => {
        switch(props.$status) {
            case 'success':
                return tw`bg-green-500/20 text-green-400`;
            case 'failed':
                return tw`bg-red-500/20 text-red-400`;
            case 'pending':
                return tw`bg-blue-500/20 text-blue-400`;
            case 'locked':
                return tw`bg-yellow-500/20 text-yellow-400`;
        }
    }};
`;

interface Props {
    backup: ServerBackup;
    className?: string;
}

export default ({ backup, className }: Props) => {
    const { mutate } = getServerBackups();

    useWebsocketEvent(`${SocketEvent.BACKUP_COMPLETED}:${backup.uuid}` as SocketEvent, (data) => {
        try {
            const parsed = JSON.parse(data);

            mutate(
                (data) => ({
                    ...data,
                    items: data.items.map((b) =>
                        b.uuid !== backup.uuid
                            ? b
                            : {
                                  ...b,
                                  isSuccessful: parsed.is_successful || true,
                                  checksum: (parsed.checksum_type || '') + ':' + (parsed.checksum || ''),
                                  bytes: parsed.file_size || 0,
                                  completedAt: new Date(),
                              }
                    ),
                }),
                false
            );
        } catch (e) {
            console.warn(e);
        }
    });

    const getStatus = () => {
        if (backup.completedAt === null) return 'pending';
        if (!backup.isSuccessful) return 'failed';
        if (backup.isLocked) return 'locked';
        return 'success';
    };

    const status = getStatus();
    const statusText = {
        pending: 'In Progress',
        failed: 'Failed',
        success: 'Successful',
        locked: 'Locked'
    }[status];

    return (
        <BackupCard $isSuccessful={backup.isSuccessful} className={className}>
            <BackupHeader $isSuccessful={backup.isSuccessful} $isLocked={backup.isLocked}>
                <div className="flex items-center">
                    {backup.completedAt !== null ? (
                        backup.isLocked ? (
                            <RiLockLine className="text-yellow-500 mr-3 text-lg" />
                        ) : backup.isSuccessful ? (
                            <RiArchiveLine className="text-green-400 mr-3 text-lg" />
                        ) : (
                            <RiCloseCircleLine className="text-red-400 mr-3 text-lg" />
                        )
                    ) : (
                        <Spinner size={'small'} className="mr-3" />
                    )}
                    <span className="font-medium text-neutral-200 truncate">
                        {backup.name}
                    </span>
                </div>
                <StatusBadge $status={status}>
                    {status === 'pending' && <RiTimeLine className="mr-1 text-xs" />}
                    {status === 'success' && <RiCheckboxCircleLine className="mr-1 text-xs" />}
                    {status === 'failed' && <RiCloseCircleLine className="mr-1 text-xs" />}
                    {status === 'locked' && <RiLockLine className="mr-1 text-xs" />}
                    {statusText}
                </StatusBadge>
            </BackupHeader>
            
            <BackupBody>
                <BackupInfo>
                    <InfoBox>
                        <span className="text-sm font-medium text-neutral-300">Size</span>
                        <div className="mt-1">
                            {backup.completedAt !== null && backup.isSuccessful ? (
                                <span className="text-sm text-neutral-200">{bytesToString(backup.bytes)}</span>
                            ) : (
                                <span className="text-sm text-neutral-400">N/A</span>
                            )}
                        </div>
                        <Label>Backup Size</Label>
                    </InfoBox>
                    
                    <InfoBox>
                        <span className="text-sm font-medium text-neutral-300">Created</span>
                        <p 
                            className="text-sm text-neutral-200 mt-1" 
                            title={format(backup.createdAt, 'ddd, MMMM do, yyyy HH:mm:ss')}
                        >
                            {formatDistanceToNow(backup.createdAt, { includeSeconds: true, addSuffix: true })}
                        </p>
                        <Label>Creation Date</Label>
                    </InfoBox>
                    
                    <InfoBox>
                        <span className="text-sm font-medium text-neutral-300">Checksum</span>
                        <p className="text-xs font-mono text-neutral-400 mt-1 truncate" title={backup.checksum}>
                            {backup.checksum || 'N/A'}
                        </p>
                        <Label>File Integrity</Label>
                    </InfoBox>
                </BackupInfo>
                
                <div className="flex justify-end">
                    <Can action={['backup.download', 'backup.restore', 'backup.delete']} matchAny>
                        {!backup.completedAt ? (
                            <div className="p-2 invisible">
                                <RiMoreFill />
                            </div>
                        ) : (
                            <BackupContextMenu backup={backup} />
                        )}
                    </Can>
                </div>
            </BackupBody>
        </BackupCard>
    );
};