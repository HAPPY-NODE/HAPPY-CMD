import React from 'react';
import FlashMessageRender from '@/components/FlashMessageRender';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';
import tw, { styled, css } from 'twin.macro';

type Props = Readonly<
    React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement> & {
        title?: string;
        borderColor?: string;
        showFlashes?: string | boolean;
        showLoadingOverlay?: boolean;
    }
>;

const GlassContainer = styled.div`
    ${tw`rounded-xl overflow-hidden`};
    background: rgba(31, 34, 53, 0.7);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.1);
    box-shadow: 
        0 10px 30px rgba(0, 0, 0, 0.2),
        0 0 0 1px rgba(255, 255, 255, 0.05),
        inset 0 0 20px rgba(255, 255, 255, 0.03);
`;

const Title = styled.h2<{ $borderColor?: string }>`
    ${tw`mb-4 px-4 text-2xl font-bold tracking-wide`};
    background: linear-gradient(90deg, #EEE 0%, #CCC 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
    padding-bottom: 8px;
    border-bottom: ${props => props.$borderColor ? `2px solid ${props.$borderColor}` : '2px solid rgba(99, 102, 241, 0.4)'};
`;

const Content = styled.div`
    ${tw`p-5 relative`};
    background: rgba(31, 34, 53, 0.3);
`;

const ContentBox = ({ title, borderColor, showFlashes, showLoadingOverlay, children, ...props }: Props) => (
    <div {...props}>
        {title && <Title $borderColor={borderColor}>{title}</Title>}
        {showFlashes && (
            <FlashMessageRender byKey={typeof showFlashes === 'string' ? showFlashes : undefined} css={tw`mb-4`} />
        )}
        <GlassContainer>
            <SpinnerOverlay visible={showLoadingOverlay || false} />
            <Content>{children}</Content>
        </GlassContainer>
    </div>
);

export default ContentBox;