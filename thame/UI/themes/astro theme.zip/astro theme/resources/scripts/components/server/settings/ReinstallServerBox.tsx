import React, { useEffect, useState } from 'react';
import { ServerContext } from '@/state/server';
import TitledGreyBox from '@/components/elements/TitledGreyBox';
import reinstallServer from '@/api/server/reinstallServer';
import { Actions, useStoreActions } from 'easy-peasy';
import { ApplicationStore } from '@/state';
import { httpErrorToHuman } from '@/api/http';
import tw from 'twin.macro';
import { Button } from '@/components/elements/button/index';
import { Dialog } from '@/components/elements/dialog';
import { RiRefreshLine, RiErrorWarningLine } from 'react-icons/ri';

export default () => {
    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const [modalVisible, setModalVisible] = useState(false);
    const { addFlash, clearFlashes } = useStoreActions((actions: Actions<ApplicationStore>) => actions.flashes);

    const reinstall = () => {
        clearFlashes('settings');
        reinstallServer(uuid)
            .then(() => {
                addFlash({
                    key: 'settings',
                    type: 'success',
                    message: 'Your server has begun the reinstallation process.',
                });
            })
            .catch((error) => {
                console.error(error);
                addFlash({ key: 'settings', type: 'error', message: httpErrorToHuman(error) });
            })
            .then(() => setModalVisible(false));
    };

    useEffect(() => {
        clearFlashes();
    }, []);

    return (
        <TitledGreyBox title={'Reinstall Server'} icon={RiRefreshLine} css={tw`relative`}>
            <Dialog.Confirm
                open={modalVisible}
                title={'Confirm Server Reinstallation'}
                confirm={'Yes, Reinstall Server'}
                onClose={() => setModalVisible(false)}
                onConfirmed={reinstall}
                icon={<RiErrorWarningLine className="text-yellow-500 text-xl" />}
            >
                <p className="mb-4">
                    Your server will be stopped and some files may be deleted or modified during this process.
                </p>
                <p className="font-medium text-red-400">
                    Please back up your data before continuing. This action cannot be undone.
                </p>
            </Dialog.Confirm>
            
            <div className="p-4 rounded-lg bg-yellow-500/10 border border-yellow-500/20 mb-4">
                <div className="flex items-start">
                    <RiErrorWarningLine className="text-yellow-500 text-lg mr-3 mt-0.5" />
                    <div>
                        <p className="text-sm text-yellow-400 font-medium">Warning</p>
                        <p className="text-sm text-yellow-400 mt-1">
                            Reinstalling will stop your server and run the initial installation script again.
                            Some files may be deleted or modified during this process.
                        </p>
                    </div>
                </div>
            </div>
            
            <div className="text-right">
                <Button.Danger variant={Button.Variants.Secondary} onClick={() => setModalVisible(true)}>
                    Reinstall Server
                </Button.Danger>
            </div>
        </TitledGreyBox>
    );
};