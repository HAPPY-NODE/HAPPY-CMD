import React, { useEffect, useState, useCallback } from 'react';
import { useActivityLogs } from '@/api/server/activity';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import { useFlashKey } from '@/plugins/useFlash';
import FlashMessageRender from '@/components/FlashMessageRender';
import Spinner from '@/components/elements/Spinner';
import ActivityLogEntry from '@/components/elements/activity/ActivityLogEntry';
import PaginationFooter from '@/components/elements/table/PaginationFooter';
import { ActivityLogFilters } from '@/api/account/activity';
import { Link } from 'react-router-dom';
import classNames from 'classnames';
import { styles as btnStyles } from '@/components/elements/button/index';
import useLocationHash from '@/plugins/useLocationHash';
import { RiHistoryLine, RiFilterLine, RiSearchLine, RiCloseCircleLine } from 'react-icons/ri';
import tw, { styled } from 'twin.macro';
import Input from '@/components/elements/Input';
import Select from '@/components/elements/Select';
import { debounce } from 'debounce';

const Header = styled.div`
  ${tw`flex items-center justify-between mb-6`};
`;

const PageTitle = styled.h1`
  ${tw`text-2xl font-bold`};
  background: linear-gradient(90deg, #EEE 0%, #CCC 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
`;

const FilterBar = styled.div`
  ${tw`flex flex-col md:flex-row items-center space-y-4 md:space-y-0 md:space-x-4 mb-6 p-4 rounded-xl`};
  background: rgba(31, 34, 53, 0.5);
  border: 1px solid rgba(255, 255, 255, 0.07);
`;

const FilterGroup = styled.div`
  ${tw`flex-1 flex flex-col md:flex-row md:items-center space-y-4 md:space-y-0 md:space-x-4`};
`;

const ActivityList = styled.div`
  ${tw`space-y-3`};
`;

const EmptyState = styled.div`
  ${tw`text-center py-12 rounded-xl`};
  background: rgba(31, 34, 53, 0.5);
  border: 1px dashed rgba(255, 255, 255, 0.1);
`;

const ClearFilterButton = styled(Link)`
  ${tw`flex items-center px-3 py-2 rounded-lg text-sm transition-colors duration-200`};
  background: rgba(239, 68, 68, 0.15);
  border: 1px solid rgba(239, 68, 68, 0.2);
  color: rgba(239, 68, 68, 0.9);
  
  &:hover {
    background: rgba(239, 68, 68, 0.25);
    color: rgba(239, 68, 68, 1);
  }
`;

const FilterTag = styled.span`
  ${tw`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium mr-2 mb-2`};
  background: rgba(99, 102, 241, 0.15);
  color: rgba(99, 102, 241, 0.9);
  border: 1px solid rgba(99, 102, 241, 0.2);
`;

export default () => {
    const { hash } = useLocationHash();
    const { clearAndAddHttpError } = useFlashKey('server:activity');
    const [filters, setFilters] = useState<ActivityLogFilters>({ 
        page: 1, 
        sorts: { timestamp: -1 },
        search: '',
        event: ''
    });
    const [localSearch, setLocalSearch] = useState('');

    const { data, isValidating, error, mutate } = useActivityLogs(filters, {
        revalidateOnMount: true,
        revalidateOnFocus: false,
    });

    useEffect(() => {
        setFilters((value) => ({ 
            ...value, 
            filters: { ip: hash.ip, event: hash.event },
            page: 1 // Reset to first page when hash changes
        }));
    }, [hash]);

    useEffect(() => {
        clearAndAddHttpError(error);
    }, [error]);

    // Debounced search function to avoid excessive API calls
    const debouncedSearch = useCallback(
        debounce((searchValue: string) => {
            setFilters((prev) => ({ 
                ...prev, 
                search: searchValue,
                page: 1 // Reset to first page when search changes
            }));
        }, 500),
        []
    );

    const handleSearchChange = (value: string) => {
        setLocalSearch(value);
        debouncedSearch(value);
    };

    const handleEventFilterChange = (event: string) => {
        setFilters((prev) => ({ 
            ...prev, 
            event: event,
            page: 1 // Reset to first page when filter changes
        }));
    };

    const clearFilters = () => {
        setFilters((value) => ({ 
            ...value, 
            filters: {}, 
            search: '', 
            event: '',
            page: 1
        }));
        setLocalSearch('');
    };

    const hasActiveFilters = filters.filters?.event || filters.filters?.ip || filters.search || filters.event;

    // Get active filter count for display
    const activeFilterCount = [
        filters.filters?.event ? 1 : 0,
        filters.filters?.ip ? 1 : 0,
        filters.search ? 1 : 0,
        filters.event ? 1 : 0
    ].reduce((a, b) => a + b, 0);

    return (
        <ServerContentBlock title={'Activity Log'}>
            <Header>
                <div className="flex items-center">
                    <RiHistoryLine className="text-indigo-400 mr-3 text-2xl" />
                    <PageTitle>Server Activity Log</PageTitle>
                </div>
            </Header>

            <FlashMessageRender byKey={'server:activity'} css={tw`mb-4`} />
            
            <FilterBar>
                <FilterGroup>
                    <div className="flex-1">
                        <Input
                            icon={RiSearchLine}
                            placeholder="Search activities..."
                            value={localSearch}
                            onChange={e => handleSearchChange(e.target.value)}
                        />
                    </div>
                    <div className="w-full md:w-48">
                        <Select 
                            value={filters.event || ''} 
                            onChange={e => handleEventFilterChange(e.target.value)}
                        >
                            <option value="">All Events</option>
                            <option value="server:console">Console Commands</option>
                            <option value="server:power">Power Actions</option>
                            <option value="server:file">File Operations</option>
                            <option value="server:sftp">SFTP Actions</option>
                            <option value="server:backup">Backup Actions</option>
                            <option value="server:schedule">Schedule Actions</option>
                            <option value="server:user">User Actions</option>
                        </Select>
                    </div>
                </FilterGroup>
                <div className="flex items-center text-sm text-neutral-400">
                    <RiFilterLine className="mr-2" />
                    {data?.pagination.total || 0} events total
                </div>
            </FilterBar>

            {/* Active filters display */}
            {hasActiveFilters && (
                <div className="mb-4 p-3 rounded-lg bg-neutral-800/50 border border-neutral-700">
                    <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium text-neutral-300">
                            Active Filters ({activeFilterCount})
                        </span>
                        <ClearFilterButton
                            to={'#'}
                            onClick={(e) => {
                                e.preventDefault();
                                clearFilters();
                            }}
                        >
                            Clear All <RiCloseCircleLine className="ml-1" />
                        </ClearFilterButton>
                    </div>
                    <div className="flex flex-wrap">
                        {filters.filters?.event && (
                            <FilterTag>
                                Event: {filters.filters.event}
                            </FilterTag>
                        )}
                        {filters.filters?.ip && (
                            <FilterTag>
                                IP: {filters.filters.ip}
                            </FilterTag>
                        )}
                        {filters.search && (
                            <FilterTag>
                                Search: {filters.search}
                            </FilterTag>
                        )}
                        {filters.event && (
                            <FilterTag>
                                Type: {filters.event}
                            </FilterTag>
                        )}
                    </div>
                </div>
            )}

            {!data && isValidating ? (
                <Spinner centered />
            ) : !data?.items.length ? (
                <EmptyState>
                    <RiHistoryLine className="text-neutral-500 text-4xl mb-4" />
                    <p className="text-center text-sm text-neutral-400">
                        {hasActiveFilters 
                            ? 'No activity logs found matching your filters.' 
                            : 'No activity logs available for this server.'
                        }
                    </p>
                    {hasActiveFilters && (
                        <button
                            onClick={clearFilters}
                            className="text-indigo-400 hover:text-indigo-300 text-sm mt-2"
                        >
                            Clear all filters
                        </button>
                    )}
                </EmptyState>
            ) : (
                <ActivityList>
                    {data?.items.map((activity) => (
                        <ActivityLogEntry key={activity.id} activity={activity} />
                    ))}
                </ActivityList>
            )}

            {data && data.pagination.totalPages > 1 && (
                <div className="mt-6">
                    <PaginationFooter
                        pagination={data.pagination}
                        onPageSelect={(page) => setFilters((value) => ({ ...value, page }))}
                    />
                </div>
            )}
        </ServerContentBlock>
    );
};