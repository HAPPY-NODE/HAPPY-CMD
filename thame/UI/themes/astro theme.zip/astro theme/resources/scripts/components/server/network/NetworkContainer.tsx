import React, { useEffect, useState } from 'react';
import Spinner from '@/components/elements/Spinner';
import { useFlashKey } from '@/plugins/useFlash';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import { ServerContext } from '@/state/server';
import AllocationRow from '@/components/server/network/AllocationRow';
import Button from '@/components/elements/Button';
import createServerAllocation from '@/api/server/network/createServerAllocation';
import tw, { styled } from 'twin.macro';
import Can from '@/components/elements/Can';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';
import getServerAllocations from '@/api/swr/getServerAllocations';
import isEqual from 'react-fast-compare';
import { useDeepCompareEffect } from '@/plugins/useDeepCompareEffect';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPlus, faNetworkWired, faInfoCircle } from '@fortawesome/free-solid-svg-icons';
import { ip } from '@/lib/formatters'; // Added missing import

const Header = styled.div`
    ${tw`flex items-center mb-6`};
    
    h1 {
        ${tw`text-2xl font-bold`};
        background: linear-gradient(90deg, #EEE 0%, #CCC 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
    }
`;

const StatsContainer = styled.div`
    ${tw`grid grid-cols-1 md:grid-cols-3 gap-4 mb-6`};
`;

const StatBox = styled.div`
    ${tw`p-4 rounded-xl`};
    background: rgba(31, 34, 53, 0.7);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.1);
    box-shadow: 
        0 4px 15px rgba(0, 0, 0, 0.15), 
        0 0 0 1px rgba(255, 255, 255, 0.05),
        inset 0 0 20px rgba(255, 255, 255, 0.03);
`;

const StatValue = styled.div`
    ${tw`text-2xl font-bold text-neutral-200`};
`;

const StatLabel = styled.div`
    ${tw`text-sm text-neutral-400 mt-1`};
`;

const ActionContainer = styled.div`
    ${tw`mt-6 flex flex-col sm:flex-row items-center justify-between p-4 rounded-xl`};
    background: rgba(31, 34, 53, 0.5);
    border: 1px solid rgba(255, 255, 255, 0.07);
`;

const InfoText = styled.p`
    ${tw`text-sm text-neutral-300 mb-4 sm:mb-0`};
`;

const NetworkContainer = () => {
    const [loading, setLoading] = useState(false);
    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const allocationLimit = ServerContext.useStoreState((state) => state.server.data!.featureLimits.allocations);
    const allocations = ServerContext.useStoreState((state) => state.server.data!.allocations, isEqual);
    const setServerFromState = ServerContext.useStoreActions((actions) => actions.server.setServerFromState);

    const { clearFlashes, clearAndAddHttpError } = useFlashKey('server:network');
    const { data, error, mutate } = getServerAllocations();

    useEffect(() => {
        mutate(allocations);
    }, []);

    useEffect(() => {
        clearAndAddHttpError(error);
    }, [error]);

    useDeepCompareEffect(() => {
        if (!data) return;

        setServerFromState((state) => ({ ...state, allocations: data }));
    }, [data]);

    const onCreateAllocation = () => {
        clearFlashes();

        setLoading(true);
        createServerAllocation(uuid)
            .then((allocation) => {
                setServerFromState((s) => ({ ...s, allocations: s.allocations.concat(allocation) }));
                return mutate(data?.concat(allocation), false);
            })
            .catch((error) => clearAndAddHttpError(error))
            .then(() => setLoading(false));
    };

    const primaryAllocation = data?.find(allocation => allocation.isDefault);
    const totalAllocations = data?.length || 0;

    return (
        <ServerContentBlock showFlashKey={'server:network'} title={'Network'}>
            <Header>
                <FontAwesomeIcon icon={faNetworkWired} className="text-indigo-400 mr-3 text-2xl" />
                <h1>Network Allocations</h1>
            </Header>
            
            <StatsContainer>
                <StatBox>
                    <StatValue>{totalAllocations}</StatValue>
                    <StatLabel>Total Allocations</StatLabel>
                </StatBox>
                
                <StatBox>
                    <StatValue>{allocationLimit}</StatValue>
                    <StatLabel>Allocation Limit</StatLabel>
                </StatBox>
                
                <StatBox>
                    <StatValue>
                        {primaryAllocation ? 
                            `${primaryAllocation.alias || ip(primaryAllocation.ip)}:${primaryAllocation.port}` : 
                            'None'
                        }
                    </StatValue>
                    <StatLabel>Primary Allocation</StatLabel>
                </StatBox>
            </StatsContainer>

            {!data ? (
                <Spinner size={'large'} centered />
            ) : (
                <>
                    <div className="mb-4">
                        {data.map((allocation) => (
                            <AllocationRow key={`${allocation.ip}:${allocation.port}`} allocation={allocation} />
                        ))}
                    </div>
                    
                    {allocationLimit > 0 && (
                        <Can action={'allocation.create'}>
                            <SpinnerOverlay visible={loading} />
                            <ActionContainer>
                                <InfoText>
                                    <FontAwesomeIcon icon={faInfoCircle} className="mr-2" />
                                    You are currently using {data.length} of {allocationLimit} allowed allocations for
                                    this server.
                                </InfoText>
                                {allocationLimit > data.length && (
                                    <Button 
                                        color={'primary'} 
                                        onClick={onCreateAllocation}
                                        className="flex items-center"
                                    >
                                        <FontAwesomeIcon icon={faPlus} className="mr-2" />
                                        Create New Allocation
                                    </Button>
                                )}
                            </ActionContainer>
                        </Can>
                    )}
                </>
            )}
        </ServerContentBlock>
    );
};

export default NetworkContainer;