import React, { useState, useRef, useEffect } from 'react';
import {
    RiDownloadLine,
    RiArchiveLine,
    RiLockLine,
    RiDeleteBinLine,
    RiUnlockLine,
    RiMoreFill
} from 'react-icons/ri';
import getBackupDownloadUrl from '@/api/server/backups/getBackupDownloadUrl';
import useFlash from '@/plugins/useFlash';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';
import deleteBackup from '@/api/server/backups/deleteBackup';
import Can from '@/components/elements/Can';
import tw, { styled, css } from 'twin.macro';
import getServerBackups from '@/api/swr/getServerBackups';
import { ServerBackup } from '@/api/server/types';
import { ServerContext } from '@/state/server';
import Input from '@/components/elements/Input';
import { restoreServerBackup } from '@/api/server/backups';
import http, { httpErrorToHuman } from '@/api/http';
import { Dialog } from '@/components/elements/dialog';
import { createPortal } from 'react-dom';

const DropdownButton = styled.button`
  ${tw`flex items-center justify-center w-8 h-8 rounded-lg transition-all duration-200`};
  background: rgba(31, 34, 53, 0.7);
  border: 1px solid rgba(255, 255, 255, 0.1);
  color: rgba(255, 255, 255, 0.6);
  
  &:hover {
    ${tw`text-indigo-300`};
    background: rgba(99, 102, 241, 0.15);
    border-color: rgba(99, 102, 241, 0.3);
    box-shadow: 0 0 15px rgba(99, 102, 241, 0.2);
  }
`;

const DropdownMenu = styled.div<{ isOpen: boolean, position: { top: number, left: number } }>`
  ${tw`fixed z-50 py-2 rounded-xl shadow-lg`};
  background: rgba(31, 34, 53, 0.95);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.1);
  box-shadow: 
    0 10px 30px rgba(0, 0, 0, 0.3),
    0 0 0 1px rgba(255, 255, 255, 0.05),
    inset 0 0 20px rgba(255, 255, 255, 0.03);
  min-width: 180px;
  transform-origin: top right;
  transition: all 0.2s ease;
  
  ${({ isOpen, position }) => css`
    top: ${position.top}px;
    left: ${position.left}px;
    
    ${isOpen 
      ? tw`opacity-100 visible scale-100` 
      : tw`opacity-0 invisible scale-95`
    };
  `};
`;

const DropdownItem = styled.button<{ danger?: boolean }>`
  ${tw`w-full text-left px-4 py-2 text-sm transition-all duration-200 flex items-center`};
  color: ${props => props.danger ? 'rgba(239, 68, 68, 0.9)' : 'rgba(255, 255, 255, 0.8)'};
  
  &:hover {
    background: ${props => props.danger 
      ? 'rgba(239, 68, 68, 0.15)' 
      : 'rgba(99, 102, 241, 0.15)'
    };
    color: ${props => props.danger ? 'rgba(239, 68, 68, 1)' : 'rgba(255, 255, 255, 1)'};
  }
  
  &:active {
    transform: scale(0.98);
  }
`;

interface Props {
    backup: ServerBackup;
}

export default ({ backup }: Props) => {
    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const setServerFromState = ServerContext.useStoreActions((actions) => actions.server.setServerFromState);
    const [modal, setModal] = useState('');
    const [loading, setLoading] = useState(false);
    const [truncate, setTruncate] = useState(false);
    const [isDropdownOpen, setIsDropdownOpen] = useState(false);
    const [dropdownPosition, setDropdownPosition] = useState({ top: 0, left: 0 });
    const { clearFlashes, clearAndAddHttpError } = useFlash();
    const { mutate } = getServerBackups();
    const dropdownButtonRef = useRef<HTMLButtonElement>(null);
    const dropdownMenuRef = useRef<HTMLDivElement>(null);

    const calculateDropdownPosition = () => {
        if (!dropdownButtonRef.current) return { top: 0, left: 0 };
        
        const rect = dropdownButtonRef.current.getBoundingClientRect();
        return {
            top: rect.bottom, // Use viewport-relative position for fixed positioning
            left: rect.right - 180 // Adjust based on dropdown width
        };
    };

    // Close dropdown when clicking outside (improved version)
    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            // Check if click is outside both the button and the dropdown menu
            if (dropdownButtonRef.current && 
                !dropdownButtonRef.current.contains(event.target as Node) &&
                dropdownMenuRef.current && 
                !dropdownMenuRef.current.contains(event.target as Node) &&
                isDropdownOpen) {
                setIsDropdownOpen(false);
            }
        };

        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, [isDropdownOpen]);

    const doDownload = () => {
        setLoading(true);
        clearFlashes('backups');
        getBackupDownloadUrl(uuid, backup.uuid)
            .then((url) => {
                // @ts-expect-error this is valid
                window.location = url;
            })
            .catch((error) => {
                console.error(error);
                clearAndAddHttpError({ key: 'backups', error });
            })
            .then(() => {
                setLoading(false);
                setIsDropdownOpen(false);
            });
    };

    const doDeletion = () => {
        setLoading(true);
        clearFlashes('backups');
        deleteBackup(uuid, backup.uuid)
            .then(() =>
                mutate(
                    (data) => ({
                        ...data,
                        items: data.items.filter((b) => b.uuid !== backup.uuid),
                        backupCount: data.backupCount - 1,
                    }),
                    false
                )
            )
            .catch((error) => {
                console.error(error);
                clearAndAddHttpError({ key: 'backups', error });
                setLoading(false);
                setModal('');
            })
            .then(() => setIsDropdownOpen(false));
    };

    const doRestorationAction = () => {
        setLoading(true);
        clearFlashes('backups');
        restoreServerBackup(uuid, backup.uuid, truncate)
            .then(() =>
                setServerFromState((s) => ({
                    ...s,
                    status: 'restoring_backup',
                }))
            )
            .catch((error) => {
                console.error(error);
                clearAndAddHttpError({ key: 'backups', error });
            })
            .then(() => {
                setLoading(false);
                setModal('');
                setIsDropdownOpen(false);
            });
    };

    const onLockToggle = () => {
        if (backup.isLocked && modal !== 'unlock') {
            setModal('unlock');
            setIsDropdownOpen(false);
            return;
        }

        http.post(`/api/client/servers/${uuid}/backups/${backup.uuid}/lock`)
            .then(() =>
                mutate(
                    (data) => ({
                        ...data,
                        items: data.items.map((b) =>
                            b.uuid !== backup.uuid
                                ? b
                                : {
                                      ...b,
                                      isLocked: !b.isLocked,
                                  }
                        ),
                    }),
                    false
                )
            )
            .catch((error) => alert(httpErrorToHuman(error)))
            .then(() => {
                setModal('');
                setIsDropdownOpen(false);
            });
    };

    const toggleDropdown = () => {
        if (!isDropdownOpen) {
            setDropdownPosition(calculateDropdownPosition());
        }
        setIsDropdownOpen(!isDropdownOpen);
    };

    return (
        <>
            <Dialog.Confirm
                open={modal === 'unlock'}
                onClose={() => setModal('')}
                title={`Unlock "${backup.name}"`}
                onConfirmed={onLockToggle}
            >
                This backup will no longer be protected from automated or accidental deletions.
            </Dialog.Confirm>
            <Dialog.Confirm
                open={modal === 'restore'}
                onClose={() => setModal('')}
                confirm={'Restore'}
                title={`Restore "${backup.name}"`}
                onConfirmed={() => doRestorationAction()}
            >
                <p>
                    Your server will be stopped. You will not be able to control the power state, access the file
                    manager, or create additional backups until completed.
                </p>
                <p css={tw`mt-4 -mb-2 bg-gray-700 p-3 rounded`}>
                    <label htmlFor={'restore_truncate'} css={tw`text-base flex items-center cursor-pointer`}>
                        <Input
                            type={'checkbox'}
                            css={tw`text-red-500! w-5! h-5! mr-2`}
                            id={'restore_truncate'}
                            value={'true'}
                            checked={truncate}
                            onChange={() => setTruncate((s) => !s)}
                        />
                        Delete all files before restoring backup.
                    </label>
                </p>
            </Dialog.Confirm>
            <Dialog.Confirm
                title={`Delete "${backup.name}"`}
                confirm={'Continue'}
                open={modal === 'delete'}
                onClose={() => setModal('')}
                onConfirmed={doDeletion}
            >
                This is a permanent operation. The backup cannot be recovered once deleted.
            </Dialog.Confirm>
            <SpinnerOverlay visible={loading} fixed />
            
            {backup.isSuccessful ? (
                <div css={tw`relative`}>
                    <DropdownButton 
                        ref={dropdownButtonRef}
                        onClick={toggleDropdown}
                    >
                        <RiMoreFill />
                    </DropdownButton>
                    
                    {isDropdownOpen && createPortal(
                        <DropdownMenu 
                            ref={dropdownMenuRef}
                            isOpen={isDropdownOpen} 
                            position={dropdownPosition}
                        >
                            <Can action={'backup.download'}>
                                <DropdownItem onClick={doDownload}>
                                    <RiDownloadLine className="mr-2" />
                                    Download
                                </DropdownItem>
                            </Can>
                            <Can action={'backup.restore'}>
                                <DropdownItem onClick={() => {
                                    setModal('restore');
                                    setIsDropdownOpen(false);
                                }}>
                                    <RiArchiveLine className="mr-2" />
                                    Restore
                                </DropdownItem>
                            </Can>
                            <Can action={'backup.delete'}>
                                {!backup.isLocked && (
                                    <DropdownItem 
                                        danger 
                                        onClick={() => {
                                            setModal('delete');
                                            setIsDropdownOpen(false);
                                        }}
                                    >
                                        <RiDeleteBinLine className="mr-2" />
                                        Delete
                                    </DropdownItem>
                                )}
                            </Can>
                        </DropdownMenu>,
                        document.body
                    )}
                </div>
            ) : (
                <button
                    onClick={() => setModal('delete')}
                    css={tw`text-gray-200 transition-colors duration-150 hover:text-gray-100 p-2`}
                >
                    <RiDeleteBinLine />
                </button>
            )}
        </>
    );
};