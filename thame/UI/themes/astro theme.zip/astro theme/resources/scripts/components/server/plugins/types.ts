export interface MinecraftPlugin {
  project_id: string;
  title: string;
  description: string;
  author: string;
  downloads: number;
  icon_url: string;
  date_created: string;
  project_type: string;
  versions: string[];
  slug: string;
}

export interface PluginVersion {
  id: string;
  version_number: string;
  date_published: string;
  game_versions: string[];
  loaders: string[];
  files: Array<{
    url: string;
    filename: string;
  }>;
}

export interface InstalledPlugin {
  name: string;
  file_name: string;
  file_size: number;
  modified_at: number;
  installed_info?: {
    version_id?: string;
    installed_at: string;
  };
}

export interface SearchResponse {
  success: boolean;
  data?: {
    hits: MinecraftPlugin[];
    total_hits: number;
  };
  error?: string;
}

export interface PluginDetailsResponse {
  success: boolean;
  plugin?: MinecraftPlugin;
  versions?: PluginVersion[];
  compatible_version?: PluginVersion;
  error?: string;
}

export interface InstallationResponse {
  success: boolean;
  message?: string;
  error?: string;
}