import React, { useEffect, useState } from 'react';
import { ServerContext } from '@/state/server';
import Modal from '@/components/elements/Modal';
import tw from 'twin.macro';
import Button from '@/components/elements/Button';
import saveFileContents from '@/api/server/files/saveFileContents';
import FlashMessageRender from '@/components/FlashMessageRender';
import useFlash from '@/plugins/useFlash';
import { SocketEvent, SocketRequest } from '@/components/server/events';

const stripAnsi = (s: string) => s.replace(/\u001b\[[0-9;]*m/g, '');

const EulaModalFeature: React.FC = () => {
    const [visible, setVisible] = useState(false);
    const [loading, setLoading] = useState(false);

    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const status = ServerContext.useStoreState((state) => state.status.value);
    const { clearFlashes, clearAndAddHttpError } = useFlash();
    const { connected, instance } = ServerContext.useStoreState((state) => state.socket);

    useEffect(() => {
        // only require a connected socket instance — listen regardless of "running" state so we don't miss lines
        if (!connected || !instance) return;

        const listener = (line: any) => {
            // Defensive: sometimes the event payload isn't a plain string.
            if (!line || typeof line !== 'string') return;

            // Remove ANSI/control codes that Minecraft server console may include and normalize.
            const normalized = stripAnsi(line).toLowerCase();

            // Be slightly more permissive: match common phrases that indicate EULA is required.
            // This handles variations like "You need to agree to the EULA..." or "eula.txt" mentions.
            if (/you need to agree to (the )?eula|agree to (the )?eula|eula\.txt/.test(normalized)) {
                // optional debug while testing:
                // console.debug('[EULA Feature] matched console line:', line);
                setVisible(true);
            }
        };

        instance.addListener(SocketEvent.CONSOLE_OUTPUT, listener);

        return () => {
            try {
                instance.removeListener(SocketEvent.CONSOLE_OUTPUT, listener);
            } catch (err) {
                // swallow - some socket implementations don't require strict removal signature
                // console.warn('[EULA Feature] failed to remove listener', err);
            }
        };
    }, [connected, instance]); // intentionally not depending on status to avoid missed attachments

    const onAcceptEULA = () => {
        setLoading(true);
        clearFlashes('feature:eula');

        saveFileContents(uuid, 'eula.txt', 'eula=true')
            .then(() => {
                // If the server is offline, request a restart; if the instance is present while online, request restart anyway.
                if ((status === 'offline' || status === 'stopped') && instance) {
                    instance.send(SocketRequest.SET_STATE, 'restart');
                } else if (instance) {
                    // If server attempted to start but failed due to EULA, a restart request is still useful.
                    instance.send(SocketRequest.SET_STATE, 'restart');
                }

                setVisible(false);
            })
            .catch((error) => {
                console.error(error);
                clearAndAddHttpError({ key: 'feature:eula', error });
            })
            .finally(() => {
                setLoading(false);
            });
    };

    useEffect(() => {
        clearFlashes('feature:eula');
    }, [clearFlashes]);

    return (
        <Modal
            visible={visible}
            onDismissed={() => setVisible(false)}
            closeOnBackground={false}
            showSpinnerOverlay={loading}
        >
            <FlashMessageRender key={'feature:eula'} css={tw`mb-4`} />
            <h2 css={tw`text-2xl mb-4 text-neutral-100`}>Accept Minecraft&reg; EULA</h2>
            <p css={tw`text-neutral-200`}>
                By pressing {'"I Accept"'} below you are indicating your agreement to the&nbsp;
                <a
                    target={'_blank'}
                    css={tw`text-primary-300 underline transition-colors duration-150 hover:text-primary-400`}
                    rel={'noreferrer noopener'}
                    href='https://www.minecraft.net/eula'
                >
                    Minecraft&reg; EULA
                </a>
                .
            </p>
            <div css={tw`mt-8 sm:flex items-center justify-end`}>
                <Button isSecondary onClick={() => setVisible(false)} css={tw`w-full sm:w-auto border-transparent`}>
                    Cancel
                </Button>
                <Button onClick={onAcceptEULA} css={tw`mt-4 sm:mt-0 sm:ml-4 w-full sm:w-auto`}>
                    I Accept
                </Button>
            </div>
        </Modal>
    );
};

export default EulaModalFeature;
