import styled, { css } from 'styled-components/macro';
import tw from 'twin.macro';

interface Props {
    hideDropdownArrow?: boolean;
    variant?: 'default' | 'primary' | 'danger';
}

const Select = styled.select<Props>`
    ${tw`shadow-none block p-3 pr-10 rounded-xl border w-full text-sm transition-all duration-200 ease-in-out`};
    
    // Base styles
    & {
        background: rgba(31, 34, 53, 0.7);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.1);
        color: rgba(255, 255, 255, 0.9);
        box-shadow: 
            inset 0 1px 3px rgba(0, 0, 0, 0.2),
            0 1px 0 rgba(255, 255, 255, 0.05);
    }

    &,
    &:hover:not(:disabled),
    &:focus {
        ${tw`outline-none`};
    }

    // Hover state
    &:hover:not(:disabled) {
        border-color: rgba(99, 102, 241, 0.4);
        box-shadow: 
            inset 0 1px 3px rgba(0, 0, 0, 0.2),
            0 0 0 3px rgba(99, 102, 241, 0.1);
    }

    // Focus state
    &:focus {
        border-color: rgba(99, 102, 241, 0.6);
        box-shadow: 
            inset 0 1px 3px rgba(0, 0, 0, 0.2),
            0 0 0 3px rgba(99, 102, 241, 0.2);
    }

    // Disabled state
    &:disabled {
        ${tw`opacity-75 cursor-not-allowed`};
        background: rgba(31, 34, 53, 0.4);
        color: rgba(255, 255, 255, 0.4);
    }

    // Remove default arrow
    -webkit-appearance: none;
    -moz-appearance: none;
    background-size: 16px;
    background-repeat: no-repeat;
    background-position-x: calc(100% - 12px);
    background-position-y: center;

    &::-ms-expand {
        display: none;
    }

    ${(props) =>
        !props.hideDropdownArrow &&
        css`
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20' fill='rgba(203, 213, 225, 0.7)'%3E%3Cpath fill-rule='evenodd' d='M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z' clip-rule='evenodd' /%3E%3C/svg%3E");
        `};

    // Variant styles
    ${(props) => props.variant === 'primary' && css`
        border-color: rgba(99, 102, 241, 0.4);
        
        &:hover:not(:disabled) {
            border-color: rgba(99, 102, 241, 0.6);
            box-shadow: 
                inset 0 1px 3px rgba(0, 0, 0, 0.2),
                0 0 0 3px rgba(99, 102, 241, 0.15);
        }
        
        &:focus {
            border-color: rgba(99, 102, 241, 0.8);
            box-shadow: 
                inset 0 1px 3px rgba(0, 0, 0, 0.2),
                0 0 0 3px rgba(99, 102, 241, 0.25);
        }
    `};

    ${(props) => props.variant === 'danger' && css`
        border-color: rgba(239, 68, 68, 0.4);
        
        &:hover:not(:disabled) {
            border-color: rgba(239, 68, 68, 0.6);
            box-shadow: 
                inset 0 1px 3px rgba(0, 0, 0, 0.2),
                0 0 0 3px rgba(239, 68, 68, 0.15);
        }
        
        &:focus {
            border-color: rgba(239, 68, 68, 0.8);
            box-shadow: 
                inset 0 1px 3px rgba(0, 0, 0, 0.2),
                0 0 0 3px rgba(239, 68, 68, 0.25);
        }
    `};
`;

export default Select;