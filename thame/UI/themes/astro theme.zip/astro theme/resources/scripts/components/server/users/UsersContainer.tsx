import React, { useEffect, useState } from 'react';
import { ServerContext } from '@/state/server';
import { Actions, useStoreActions, useStoreState } from 'easy-peasy';
import { ApplicationStore } from '@/state';
import Spinner from '@/components/elements/Spinner';
import AddSubuserButton from '@/components/server/users/AddSubuserButton';
import UserRow from '@/components/server/users/UserRow';
import FlashMessageRender from '@/components/FlashMessageRender';
import getServerSubusers from '@/api/server/users/getServerSubusers';
import { httpErrorToHuman } from '@/api/http';
import Can from '@/components/elements/Can';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import tw, { styled } from 'twin.macro';
import { RiGroupLine, RiInformationLine, RiUserAddLine } from 'react-icons/ri';

const Header = styled.div`
    ${tw`flex items-center mb-6`};
    
    h1 {
        ${tw`text-2xl font-bold`};
        background: linear-gradient(90deg, #EEE 0%, #CCC 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
    }
`;

const StatsContainer = styled.div`
    ${tw`grid grid-cols-1 md:grid-cols-3 gap-4 mb-6`};
`;

const StatBox = styled.div`
    ${tw`p-4 rounded-xl`};
    background: rgba(31, 34, 53, 0.7);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.1);
    box-shadow: 
        0 4px 15px rgba(0, 0, 0, 0.15), 
        0 0 0 1px rgba(255, 255, 255, 0.05),
        inset 0 0 20px rgba(255, 255, 255, 0.03);
`;

const StatValue = styled.div`
    ${tw`text-2xl font-bold text-neutral-200`};
`;

const StatLabel = styled.div`
    ${tw`text-sm text-neutral-400 mt-1`};
`;

const UserGrid = styled.div`
    ${tw`grid grid-cols-1 gap-4`};
`;

const EmptyState = styled.div`
    ${tw`text-center py-12 rounded-xl col-span-3`};
    background: rgba(31, 34, 53, 0.5);
    border: 1px dashed rgba(255, 255, 255, 0.1);
`;

const ActionContainer = styled.div`
    ${tw`mt-6 flex flex-col sm:flex-row items-center justify-between p-4 rounded-xl`};
    background: rgba(31, 34, 53, 0.5);
    border: 1px solid rgba(255, 255, 255, 0.07);
`;

const InfoText = styled.p`
    ${tw`text-sm text-neutral-300 mb-4 sm:mb-0`};
`;

export default () => {
    const [loading, setLoading] = useState(true);

    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const subusers = ServerContext.useStoreState((state) => state.subusers.data);
    const setSubusers = ServerContext.useStoreActions((actions) => actions.subusers.setSubusers);

    const permissions = useStoreState((state: ApplicationStore) => state.permissions.data);
    const getPermissions = useStoreActions((actions: Actions<ApplicationStore>) => actions.permissions.getPermissions);
    const { addError, clearFlashes } = useStoreActions((actions: Actions<ApplicationStore>) => actions.flashes);

    useEffect(() => {
        clearFlashes('users');
        getServerSubusers(uuid)
            .then((subusers) => {
                setSubusers(subusers);
                setLoading(false);
            })
            .catch((error) => {
                console.error(error);
                addError({ key: 'users', message: httpErrorToHuman(error) });
                setLoading(false);
            });
    }, []);

    useEffect(() => {
        getPermissions().catch((error) => {
            addError({ key: 'users', message: httpErrorToHuman(error) });
            console.error(error);
        });
    }, []);

    // Calculate statistics
    const totalUsers = subusers.length;
    const usersWith2FA = subusers.filter(user => user.twoFactorEnabled).length;
    const activePermissions = subusers.reduce((acc, user) => {
        return acc + user.permissions.filter(p => p !== 'websocket.connect').length;
    }, 0);

    if (loading || !Object.keys(permissions).length) {
        return <Spinner size={'large'} centered />;
    }

    return (
        <ServerContentBlock title={'Users'}>
            <Header>
                <RiGroupLine className="text-indigo-400 mr-3 text-2xl" />
                <h1>User Management</h1>
            </Header>
            
            <StatsContainer>
                <StatBox>
                    <StatValue>{totalUsers}</StatValue>
                    <StatLabel>Total Users</StatLabel>
                </StatBox>
                
                <StatBox>
                    <StatValue>{usersWith2FA}</StatValue>
                    <StatLabel>2FA Enabled</StatLabel>
                </StatBox>
                
                <StatBox>
                    <StatValue>{activePermissions}</StatValue>
                    <StatLabel>Active Permissions</StatLabel>
                </StatBox>
            </StatsContainer>

            <FlashMessageRender byKey={'users'} css={tw`mb-4`} />
            
            {!subusers.length ? (
                <EmptyState>
					<div className="flex justify-center items-center">
						<RiGroupLine className="text-neutral-500 text-4xl mb-4" />
					</div>
                    <p css={tw`text-center text-sm text-neutral-400`}>
                        No users have been added to this server yet.
                    </p>
                    <p css={tw`text-center text-sm text-neutral-500 mt-2`}>
                        Add your first user to get started with collaborative management.
                    </p>
                </EmptyState>
            ) : (
                <UserGrid>
                    {subusers.map((subuser) => <UserRow key={subuser.uuid} subuser={subuser} />)}
                </UserGrid>
            )}
            
            <Can action={'user.create'}>
                <ActionContainer>
                    <InfoText>
                        <RiInformationLine className="mr-2" />
                        Manage users who can access and control this server.
                    </InfoText>
                    <AddSubuserButton>
                        <RiUserAddLine className="mr-2" />
                        Add User
                    </AddSubuserButton>
                </ActionContainer>
            </Can>
        </ServerContentBlock>
    );
};