import * as React from 'react';
import ContentBox from '@/components/elements/ContentBox';
import UpdatePasswordForm from '@/components/dashboard/forms/UpdatePasswordForm';
import UpdateEmailAddressForm from '@/components/dashboard/forms/UpdateEmailAddressForm';
import ConfigureTwoFactorForm from '@/components/dashboard/forms/ConfigureTwoFactorForm';
import PageContentBlock from '@/components/elements/PageContentBlock';
import tw, { styled } from 'twin.macro';
import { breakpoint } from '@/theme';
import MessageBox from '@/components/MessageBox';
import { useLocation } from 'react-router-dom';
import { RiShieldKeyholeLine, RiMailLine, RiLockPasswordLine } from 'react-icons/ri';

const Container = styled.div`
    ${tw`grid grid-cols-1 lg:grid-cols-3 gap-6 mb-10`};
`;

const StatsContainer = styled.div`
    ${tw`grid grid-cols-1 md:grid-cols-3 gap-4 mb-8`};
`;

const StatBox = styled.div`
    ${tw`p-4 rounded-xl`};
    background: rgba(31, 34, 53, 0.7);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.1);
    box-shadow: 
        0 4px 15px rgba(0, 0, 0, 0.15), 
        0 0 0 1px rgba(255, 255, 255, 0.05),
        inset 0 0 20px rgba(255, 255, 255, 0.03);
`;

const StatValue = styled.div`
    ${tw`text-2xl font-bold text-neutral-200`};
`;

const StatLabel = styled.div`
    ${tw`text-sm text-neutral-400 mt-1`};
`;

const Header = styled.div`
    ${tw`flex items-center mb-8`};
    
    h1 {
        ${tw`text-2xl font-bold`};
        background: linear-gradient(90deg, #EEE 0%, #CCC 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
    }
`;

export default () => {
    const { state } = useLocation<undefined | { twoFactorRedirect?: boolean }>();

    return (
        <PageContentBlock title={'Account Overview'}>
            <Header>
                <RiShieldKeyholeLine className="text-indigo-400 mr-3 text-2xl" />
                <h1>Account Security</h1>
            </Header>

            {state?.twoFactorRedirect && (
                <MessageBox title={'2-Factor Required'} type={'error'} className="mb-6">
                    Your account must have two-factor authentication enabled in order to continue.
                </MessageBox>
            )}

            <Container>
                <ContentBox 
                    title={'Update Password'} 
                    icon={RiLockPasswordLine}
                    showFlashes={'account:password'}
                >
                    <UpdatePasswordForm />
                </ContentBox>
                
                <ContentBox 
                    title={'Update Email Address'} 
                    icon={RiMailLine}
                    showFlashes={'account:email'}
                >
                    <UpdateEmailAddressForm />
                </ContentBox>
                
                <ContentBox 
                    title={'Two-Step Verification'} 
                    icon={RiShieldKeyholeLine}
                >
                    <ConfigureTwoFactorForm />
                </ContentBox>
            </Container>
        </PageContentBlock>
    );
};