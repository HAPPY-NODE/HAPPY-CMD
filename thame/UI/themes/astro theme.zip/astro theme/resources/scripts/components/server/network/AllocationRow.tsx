import React, { memo, useCallback, useState } from 'react';
import isEqual from 'react-fast-compare';
import tw, { styled } from 'twin.macro';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faNetworkWired, faStar, faStickyNote, faCopy, faCheckCircle } from '@fortawesome/free-solid-svg-icons';
import InputSpinner from '@/components/elements/InputSpinner';
import { Textarea } from '@/components/elements/Input';
import Can from '@/components/elements/Can';
import { Button } from '@/components/elements/button/index';
import GreyRowBox from '@/components/elements/GreyRowBox';
import { Allocation } from '@/api/server/getServer';
import { debounce } from 'debounce';
import setServerAllocationNotes from '@/api/server/network/setServerAllocationNotes';
import { useFlashKey } from '@/plugins/useFlash';
import { ServerContext } from '@/state/server';
import CopyOnClick from '@/components/elements/CopyOnClick';
import DeleteAllocationButton from '@/components/server/network/DeleteAllocationButton';
import setPrimaryServerAllocation from '@/api/server/network/setPrimaryServerAllocation';
import getServerAllocations from '@/api/swr/getServerAllocations';
import { ip } from '@/lib/formatters';
import Code from '@/components/elements/Code';

const AllocationContainer = styled.div`
    ${tw`rounded-xl overflow-hidden mb-4`};
    background: rgba(31, 34, 53, 0.7);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.1);
    box-shadow: 
        0 10px 30px rgba(0, 0, 0, 0.2),
        0 0 0 1px rgba(255, 255, 255, 0.05),
        inset 0 0 20px rgba(255, 255, 255, 0.03);
    transition: all 0.3s ease;
    
    &:hover {
        transform: translateY(-2px);
        box-shadow: 
            0 15px 35px rgba(0, 0, 0, 0.3),
            0 0 0 1px rgba(99, 102, 241, 0.1),
            inset 0 0 20px rgba(255, 255, 255, 0.05);
    }
`;

const AllocationHeader = styled.div<{ $isPrimary: boolean }>`
    ${tw`flex items-center px-5 py-3 border-b`};
    background: ${props => props.$isPrimary 
        ? 'linear-gradient(90deg, rgba(59, 130, 246, 0.15) 0%, rgba(37, 99, 235, 0.1) 100%)' 
        : 'rgba(31, 34, 53, 0.5)'};
    border-color: rgba(255, 255, 255, 0.07);
`;

const AllocationBody = styled.div`
    ${tw`p-5`};
    background: rgba(31, 34, 53, 0.3);
`;

const AllocationInfo = styled.div`
    ${tw`grid grid-cols-1 md:grid-cols-3 gap-4 mb-4`};
`;

const InfoBox = styled.div`
    ${tw`p-3 rounded-lg`};
    background: rgba(31, 34, 53, 0.5);
    border: 1px solid rgba(255, 255, 255, 0.07);
`;

const Label = styled.label`
    ${tw`uppercase text-xs mt-1 text-neutral-400 block px-1 select-none transition-colors duration-150`}
`;

const CopyButton = styled.button`
    ${tw`ml-2 p-1 text-neutral-400 hover:text-indigo-300 transition-colors duration-200`};
`;

const NotesSection = styled.div`
    ${tw`mt-4`};
`;

const NotesHeader = styled.div`
    ${tw`flex items-center text-sm font-medium text-neutral-300 mb-2`};
    
    svg {
        ${tw`mr-2`};
    }
`;

const ActionBar = styled.div`
    ${tw`flex justify-end space-x-3 mt-4`};
`;

const PrimaryBadge = styled.span`
    ${tw`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-500 text-white`};
    
    svg {
        ${tw`mr-1`};
    }
`;

interface Props {
    allocation: Allocation;
}

const AllocationRow = ({ allocation }: Props) => {
    const [loading, setLoading] = useState(false);
    const [copied, setCopied] = useState({ ip: false, port: false });
    const { clearFlashes, clearAndAddHttpError } = useFlashKey('server:network');
    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const { mutate } = getServerAllocations();

    const onNotesChanged = useCallback((id: number, notes: string) => {
        mutate((data) => data?.map((a) => (a.id === id ? { ...a, notes } : a)), false);
    }, []);

    const setAllocationNotes = debounce((notes: string) => {
        setLoading(true);
        clearFlashes();

        setServerAllocationNotes(uuid, allocation.id, notes)
            .then(() => onNotesChanged(allocation.id, notes))
            .catch((error) => clearAndAddHttpError(error))
            .then(() => setLoading(false));
    }, 750);

    const setPrimaryAllocation = () => {
        clearFlashes();
        mutate((data) => data?.map((a) => ({ ...a, isDefault: a.id === allocation.id })), false);

        setPrimaryServerAllocation(uuid, allocation.id).catch((error) => {
            clearAndAddHttpError(error);
            mutate();
        });
    };

    const handleCopy = (type: 'ip' | 'port') => {
        setCopied({ ...copied, [type]: true });
        setTimeout(() => setCopied({ ...copied, [type]: false }), 2000);
    };

    return (
        <AllocationContainer>
            <AllocationHeader $isPrimary={allocation.isDefault}>
                <div className="flex items-center">
                    <FontAwesomeIcon icon={faNetworkWired} className="text-blue-400 mr-3" />
                    <span className="font-medium text-neutral-200">
                        Network Allocation
                    </span>
                    {allocation.isDefault && (
                        <PrimaryBadge className="ml-3">
                            <FontAwesomeIcon icon={faStar} className="text-xs" />
                            Primary
                        </PrimaryBadge>
                    )}
                </div>
            </AllocationHeader>
            
            <AllocationBody>
                <AllocationInfo>
                    <InfoBox>
                        <div className="flex items-center justify-between">
                            <span className="text-sm font-medium text-neutral-300">IP Address</span>
                            <CopyOnClick text={allocation.alias || ip(allocation.ip)}>
                                <CopyButton onClick={() => handleCopy('ip')}>
                                    {copied.ip ? (
                                        <FontAwesomeIcon icon={faCheckCircle} className="text-green-400" />
                                    ) : (
                                        <FontAwesomeIcon icon={faCopy} />
                                    )}
                                </CopyButton>
                            </CopyOnClick>
                        </div>
                        <Code dark className="mt-1 text-sm">
                            {allocation.alias || ip(allocation.ip)}
                        </Code>
                        <Label>{allocation.alias ? 'Hostname' : 'IP Address'}</Label>
                    </InfoBox>
                    
                    <InfoBox>
                        <div className="flex items-center justify-between">
                            <span className="text-sm font-medium text-neutral-300">Port</span>
                            <CopyOnClick text={String(allocation.port)}>
                                <CopyButton onClick={() => handleCopy('port')}>
                                    {copied.port ? (
                                        <FontAwesomeIcon icon={faCheckCircle} className="text-green-400" />
                                    ) : (
                                        <FontAwesomeIcon icon={faCopy} />
                                    )}
                                </CopyButton>
                            </CopyOnClick>
                        </div>
                        <Code dark className="mt-1 text-sm">
                            {allocation.port}
                        </Code>
                        <Label>Port Number</Label>
                    </InfoBox>
                    
                    <InfoBox>
                        <span className="text-sm font-medium text-neutral-300">Status</span>
                        <div className="mt-1 flex items-center">
                            <div className={`h-2 w-2 rounded-full ${allocation.isDefault ? 'bg-green-400' : 'bg-blue-400'}`}></div>
                            <span className="text-sm text-neutral-300 ml-2">
                                {allocation.isDefault ? 'Active' : 'Standby'}
                            </span>
                        </div>
                        <Label>Connection Status</Label>
                    </InfoBox>
                </AllocationInfo>
                
                <NotesSection>
                    <NotesHeader>
                        <FontAwesomeIcon icon={faStickyNote} />
                        Notes
                    </NotesHeader>
                    <InputSpinner visible={loading}>
                        <Textarea
                            className={'bg-neutral-800 hover:border-neutral-600 border-transparent rounded-lg'}
                            placeholder={'Add notes about this allocation...'}
                            defaultValue={allocation.notes || undefined}
                            onChange={(e) => setAllocationNotes(e.currentTarget.value)}
                            rows={2}
                        />
                    </InputSpinner>
                </NotesSection>
                
                <ActionBar>
                    {allocation.isDefault ? (
                        <Button size={Button.Sizes.Small} className={'!text-gray-50 !bg-blue-600'} disabled>
                            <FontAwesomeIcon icon={faStar} className="mr-2" />
                            Primary Allocation
                        </Button>
                    ) : (
                        <>
                            <Can action={'allocation.delete'}>
                                <DeleteAllocationButton allocation={allocation.id} />
                            </Can>
                            <Can action={'allocation.update'}>
                                <Button size={Button.Sizes.Small} onClick={setPrimaryAllocation}>
                                    <FontAwesomeIcon icon={faStar} className="mr-2" />
                                    Make Primary
                                </Button>
                            </Can>
                        </>
                    )}
                </ActionBar>
            </AllocationBody>
        </AllocationContainer>
    );
};

export default memo(AllocationRow, isEqual);