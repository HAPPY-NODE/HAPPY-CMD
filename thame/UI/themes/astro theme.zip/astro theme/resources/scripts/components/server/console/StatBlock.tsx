import React from 'react';
import Icon from '@/components/elements/Icon';
import { IconDefinition } from '@fortawesome/free-solid-svg-icons';
import classNames from 'classnames';
import useFitText from 'use-fit-text';
import CopyOnClick from '@/components/elements/CopyOnClick';
import tw from 'twin.macro';
import styled from 'styled-components/macro';
import { motion } from 'framer-motion';

const StatContainer = styled.div`
  ${tw`relative flex items-center gap-4 p-6 rounded-xl transition-all duration-500 overflow-hidden`}
  background: linear-gradient(135deg, rgba(30, 30, 46, 0.9) 0%, rgba(25, 25, 40, 0.9) 100%);
  border: 1px solid rgba(255, 255, 255, 0.08);
  backdrop-filter: blur(20px);
  box-shadow: 
    0 4px 20px rgba(0, 0, 0, 0.15),
    inset 0 1px 0 rgba(255, 255, 255, 0.1);
  
  &::before {
    content: '';
    ${tw`absolute inset-0 opacity-0 transition-opacity duration-500`}
    background: linear-gradient(135deg, rgba(59, 130, 246, 0.1) 0%, rgba(168, 85, 247, 0.05) 100%);
  }
  
  &:hover {
    border-color: rgba(59, 130, 246, 0.3);
    transform: translateY(-4px);
    box-shadow: 
      0 12px 40px rgba(0, 0, 0, 0.25),
      0 0 0 1px rgba(59, 130, 246, 0.1),
      inset 0 1px 0 rgba(255, 255, 255, 0.1);
    
    &::before {
      opacity: 1;
    }
  }
`;

const BackgroundIcon = styled.div<{ $iconColor?: string }>`
  ${tw`absolute right-3 bottom-2 text-5xl opacity-[0.03] pointer-events-none transition-all duration-700`}
  color: ${props => props.$iconColor || '#3b82f6'};
  z-index: 0;
  filter: blur(0.5px);
  
  ${StatContainer}:hover & {
    transform: scale(1.1) translateY(-5px);
    opacity: 0.05;
  }
`;

const ContentWrapper = styled.div`
  ${tw`flex items-center gap-4 w-full relative z-10`}
`;

const IconContainer = styled.div<{ $color?: string }>`
  ${tw`flex items-center justify-center h-14 w-14 rounded-xl transition-all duration-500 relative overflow-hidden`}
  background: ${props => props.$color ? 
    `linear-gradient(135deg, ${props.$color}15 0%, ${props.$color}08 100%)` : 
    'linear-gradient(135deg, rgba(59, 130, 246, 0.15) 0%, rgba(59, 130, 246, 0.08) 100%)'};
  border: 1px solid ${props => props.$color ? `${props.$color}20` : 'rgba(59, 130, 246, 0.2)'};
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  
  &::before {
    content: '';
    ${tw`absolute inset-0 opacity-0 transition-opacity duration-500`}
    background: linear-gradient(135deg, ${props => props.$color || '#3b82f6'}20 0%, transparent 50%);
  }
  
  ${StatContainer}:hover & {
    transform: scale(1.08) rotate(5deg);
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
    
    &::before {
      opacity: 1;
    }
  }
`;

const TextContainer = styled.div`
  ${tw`flex flex-col justify-center flex-1 min-w-0`}
`;

const Title = styled.p`
  ${tw`text-xs font-semibold text-neutral-300 mb-2 uppercase tracking-wider`}
  text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
`;

const Value = styled.div`
  ${tw`font-bold text-white text-lg leading-tight`}
  text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
`;

const SubValue = styled.span`
  ${tw`text-sm text-neutral-400 ml-1 font-normal`}
`;

const GlowEffect = styled.div<{ $color?: string }>`
  ${tw`absolute inset-0 rounded-2xl opacity-0 transition-opacity duration-500`}
  background: radial-gradient(circle at center, ${props => props.$color || '#3b82f6'}15 0%, transparent 70%);
  filter: blur(10px);
  z-index: -1;
  
  ${StatContainer}:hover & {
    opacity: 1;
  }
`;

interface StatBlockProps {
    title: string;
    copyOnClick?: string;
    color?: string;
    icon: IconDefinition;
    children: React.ReactNode;
    className?: string;
}

const StatBlock = ({ title, copyOnClick, icon, color, className, children }: StatBlockProps) => {
    const { fontSize, ref } = useFitText({ minFontSize: 18, maxFontSize: 24 });

    return (
        <CopyOnClick text={copyOnClick}>
            <StatContainer
                className={className}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
            >
                <GlowEffect $color={color} />
                
                <ContentWrapper>

                    <TextContainer>
                        <Title>{title}</Title>
                        <Value ref={ref}>
                            {children}
                        </Value>
                    </TextContainer>
                </ContentWrapper>
            </StatContainer>
        </CopyOnClick>
    );
};

export default StatBlock;