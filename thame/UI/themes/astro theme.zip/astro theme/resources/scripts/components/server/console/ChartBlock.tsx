import React from 'react';
import classNames from 'classnames';
import tw from 'twin.macro';
import styled from 'styled-components/macro';

const ChartContainer = styled.div`
  ${tw`p-3 rounded-xl transition-all duration-500 overflow-hidden`}
  background: linear-gradient(135deg, rgba(30, 30, 46, 0.9) 0%, rgba(25, 25, 40, 0.9) 100%);
  border: 1px solid rgba(255, 255, 255, 0.08);
  backdrop-filter: blur(20px);
  box-shadow: 
    0 4px 20px rgba(0, 0, 0, 0.15),
    inset 0 1px 0 rgba(255, 255, 255, 0.1);
  
  &::before {
    content: '';
    ${tw`absolute inset-0 opacity-0 transition-opacity duration-500`}
    background: linear-gradient(135deg, rgba(59, 130, 246, 0.1) 0%, rgba(168, 85, 247, 0.05) 100%);
  }
  
  &:hover {
    border-color: rgba(59, 130, 246, 0.3);
    transform: translateY(-4px);
    box-shadow: 
      0 12px 40px rgba(0, 0, 0, 0.25),
      0 0 0 1px rgba(59, 130, 246, 0.1),
      inset 0 1px 0 rgba(255, 255, 255, 0.1);
    
    &::before {
      opacity: 1;
    }
  }
`;

interface ChartBlockProps {
    title: string;
    legend?: React.ReactNode;
    children: React.ReactNode;
}

const ChartBlock = ({ title, legend, children }: ChartBlockProps) => (
    <ChartContainer className={classNames('group')}>
        <div className={'flex items-center justify-between mb-2'}>
            <h3 className={'font-header text-blue-300 text-sm'}>{title}</h3>
            {legend && <div className={'text-xs flex items-center gap-2'}>{legend}</div>}
        </div>
        {children}
    </ChartContainer>
);

export default ChartBlock;
