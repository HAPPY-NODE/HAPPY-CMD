import React, { useState, useEffect, useRef } from 'react';
import ReactDOM from 'react-dom';
import { ServerContext } from '@/state/server';
import TitledGreyBox from '@/components/elements/TitledGreyBox';
import { Button } from '@/components/elements/button/index';
import Input from '@/components/elements/Input';
import { RiSearchLine, RiDownloadLine, RiInformationLine, RiBox3Line, RiCheckLine, RiStarFill, RiCloseLine, RiArrowLeftSLine, RiArrowRightSLine } from 'react-icons/ri';
import tw from 'twin.macro';
import styled, { keyframes, css } from 'styled-components/macro';

// Pulsing animation for placeholders
const pulse = keyframes`
  0%, 100% {
    opacity: 1;
  }
  50% {
    opacity: 0.6;
  }
`;

const shimmer = keyframes`
  0% {
    transform: translateX(-100%);
  }
  100% {
    transform: translateX(100%);
  }
`;

const SearchContainer = styled.div`
    ${tw`mb-6`};
`;

const PluginGrid = styled.div`
    ${tw`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-4`};
`;

const PluginCard = styled.div`
    ${tw`p-4 rounded-lg transition-all duration-300 flex flex-col`};
    background: rgba(31, 34, 53, 0.8);
    border: 1px solid rgba(255, 255, 255, 0.08);
    backdrop-filter: blur(10px);
    
    &:hover {
        border-color: rgba(99, 102, 241, 0.5);
        transform: translateY(-3px);
        box-shadow: 0 12px 30px -8px rgba(0, 0, 0, 0.45);
    }
`;

// Placeholder Card Component
const PlaceholderCard = styled.div<{ delay?: number }>`
    ${tw`p-4 rounded-lg flex flex-col relative overflow-hidden`};
    background: rgba(31, 34, 53, 0.6);
    border: 1px solid rgba(255, 255, 255, 0.05);
    animation: ${pulse} 2s ease-in-out infinite;
    animation-delay: ${props => props.delay || 0}ms;
    
    &::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(
            90deg,
            transparent,
            rgba(255, 255, 255, 0.1),
            transparent
        );
        animation: ${shimmer} 2s infinite;
        animation-delay: ${props => props.delay || 0}ms;
    }
`;

const PlaceholderIcon = styled.div`
    ${tw`w-12 h-12 rounded-lg mb-3`};
    background: linear-gradient(90deg, rgba(55, 65, 81, 0.5), rgba(75, 85, 99, 0.5), rgba(55, 65, 81, 0.5));
    background-size: 200% 100%;
    animation: ${pulse} 1.5s ease-in-out infinite;
`;

const PlaceholderText = styled.div<{ width?: string; height?: string }>`
    background: linear-gradient(90deg, rgba(55, 65, 81, 0.5), rgba(75, 85, 99, 0.5), rgba(55, 65, 81, 0.5));
    background-size: 200% 100%;
    border-radius: 4px;
    width: ${props => props.width || '100%'};
    height: ${props => props.height || '12px'};
    margin-bottom: 8px;
    animation: ${pulse} 2s ease-in-out infinite;
`;

const EmptyState = styled.div`
    ${tw`text-center py-12`};
`;

const FilterContainer = styled.div`
    ${tw`flex flex-wrap gap-4 mb-4 items-center`};
`;

const FilterSelect = styled.select`
    ${tw`px-3 py-2 bg-gray-700 border border-gray-600 rounded text-sm text-gray-200 transition-colors`};
    
    &:focus {
        ${tw`outline-none ring-2 ring-blue-500 border-blue-500`};
    }
    
    &:hover {
        ${tw`border-gray-500`};
    }
`;

const InstallButton = styled(Button)<{ installing?: boolean; installed?: boolean }>`
    ${tw`w-full transition-all duration-300 relative overflow-hidden flex items-center justify-center`};
    
    ${props => props.installing && tw`opacity-75 cursor-not-allowed`};
    ${props => props.installed && tw`bg-green-600 hover:bg-green-700 border-green-500`};
`;

const LoadingBar = styled.div<{ progress: number }>`
    ${tw`absolute bottom-0 left-0 h-1 bg-blue-400 transition-all duration-300`};
    width: ${props => props.progress}%;
`;

const FeaturedBadge = styled.div`
    ${tw`absolute -top-2 -right-2 bg-gradient-to-r from-yellow-500 to-red-400 text-white text-xs px-2 py-1 rounded-full flex items-center space-x-1`};
    box-shadow: 0 2px 10px rgba(245, 158, 11, 0.3);
`;

const PluginIconContainer = styled.div`
    ${tw`relative`};
`;

const StatsContainer = styled.div`
    ${tw`flex items-center justify-between text-xs`};
`;

const StatItem = styled.div`
    ${tw`flex items-center space-x-1 text-gray-400`};
`;

const CategoryBadge = styled.span<{ type: string }>`
    ${tw`px-2 py-1 text-xs rounded border font-medium`};
    ${props => {
        switch (props.type) {
            case 'mod': return tw`bg-purple-500/20 text-purple-300 border-purple-500/30`;
            case 'datapack': return tw`bg-green-500/20 text-green-300 border-green-500/30`;
            case 'resourcepack': return tw`bg-yellow-500/20 text-yellow-300 border-yellow-500/30`;
            case 'plugin': 
            default: return tw`bg-blue-500/20 text-blue-300 border-blue-500/30`;
        }
    }};
`;

/* Modal styles (simple, dependency-free) */
const ModalOverlay = styled.div`
    ${tw`fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-60`};
`;

const ModalContent = styled.div`
    ${tw`w-full max-w-3xl p-6 rounded-lg`};
    background: rgba(17, 24, 39, 0.95);
    border: 1px solid rgba(255,255,255,0.06);
    box-shadow: 0 10px 40px rgba(2,6,23,0.75);
`;

// Function to get CSRF token from meta tag
const getCsrfToken = (): string => {
    const metaTag = document.querySelector('meta[name="csrf-token"]') as HTMLMetaElement;
    return metaTag ? metaTag.content : '';
};

/**
 * Small portal helper so modal mounts on document.body and always appears in viewport
 * (prevents it being clipped/offset inside parent scroll container).
 */
const ModalPortal: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    if (typeof document === 'undefined') return null;
    return ReactDOM.createPortal(children, document.body);
};

// Loading spinner for install buttons (kept for installation process)
const InstallSpinner = styled.div`
    ${tw`w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2`};
`;

// Component to render placeholder plugin cards
const PluginPlaceholders: React.FC<{ count?: number }> = ({ count = 9 }) => {
    return (
        <PluginGrid>
            {Array.from({ length: count }, (_, index) => (
                <PlaceholderCard key={index} delay={index * 100}>
                    <div className="flex items-start space-x-3 mb-3">
                        <PlaceholderIcon />
                        <div className="flex-1 min-w-0">
                            <PlaceholderText width="70%" height="16px" />
                            <PlaceholderText width="50%" height="12px" />
                        </div>
                    </div>
                    
                    <PlaceholderText height="14px" />
                    <PlaceholderText height="14px" />
                    <PlaceholderText width="80%" height="14px" />
                    
                    <div className="mt-4 space-y-2">
                        <PlaceholderText width="100%" height="36px" />
                        <PlaceholderText width="100%" height="36px" />
                    </div>
                </PlaceholderCard>
            ))}
        </PluginGrid>
    );
};

export default () => {
    const server = ServerContext.useStoreState(state => state.server.data!);
    const [searchQuery, setSearchQuery] = useState('');
    const [plugins, setPlugins] = useState<any[]>([]);
    const [loading, setLoading] = useState(false);
    const [searchState, setSearchState] = useState<'initial' | 'loading' | 'results' | 'empty'>('loading');
    const [filters, setFilters] = useState({
        category: '',
        sort: 'relevance'
    });
    const [installingPlugins, setInstallingPlugins] = useState<{ [key: string]: boolean }>({});
    const [installedPlugins, setInstalledPlugins] = useState<{ [key: string]: boolean }>({});
    const [installProgress, setInstallProgress] = useState<{ [key: string]: number }>({});
    const [modalOpen, setModalOpen] = useState(false);
    const [modalPlugin, setModalPlugin] = useState<any | null>(null);
    const [modalLoading, setModalLoading] = useState(false);

    // pagination state
    const [currentPage, setCurrentPage] = useState<number>(1);
    const [totalPages, setTotalPages] = useState<number>(1);
    const [perPage, setPerPage] = useState<number>(48); // featured default bigger
    const [totalHits, setTotalHits] = useState<number>(0);

    // keep track if component is mounted to avoid state updates on unmounted
    const isMounted = useRef(true);
    useEffect(() => {
        isMounted.current = true;
        return () => { isMounted.current = false; };
    }, []);

    // AbortController for searching
    const activeSearchController = useRef<AbortController | null>(null);

    useEffect(() => {
        const loadInstalledPlugins = async () => {
            try {
                const response = await fetch(`/api/client/servers/${server.uuid}/plugins/installed`);
                const data = await response.json();

                if (data.success && data.plugins) {
                    const installedMap: { [key: string]: boolean } = {};
                    data.plugins.forEach((plugin: any) => {
                        // map by project_id or plugin name to be safer
                        const id = plugin.plugin_id || plugin.name;
                        installedMap[id] = true;
                    });
                    if (isMounted.current) setInstalledPlugins(installedMap);
                }
            } catch (err) {
                console.error('Error loading installed plugins:', err);
            }
        };

        loadInstalledPlugins();
    }, [server.uuid]);

    const loadFeaturedPlugins = async (page = 1) => {
        setLoading(true);
        setSearchState('loading');
        setCurrentPage(page);

        if (activeSearchController.current) activeSearchController.current.abort();
        activeSearchController.current = new AbortController();
        const signal = activeSearchController.current.signal;

        try {
            const params = new URLSearchParams();
            params.set('page', String(page));
            params.set('per_page', String(perPage));
            // get featured (no query)
            const response = await fetch(`/api/client/servers/${server.uuid}/plugins/featured?${params.toString()}`, { signal });
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            const data = await response.json();

            if (data.success && data.data) {
                const featuredPlugins = data.data.hits || [];
                if (!isMounted.current) return;

                setPlugins(featuredPlugins);
                setSearchState(featuredPlugins.length > 0 ? 'initial' : 'empty');

                // read pagination (backend returns pagination metadata)
                if (data.pagination) {
                    setCurrentPage(data.pagination.page || 1);
                    setPerPage(data.pagination.per_page || perPage);
                    setTotalPages(data.pagination.total_pages || 1);
                    setTotalHits(data.pagination.total_hits || 0);
                } else {
                    // fallback: compute
                    setTotalPages(Math.max(1, Math.ceil((data.total || featuredPlugins.length) / perPage)));
                    setTotalHits(data.total || featuredPlugins.length);
                }
            } else {
                throw new Error(data.error || 'Failed to load featured plugins');
            }
        } catch (err: any) {
            if (err?.name === 'AbortError') return;
            console.error('Error loading featured plugins:', err);
            if (!isMounted.current) return;
            setSearchState('empty');
            setPlugins([]);
        } finally {
            if (isMounted.current) setLoading(false);
        }
    };

    const searchPlugins = async (query: string, page = 1) => {
        // if empty, show featured view
        if (!query.trim()) {
            setSearchState('initial');
            await loadFeaturedPlugins(page);
            return;
        }

        setLoading(true);
        setSearchState('loading');
        setCurrentPage(page);

        // Abort previous
        if (activeSearchController.current) activeSearchController.current.abort();
        activeSearchController.current = new AbortController();
        const signal = activeSearchController.current.signal;

        try {
            const queryParams = new URLSearchParams({
                q: query,
                page: String(page),
                per_page: String(perPage),
            });

            // Only set sort param if not relevance (backend expects no 'sort' for relevance)
            if (filters.sort && filters.sort !== 'relevance') {
                queryParams.set('sort', filters.sort);
            }

            // If category supplied, send it as 'category' param for backend to map to facets
            if (filters.category) queryParams.set('category', filters.category);

            const url = `/api/client/servers/${server.uuid}/plugins/search?${queryParams.toString()}`;

            const response = await fetch(url, { signal });
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            const data = await response.json();

            if (data.success && data.data) {
                if (!isMounted.current) return;
                const hits = data.data.hits || [];
                setPlugins(hits);
                setSearchState(hits.length > 0 ? 'results' : 'empty');

                if (data.pagination) {
                    setCurrentPage(data.pagination.page || page);
                    setPerPage(data.pagination.per_page || perPage);
                    setTotalPages(data.pagination.total_pages || 1);
                    setTotalHits(data.pagination.total_hits || 0);
                } else {
                    // compute fallback
                    setTotalPages(Math.max(1, Math.ceil((data.total || hits.length) / perPage)));
                    setTotalHits(data.total || hits.length);
                }
            } else {
                throw new Error(data.error || 'Search failed');
            }
        } catch (err: any) {
            if (err?.name === 'AbortError') return;
            console.error('Error searching plugins:', err);
            if (!isMounted.current) return;
            setSearchState('empty');
            setPlugins([]);
        } finally {
            if (isMounted.current) setLoading(false);
        }
    };

    useEffect(() => {
        // initial load
        loadFeaturedPlugins(1);
        // cleanup abort controller on unmount
        return () => {
            if (activeSearchController.current) activeSearchController.current.abort();
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    // Debounced search when searchQuery or filters change
    useEffect(() => {
        const id = setTimeout(() => {
            // always reset to first page on filter changes/search changes
            setCurrentPage(1);
            searchPlugins(searchQuery, 1);
        }, 450);

        return () => clearTimeout(id);
    // include filters.sort and filters.category so changes re-trigger search
    }, [searchQuery, filters.sort, filters.category]);

    // effect when perPage changes: reload current view
    useEffect(() => {
        // refresh current search / featured with new perPage
        if (searchQuery.trim()) {
            searchPlugins(searchQuery, 1);
        } else {
            loadFeaturedPlugins(1);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [perPage]);

    // simulate progress helper
    const simulateProgress = (pluginId: string) => {
        let progress = 0;
        const interval = setInterval(() => {
            progress += Math.random() * 15;
            if (progress >= 90) {
                clearInterval(interval);
            }
            if (isMounted.current) setInstallProgress(prev => ({ ...prev, [pluginId]: Math.min(progress, 90) }));
        }, 200);

        return interval;
    };

    const handlePluginInstall = async (plugin: any) => {
        const pluginId = plugin.project_id || plugin.id || plugin.slug || plugin.title;
        // Set installing state and reset progress
        setInstallingPlugins(prev => ({ ...prev, [pluginId]: true }));
        setInstallProgress(prev => ({ ...prev, [pluginId]: 0 }));

        const progressInterval = simulateProgress(pluginId);

        try {
            // Get details from backend (which will provide compatible version if available)
            const detailsUrl = `/api/client/servers/${server.uuid}/plugins/${encodeURIComponent(pluginId)}`;
            const detailsResponse = await fetch(detailsUrl);
            if (!detailsResponse.ok) throw new Error(`HTTP error! status: ${detailsResponse.status}`);
            const details = await detailsResponse.json();

            if (details.success) {
                let versionId: string | undefined;
                let useLatest = false;

                if (details.compatible_version) {
                    versionId = details.compatible_version.id;
                } else {
                    useLatest = confirm(
                        'No compatible version found for your server version. ' +
                        'Would you like to install the latest version anyway? ' +
                        'This might not work with your server version.'
                    );

                    if (useLatest && details.versions && details.versions.length > 0) {
                        versionId = details.versions[0].id;
                    } else {
                        throw new Error('No compatible version available');
                    }
                }

                // Get CSRF token
                const csrfToken = getCsrfToken();

                const installResponse = await fetch(`/api/client/servers/${server.uuid}/plugins/install`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest',
                        'X-CSRF-TOKEN': csrfToken,
                    },
                    body: JSON.stringify({
                        version_id: versionId!,
                        plugin_name: plugin.slug || plugin.title || pluginId
                    })
                });

                // Complete progress
                clearInterval(progressInterval);
                if (isMounted.current) setInstallProgress(prev => ({ ...prev, [pluginId]: 100 }));

                if (!installResponse.ok) {
                    throw new Error(`HTTP error! status: ${installResponse.status}`);
                }

                const result = await installResponse.json();

                if (result.success) {
                    // Mark as installed using stable id (project_id or pluginId)
                    setInstalledPlugins(prev => ({ ...prev, [plugin.project_id || plugin.id || plugin.slug || pluginId]: true }));

                    // Reset installing state after a short delay
                    setTimeout(() => {
                        if (!isMounted.current) return;
                        setInstallingPlugins(prev => ({ ...prev, [pluginId]: false }));
                        setInstallProgress(prev => ({ ...prev, [pluginId]: 0 }));
                    }, 1200);
                } else {
                    throw new Error(result.error || 'Installation failed');
                }
            } else {
                throw new Error(details.error || 'Failed to get plugin details');
            }
        } catch (err) {
            console.error('Installation failed:', err);
            clearInterval(progressInterval);
            if (isMounted.current) {
                setInstallingPlugins(prev => ({ ...prev, [pluginId]: false }));
                setInstallProgress(prev => ({ ...prev, [pluginId]: 0 }));
            }
            alert(`Installation failed: ${err instanceof Error ? err.message : 'Unknown error'}`);
        }
    };

    const formatNumber = (num: number): string => {
        if (!num && num !== 0) return '0';
        if (num >= 1000000) {
            return (num / 1000000).toFixed(1) + 'M';
        } else if (num >= 1000) {
            return (num / 1000).toFixed(1) + 'K';
        }
        return num.toString();
    };

    const getButtonText = (plugin: any) => {
        const pluginId = plugin.project_id || plugin.id || plugin.slug || plugin.title;
        if (installedPlugins[pluginId]) return 'Installed';
        if (installingPlugins[pluginId]) return 'Installing...';
        return 'Install';
    };

    const getButtonIcon = (plugin: any) => {
        const pluginId = plugin.project_id || plugin.id || plugin.slug || plugin.title;
        if (installedPlugins[pluginId]) return RiCheckLine;
        if (installingPlugins[pluginId]) return InstallSpinner;
        return RiDownloadLine;
    };

    const isFeatured = (plugin: any) => {
        // Simple heuristic: plugins with high downloads are considered featured
        return (plugin.downloads || plugin.download_count || 0) > 100000;
    };

    /* Modal: load plugin details and show */
    const openPluginModal = async (plugin: any) => {
        const pluginId = plugin.project_id || plugin.id || plugin.slug || plugin.title;
        setModalPlugin(null);
        setModalOpen(true);
        setModalLoading(true);

        try {
            const response = await fetch(`/api/client/servers/${server.uuid}/plugins/${encodeURIComponent(pluginId)}`);
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            const data = await response.json();
            if (data.success) {
                if (!isMounted.current) return;
                // Backend returns project/versions; unify a bit
                setModalPlugin({
                    project: data.plugin || data.project || plugin,
                    versions: data.versions || data.versions || [],
                    compatible_version: data.compatible_version || null,
                    raw: data
                });
            } else {
                throw new Error(data.error || 'Failed to fetch plugin details');
            }
        } catch (err) {
            console.error('Failed to open plugin modal:', err);
            if (!isMounted.current) return;
            setModalPlugin({ error: err instanceof Error ? err.message : 'Failed to load details', raw: null });
        } finally {
            if (isMounted.current) setModalLoading(false);
        }
    };

    const closeModal = () => {
        setModalOpen(false);
        setModalPlugin(null);
        setModalLoading(false);
    };

    /** Pagination helpers */
    const handlePageChange = (page: number) => {
        if (page < 1 || page > totalPages) return;
        setCurrentPage(page);

        if (!searchQuery.trim()) {
            loadFeaturedPlugins(page);
        } else {
            searchPlugins(searchQuery, page);
        }
    };

    const renderPagination = () => {
        if (totalPages <= 1) return null;

        // show a compact set of page numbers centered around current page
        const maxButtons = 7;
        let start = Math.max(1, currentPage - Math.floor(maxButtons / 2));
        let end = start + maxButtons - 1;
        if (end > totalPages) {
            end = totalPages;
            start = Math.max(1, end - maxButtons + 1);
        }

        const pages = [];
        for (let p = start; p <= end; p++) pages.push(p);

        return (
            <div className="flex items-center justify-center mt-6 space-x-2">
                <Button variant={'alt'} onClick={() => handlePageChange(currentPage - 1)} disabled={currentPage === 1}>
                    <RiArrowLeftSLine />
                </Button>

                {start > 1 && (
                    <>
                        <Button variant={'alt'} onClick={() => handlePageChange(1)}>1</Button>
                        {start > 2 && <div className="px-2 text-gray-400">…</div>}
                    </>
                )}

                {pages.map(p => (
                    <Button key={p} variant={p === currentPage ? 'primary' : 'alt'} onClick={() => handlePageChange(p)}>
                        {p}
                    </Button>
                ))}

                {end < totalPages && (
                    <>
                        {end < totalPages - 1 && <div className="px-2 text-gray-400">…</div>}
                        <Button variant={'alt'} onClick={() => handlePageChange(totalPages)}>{totalPages}</Button>
                    </>
                )}

                <Button variant={'alt'} onClick={() => handlePageChange(currentPage + 1)} disabled={currentPage === totalPages}>
                    <RiArrowRightSLine />
                </Button>
            </div>
        );
    };

    return (
        <TitledGreyBox title={'Plugin Marketplace'}>
            {/* Search Input */}
            <SearchContainer>
                <div className="relative">
                    <Input
                        type="text"
                        value={searchQuery}
                        onChange={e => setSearchQuery(e.currentTarget.value)}
                        placeholder="Search thousands of Minecraft plugins..."
                        icon={RiSearchLine}
                        css={tw`bg-gray-800/50 border-gray-600 backdrop-blur-sm`}
                    />
                    {!searchQuery && (
                        <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                            <div className="flex items-center space-x-1 text-xs text-gray-400 bg-gray-700/50 px-2 py-1 rounded">
                                <RiStarFill className="text-yellow-400" />
                                <span>Featured Plugins</span>
                            </div>
                        </div>
                    )}
                </div>
            </SearchContainer>

            {/* Search Results */}
            <div>
                {/* Featured/Initial State */}
                {searchState === 'initial' && !loading && (
                    <div>
                        <div className="flex items-center justify-between mb-6">
                            <div>
                                <h3 className="text-2xl font-bold text-gray-50 mb-2">Featured Plugins</h3>
                                <p className="text-gray-400">Popular plugins curated for your server</p>
                            </div>
                            <div className="text-sm text-gray-400">
                                {totalHits} featured {totalHits === 1 ? 'plugin' : 'plugins'}
                            </div>
                        </div>
                        {plugins.length > 0 ? (
                            <>
                            <PluginGrid>
                                {plugins.map((plugin) => {
                                    const id = plugin.project_id || plugin.id || plugin.slug || plugin.title;
                                    return (
                                        <PluginCard key={id}>
                                            <PluginIconContainer>
                                                <div className="flex items-start space-x-3 mb-3">
                                                    {plugin.icon_url ? (
                                                        <img
                                                            src={plugin.icon_url}
                                                            alt={plugin.title}
                                                            className="w-12 h-12 rounded-lg object-cover border border-gray-600"
                                                        />
                                                    ) : (
                                                        <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center border border-gray-600">
                                                            <RiBox3Line className="text-gray-50 text-xl" />
                                                        </div>
                                                    )}
                                                    <div className="flex-1 min-w-0">
                                                        <h4 className="font-bold text-gray-50 truncate text-sm leading-tight">
                                                            {plugin.title}
                                                        </h4>
                                                        <p className="text-gray-400 text-xs truncate mt-1">
                                                            by {plugin.author || plugin.author?.username || 'Unknown'}
                                                        </p>
                                                    </div>
                                                </div>
                                            </PluginIconContainer>

                                            <p className="text-gray-300 text-xs mb-4 line-clamp-3 leading-relaxed">
                                                {plugin.description || 'No description available.'}
                                            </p>

                                            <StatsContainer className="mb-4">
                                                <div className="flex items-center space-x-3">
                                                    <StatItem>
                                                        <RiDownloadLine size={12} />
                                                        <span>{formatNumber(plugin.downloads || plugin.download_count || 0)}</span>
                                                    </StatItem>
                                                    <StatItem>
                                                        <RiInformationLine size={12} />
                                                        <span>{plugin.date_created ? new Date(plugin.date_created).getFullYear() : '—'}</span>
                                                    </StatItem>
                                                </div>
                                                <CategoryBadge type='plugin'>
                                                    plugin
                                                </CategoryBadge>
                                            </StatsContainer>

                                            <div className="flex items-center space-x-2 mt-auto">
                                                <Button
                                                    onClick={() => openPluginModal(plugin)}
                                                    variant={'alt'}
                                                    css={tw`w-full`}
                                                >
                                                    <RiInformationLine className="mr-2" />
                                                    Details
                                                </Button>

                                                <InstallButton
                                                    onClick={() => handlePluginInstall(plugin)}
                                                    installing={installingPlugins[id]}
                                                    installed={installedPlugins[id]}
                                                    disabled={installingPlugins[id] || installedPlugins[id]}
                                                    css={tw`w-36`}
                                                >
                                                    {React.createElement(getButtonIcon(plugin), {
                                                        className: `mr-2 ${installingPlugins[id] ? '' : ''}`
                                                    })}
                                                    {getButtonText(plugin)}
                                                    {installingPlugins[id] && (
                                                        <LoadingBar progress={installProgress[id] || 0} />
                                                    )}
                                                </InstallButton>
                                            </div>
                                        </PluginCard>
                                    );
                                })}
                            </PluginGrid>

                            {/* Pagination intentionally hidden on Featured page (initial state) */}

                            </>
                        ) : (
                            <EmptyState>
                                <RiBox3Line className="text-gray-400 text-5xl mx-auto mb-4" />
                                <h3 className="text-xl font-bold text-gray-200 mb-2">No Featured Plugins</h3>
                                <p className="text-gray-400 mb-6">
                                    Start searching to discover amazing plugins for your server.
                                </p>
                                <Button onClick={() => setSearchQuery('worldedit')}>
                                    <RiSearchLine className="mr-2" />
                                    Explore Popular Plugins
                                </Button>
                            </EmptyState>
                        )}
                    </div>
                )}

                {/* Loading State - Now with Advanced Placeholders */}
                {(searchState === 'loading' || loading) && (
                    <div>
                        <div className="flex items-center justify-between mb-6">
                            <div>
                                <h3 className="text-2xl font-bold text-gray-50 mb-2">
                                    {searchQuery ? `Searching for "${searchQuery}"` : 'Loading Featured Plugins'}
                                </h3>
                                <p className="text-gray-400">
                                    {searchQuery ? 'Finding the best plugins for you...' : 'Loading curated plugins...'}
                                </p>
                            </div>
                        </div>
                        <PluginPlaceholders count={9} />
                    </div>
                )}

                {/* Results Grid */}
                {searchState === 'results' && searchQuery && (
                    <div>
                        <div className="flex items-center justify-between mb-6">
                            <div>
                                <h3 className="text-2xl font-bold text-gray-50 mb-2">
                                    Search Results for "{searchQuery}"
                                </h3>
                                <p className="text-gray-400">
                                    Found {totalHits} results — showing {plugins.length} on this page
                                </p>
                            </div>
                        </div>
                        <PluginGrid>
                            {plugins.map((plugin) => {
                                const id = plugin.project_id || plugin.id || plugin.slug || plugin.title;
                                return (
                                    <PluginCard key={id}>
                                        <PluginIconContainer>
                                            {isFeatured(plugin) && (
                                                <FeaturedBadge>
                                                    <RiStarFill size={10} />
                                                    <span>Featured</span>
                                                </FeaturedBadge>
                                            )}
                                            <div className="flex items-start space-x-3 mb-3">
                                                {plugin.icon_url ? (
                                                    <img
                                                        src={plugin.icon_url}
                                                        alt={plugin.title}
                                                        className="w-12 h-12 rounded-lg object-cover border border-gray-600"
                                                    />
                                                ) : (
                                                    <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center border border-gray-600">
                                                        <RiBox3Line className="text-gray-50 text-xl" />
                                                    </div>
                                                )}
                                                <div className="flex-1 min-w-0">
                                                    <h4 className="font-bold text-gray-50 truncate text-sm leading-tight">
                                                        {plugin.title}
                                                    </h4>
                                                    <p className="text-gray-400 text-xs truncate mt-1">
                                                        by {plugin.author || plugin.author?.username || 'Unknown'}
                                                    </p>
                                                </div>
                                            </div>
                                        </PluginIconContainer>

                                        <p className="text-gray-300 text-xs mb-4 line-clamp-3 leading-relaxed">
                                            {plugin.description || 'No description available.'}
                                        </p>

                                        <StatsContainer className="mb-4">
                                            <div className="flex items-center space-x-3">
                                                <StatItem>
                                                    <RiDownloadLine size={12} />
                                                    <span>{formatNumber(plugin.downloads || plugin.download_count || 0)}</span>
                                                </StatItem>
                                                <StatItem>
                                                    <RiInformationLine size={12} />
                                                    <span>{plugin.date_created ? new Date(plugin.date_created).getFullYear() : '—'}</span>
                                                </StatItem>
                                            </div>
                                            <CategoryBadge type={plugin.project_type || 'plugin'}>
                                                {plugin.project_type || 'plugin'}
                                            </CategoryBadge>
                                        </StatsContainer>

                                        <div className="flex items-center space-x-2 mt-auto">
                                            <Button
                                                onClick={() => openPluginModal(plugin)}
                                                variant={'alt'}
                                                css={tw`w-full`}
                                            >
                                                <RiInformationLine className="mr-2" />
                                                Details
                                            </Button>

                                            <InstallButton
                                                onClick={() => handlePluginInstall(plugin)}
                                                installing={installingPlugins[id]}
                                                installed={installedPlugins[id]}
                                                disabled={installingPlugins[id] || installedPlugins[id]}
                                                css={tw`w-36`}
                                            >
                                                {React.createElement(getButtonIcon(plugin), {
                                                    className: `mr-2 ${installingPlugins[id] ? '' : ''}`
                                                })}
                                                {getButtonText(plugin)}
                                                {installingPlugins[id] && (
                                                    <LoadingBar progress={installProgress[id] || 0} />
                                                )}
                                            </InstallButton>
                                        </div>
                                    </PluginCard>
                                );
                            })}
                        </PluginGrid>

                        {/* pagination */}
                        {renderPagination()}
                    </div>
                )}

                {/* Empty State */}
                {searchState === 'empty' && (
                    <EmptyState>
                        <RiSearchLine className="text-gray-400 text-5xl mx-auto mb-4" />
                        <h3 className="text-xl font-bold text-gray-200 mb-2">No Plugins Found</h3>
                        <p className="text-gray-400 mb-6 max-w-md mx-auto">
                            No plugins found matching "<span className="text-blue-400">{searchQuery}</span>". 
                            Try different keywords or check the spelling.
                        </p>
                        <div className="flex flex-col sm:flex-row gap-3.justify-center">
                            <Button onClick={() => { setSearchQuery(''); }}>
                                <RiStarFill className="mr-2" />
                                View Featured Plugins
                            </Button>
                            <Button onClick={() => setSearchQuery('worldedit')}>
                                <RiSearchLine className="mr-2" />
                                Try Popular Plugins
                            </Button>
                        </div>
                    </EmptyState>
                )}
            </div>

            {/* Plugin Details Modal (rendered into document.body via portal so it's always visible at user's scroll position) */}
            {modalOpen && (
                <ModalPortal>
                    <ModalOverlay onMouseDown={closeModal}>
                        <ModalContent onMouseDown={e => e.stopPropagation()}>
                            <div className="flex items-start justify-between mb-4">
                                <div className="flex items-start space-x-3">
                                    <div className="w-14 h-14 rounded-lg overflow-hidden border border-gray-700 bg-gradient-to-br from-blue-600 to-purple-600">
                                        {modalPlugin?.project?.icon_url ? (
                                            <img src={modalPlugin.project.icon_url} alt={modalPlugin.project.title} className="w-full h-full object-cover" />
                                        ) : (
                                            <div className="w-full h-full flex items-center justify-center text-white">
                                                <RiBox3Line />
                                            </div>
                                        )}
                                    </div>
                                    <div>
                                        <h3 className="text-lg font-bold text-gray-50">
                                            {modalPlugin?.project?.title || 'Plugin Details'}
                                        </h3>
                                        <p className="text-gray-400 text-sm mt-1">
                                            by {modalPlugin?.project?.author || modalPlugin?.project?.author?.username || 'Unknown'}
                                        </p>
                                    </div>
                                </div>
                                <button onClick={closeModal} className="text-gray-300 hover:text-gray-100 p-2">
                                    <RiCloseLine />
                                </button>
                            </div>

                            {modalLoading && (
                                <div className="space-y-4 py-4">
                                    <PlaceholderText width="100%" height="16px" />
                                    <PlaceholderText width="90%" height="16px" />
                                    <PlaceholderText width="80%" height="16px" />
                                    <div className="grid grid-cols-2 gap-4 mt-6">
                                        <PlaceholderText width="100%" height="20px" />
                                        <PlaceholderText width="100%" height="20px" />
                                    </div>
                                    <div className="mt-6 space-y-2">
                                        {Array.from({ length: 3 }).map((_, i) => (
                                            <PlaceholderText key={i} width="100%" height="40px" />
                                        ))}
                                    </div>
                                </div>
                            )}

            {!modalLoading && modalPlugin && modalPlugin.error && (
                <div className="p-4 bg-red-500/10 border border-red-500/20 rounded text-red-200">
                    <strong>Error:</strong> {modalPlugin.error}
                </div>
            )}

            {!modalLoading && modalPlugin && !modalPlugin.error && (
                <div>
                    <p className="text-gray-300 text-sm mb-4 whitespace-pre-wrap">
                        {modalPlugin.project?.description || 'No description available.'}
                    </p>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <h4 className="text-gray-400 text-xs uppercase mb-2">Downloads</h4>
                            <div className="text-gray-50 font-bold">
                                {formatNumber(modalPlugin.project?.downloads || modalPlugin.project?.download_count || 0)}
                            </div>
                        </div>

                        <div>
                            <h4 className="text-gray-400 text-xs uppercase mb-2">Latest Version</h4>
                            <div className="text-gray-50 font-bold">
                                {modalPlugin.versions && modalPlugin.versions.length > 0 ? (modalPlugin.versions[0].version_number || modalPlugin.versions[0].name || modalPlugin.versions[0].id) : 'Unknown'}
                            </div>
                        </div>

                        <div className="md:col-span-2 mt-4">
                            <h4 className="text-gray-400 text-xs uppercase mb-2">Versions</h4>
                            <div className="space-y-2 max-h-48 overflow-auto pr-2">
                                {(modalPlugin.versions && modalPlugin.versions.length > 0) ? modalPlugin.versions.map((v: any) => (
                                    <div key={v.id} className="flex items-center justify-between p-2 bg-gray-800/40 rounded border border-gray-700 text-sm">
                                        <div className="truncate">
                                            <div className="font-medium text-gray-100">{v.version_number || v.name || v.id}</div>
                                            <div className="text-gray-400 text-xs">{(v.game_versions || v.game_versions?.join?.(', ') || []).slice(0, 5).join(', ')}</div>
                                        </div>
                                        <div className="text-gray-300 text-xs">
                                            {v.date_published ? new Date(v.date_published).toLocaleDateString() : ''}
                                        </div>
                                    </div>
                                )) : (
                                    <div className="text-gray-400 text-sm">No version data available.</div>
                                )}
                            </div>
                        </div>
                    </div>

                    <div className="flex items-center justify-end mt-6 space-x-3">
                        <Button onClick={() => {
                            // attempt to install compatible version directly if available
                            const versionId = modalPlugin.compatible_version?.id || (modalPlugin.versions && modalPlugin.versions[0]?.id);
                            if (!versionId) {
                                alert('No installable version available');
                                return;
                            }
                            // build a minimal plugin-like object for install handler
                            const pseudo = { project_id: modalPlugin.project?.project_id || modalPlugin.project?.id || modalPlugin.project?.slug, slug: modalPlugin.project?.slug, title: modalPlugin.project?.title };
                            closeModal();
                            handlePluginInstall({ ...pseudo });
                        }}>
                            <RiDownloadLine className="mr-2" />
                            Install
                        </Button>
                        <Button onClick={closeModal} variant={'secondary'}>
                            Close
                        </Button>
                    </div>
                </div>
            )}
                        </ModalContent>
                    </ModalOverlay>
                </ModalPortal>
            )}
        </TitledGreyBox>
    );
};