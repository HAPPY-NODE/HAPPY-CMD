import React, { Suspense } from 'react';
import styled, { css, keyframes } from 'styled-components/macro';
import tw from 'twin.macro';
import ErrorBoundary from '@/components/elements/ErrorBoundary';

export type SpinnerSize = 'small' | 'base' | 'large';

interface Props {
    size?: SpinnerSize;
    centered?: boolean;
    isBlue?: boolean;
}

interface Spinner extends React.FC<Props> {
    Size: Record<'SMALL' | 'BASE' | 'LARGE', SpinnerSize>;
    Suspense: React.FC<Props>;
}

// Bar animation keyframes
const barAnimation = keyframes<Props>`
    0% { 
        transform: scaleY(0.1); 
        background-color: ${(props) => (!props.isBlue ? 'rgba(255, 255, 255, 0.2)' : 'hsla(212, 92%, 43%, 0.2)')}; 
    }
    50% { 
        transform: scaleY(1); 
        background-color: ${(props) => (!props.isBlue ? 'rgb(255, 255, 255)' : 'hsl(212, 92%, 43%)')}; 
    }
    100% { 
        transform: scaleY(0.1); 
        background-color: ${(props) => (!props.isBlue ? 'rgba(255, 255, 255, 0.2)' : 'hsla(212, 92%, 43%, 0.2)')}; 
    }
`;

const BarLoaderContainer = styled.div<Props>`
    ${tw`flex items-center justify-center`};
    width: ${(props) => {
        switch (props.size) {
            case 'small': return '30px';
            case 'large': return '90px';
            default: return '60px';
        }
    }};
    height: ${(props) => {
        switch (props.size) {
            case 'small': return '15px';
            case 'large': return '30px';
            default: return '20px';
        }
    }};
`;

const Bar = styled.div<Props>`
    ${tw`mx-1`};
    animation: ${barAnimation} 1.2s infinite ease-in-out;
    width: ${(props) => {
        switch (props.size) {
            case 'small': return '2px';
            case 'large': return '6px';
            default: return '4px';
        }
    }};
    height: 100%;
    border-radius: 2px;
    background-color: ${(props) => (!props.isBlue ? 'rgba(255, 255, 255, 0.2)' : 'hsla(212, 92%, 43%, 0.2)')};

    &:nth-child(1) { animation-delay: -1.2s; }
    &:nth-child(2) { animation-delay: -1.1s; }
    &:nth-child(3) { animation-delay: -1.0s; }
    &:nth-child(4) { animation-delay: -0.9s; }
    &:nth-child(5) { animation-delay: -0.8s; }
`;

const BarLoader: React.FC<Props> = ({ size = 'base', isBlue = false }) => (
    <BarLoaderContainer size={size}>
        <Bar size={size} isBlue={isBlue} />
        <Bar size={size} isBlue={isBlue} />
        <Bar size={size} isBlue={isBlue} />
        <Bar size={size} isBlue={isBlue} />
        <Bar size={size} isBlue={isBlue} />
    </BarLoaderContainer>
);

const Spinner: Spinner = ({ centered, size = 'base', isBlue = false, ...props }) =>
    centered ? (
        <div css={[tw`flex justify-center items-center`, size === 'large' ? tw`m-20` : tw`m-6`]}>
            <BarLoader size={size} isBlue={isBlue} {...props} />
        </div>
    ) : (
        <BarLoader size={size} isBlue={isBlue} {...props} />
    );

Spinner.displayName = 'Spinner';

Spinner.Size = {
    SMALL: 'small',
    BASE: 'base',
    LARGE: 'large',
};

Spinner.Suspense = ({ children, centered = true, size = Spinner.Size.LARGE, ...props }) => (
    <Suspense fallback={<Spinner centered={centered} size={size} {...props} />}>
        <ErrorBoundary>{children}</ErrorBoundary>
    </Suspense>
);

Spinner.Suspense.displayName = 'Spinner.Suspense';

export default Spinner;