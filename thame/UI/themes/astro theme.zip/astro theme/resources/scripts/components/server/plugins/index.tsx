import React from 'react';
import { createRoot } from 'react-dom/client';
import PluginManager from './components/PluginManagerContainer';

const container = document.getElementById('plugin-manager-root');
if (container) {
    const root = createRoot(container);
    root.render(<PluginManager />);
}