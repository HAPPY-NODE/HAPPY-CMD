import React, { useEffect, useRef, useState } from 'react';
import { Link, RouteComponentProps } from 'react-router-dom';
import login from '@/api/auth/login';
import LoginFormContainer from '@/components/auth/LoginFormContainer';
import { useStoreState } from 'easy-peasy';
import { Formik, FormikHelpers } from 'formik';
import { object, string } from 'yup';
import Field from '@/components/elements/Field';
import tw from 'twin.macro';
import Button from '@/components/elements/Button';
import Reaptcha from 'reaptcha';
import useFlash from '@/plugins/useFlash';

interface Values {
  username: string;
  password: string;
}

const LoginContainer = ({ history }: RouteComponentProps) => {
  const ref = useRef<Reaptcha>(null);
  const [token, setToken] = useState('');

  const { clearFlashes, clearAndAddHttpError } = useFlash();
  const { enabled: recaptchaEnabled, siteKey } = useStoreState((state) => state.settings.data!.recaptcha);

  useEffect(() => {
    clearFlashes();
  }, []);

  const onSubmit = (values: Values, { setSubmitting }: FormikHelpers<Values>) => {
    clearFlashes();

    if (recaptchaEnabled && !token) {
      ref.current!.execute().catch((error) => {
        console.error(error);
        setSubmitting(false);
        clearAndAddHttpError({ error });
      });
      return;
    }

    login({ ...values, recaptchaData: token })
      .then((response) => {
        if (response.complete) {
          window.location = response.intended || '/';
          return;
        }

        history.replace('/auth/login/checkpoint', { token: response.confirmationToken });
      })
      .catch((error) => {
        console.error(error);
        setToken('');
        if (ref.current) ref.current.reset();
        setSubmitting(false);
        clearAndAddHttpError({ error });
      });
  };

  return (
    <Formik
      onSubmit={onSubmit}
      initialValues={{ username: '', password: '' }}
      validationSchema={object().shape({
        username: string().required('A username or email must be provided.'),
        password: string().required('Please enter your account password.'),
      })}
    >
      {({ isSubmitting, setSubmitting, submitForm }) => (
        <LoginFormContainer title={'Welcome Back'} css={tw`w-full flex`}>
          <div css={tw`mb-6`}>
            <Field
              type={'text'}
              label={'Username or Email'}
              name={'username'}
              disabled={isSubmitting}
              css={tw`w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-neutral-400 
                     focus:bg-white/10 focus:border-blue-400/50 focus:ring-2 focus:ring-blue-400/20 
                     transition-all duration-300 backdrop-blur-sm`}
            />
          </div>
          
          <div css={tw`mb-6`}>
            <Field
              type={'password'}
              label={'Password'}
              name={'password'}
              disabled={isSubmitting}
              css={tw`w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-neutral-400 
                     focus:bg-white/10 focus:border-blue-400/50 focus:ring-2 focus:ring-blue-400/20 
                     transition-all duration-300 backdrop-blur-sm`}
            />
          </div>
          
          <div css={tw`mb-6`}>
            <Button 
              type={'submit'} 
              size={'xlarge'} 
              isLoading={isSubmitting} 
              disabled={isSubmitting}
              css={tw`w-full py-3 bg-gradient-to-r from-blue-500 to-blue-600 border-0 rounded-xl
                     hover:from-blue-600 hover:to-blue-700 hover:shadow-lg hover:shadow-xl
                     active:scale-95 transform transition-all duration-300
                     backdrop-blur-md font-medium`}
            >
              {isSubmitting ? 'Authenticating...' : 'Login'}
            </Button>
          </div>
          
          {recaptchaEnabled && (
            <Reaptcha
              ref={ref}
              size={'invisible'}
              sitekey={siteKey || '_invalid_key'}
              onVerify={(response) => {
                setToken(response);
                submitForm();
              }}
              onExpire={() => {
                setSubmitting(false);
                setToken('');
              }}
            />
          )}
          
          <div css={tw`mt-6 text-center`}>
            <Link
              to={'/auth/password'}
              css={tw`text-sm text-neutral-400 no-underline hover:text-blue-300 transition-colors duration-300`}
            >
              Forgot password?
            </Link>
          </div>
        </LoginFormContainer>
      )}
    </Formik>
  );
};

export default LoginContainer;