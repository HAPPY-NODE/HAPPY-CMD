import React, { memo, useEffect, useRef, useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEthernet, faHdd, faMemory, faMicrochip, faServer, faCircle } from '@fortawesome/free-solid-svg-icons';
import { Link } from 'react-router-dom';
import { Server } from '@/api/server/getServer';
import getServerResourceUsage, { ServerPowerState, ServerStats } from '@/api/server/getServerResourceUsage';
import { bytesToString, ip, mbToBytes } from '@/lib/formatters';
import tw from 'twin.macro';
import Spinner from '@/components/elements/Spinner';
import styled, { keyframes, css } from 'styled-components/macro';
import isEqual from 'react-fast-compare';
import getServerNestInfo from '@/api/server/getServerNestInfo';
import axios from 'axios';

const customBg = '#0f1117';
const customAccent = '#3b82f6';
const customAccentHover = '#2563eb';
const customCardBg = 'rgba(30, 30, 46, 0.7)';

const fadeInUp = keyframes`
  from { 
    opacity: 0; 
    transform: translateY(15px) scale(0.98); 
  }
  to { 
    opacity: 1; 
    transform: translateY(0) scale(1); 
  }
`;

const ServerCard = styled(Link)<{ $status: ServerPowerState | undefined; $viewMode: 'grid' | 'list'; $delay: number }>`
  ${tw`relative flex transition-all duration-300 overflow-hidden backdrop-blur-lg`}
  ${({ $viewMode }) => $viewMode === 'grid'
    ? tw`p-4 rounded-2xl flex-col border border-opacity-10`
    : tw`p-5 rounded-xl flex-row items-center border border-opacity-10`}
  
  background: ${customCardBg};
  border-color: rgba(255, 255, 255, 0.1);
  color: white;
  opacity: 0;
  animation: ${fadeInUp} 0.4s ease-out forwards;
  animation-delay: ${({ $delay }) => $delay * 0.08}s;
  
  /* Subtle gradient overlay */
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 1px;
    background: linear-gradient(90deg, transparent, ${customAccent}, transparent);
    opacity: 0;
    transition: opacity 0.3s ease;
  }

  &:hover {
    transform: translateY(-2px);
    border-color: ${customAccent};
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
    
    &::before {
      opacity: 1;
    }
  }

  /* Status Indicator - Grid View */
  ${({ $viewMode }) => $viewMode === 'grid' && css`
    .status-indicator {
      ${tw`absolute top-3 right-4 flex items-center gap-2`}
      .status-badge {
        ${tw`px-3 py-1.5 rounded-full text-xs font-medium flex items-center gap-2 backdrop-blur-sm`}
        background: rgba(15, 23, 42, 0.8);
        border: 1px solid rgba(255, 255, 255, 0.1);
        
        .status-dot {
          ${tw`w-2 h-2 rounded-full`}
          background-color: ${({ $status }) =>
            !$status || $status === 'offline' ? '#ef4444'
              : $status === 'running' ? '#10b981'
              : '#f59e0b'};
          box-shadow: 0 0 8px ${({ $status }) =>
            !$status || $status === 'offline' ? 'rgba(239, 68, 68, 0.4)'
              : $status === 'running' ? 'rgba(16, 185, 129, 0.4)'
              : 'rgba(245, 158, 11, 0.4)'};
        }
      }
    }
  `}

  /* Status Indicator - List View */
  ${({ $viewMode }) => $viewMode === 'list' && css`
    .status-indicator {
      ${tw`flex items-center gap-3 ml-4`}
      .status-pill {
        ${tw`px-4 py-2 rounded-full text-sm font-medium flex items-center gap-2 backdrop-blur-sm`}
        background: rgba(15, 23, 42, 0.8);
        border: 1px solid rgba(255, 255, 255, 0.1);
        min-width: 100px;
        justify-content: center;
        
        .status-dot {
          ${tw`w-2.5 h-2.5 rounded-full`}
          background-color: ${({ $status }) =>
            !$status || $status === 'offline' ? '#ef4444'
              : $status === 'running' ? '#10b981'
              : '#f59e0b'};
          box-shadow: 0 0 10px ${({ $status }) =>
            !$status || $status === 'offline' ? 'rgba(239, 68, 68, 0.4)'
              : $status === 'running' ? 'rgba(16, 185, 129, 0.4)'
              : 'rgba(245, 158, 11, 0.4)'};
        }
      }
    }
  `}
`;

const StatBox = styled.div<{ $alarm: boolean; $viewMode: 'grid' | 'list' }>`
  ${tw`flex items-center p-3 rounded-lg transition-all duration-300 backdrop-blur-sm`}
  background: rgba(15, 23, 42, 0.6);
  border: 1px solid ${({ $alarm }) => $alarm ? 'rgba(239, 68, 68, 0.3)' : 'rgba(255,255,255,0.08)'};
  
  &:hover {
    background: rgba(15, 23, 42, 0.8);
    border-color: ${({ $alarm }) => $alarm ? '#ef4444' : customAccent};
    transform: translateY(-1px);
  }
  
  ${({ $viewMode }) => $viewMode === 'list' && tw`h-14`}
`;

const ServerInfo = styled.div<{ $viewMode: 'grid' | 'list' }>`
  ${tw`text-sm text-gray-400`}
  ${({ $viewMode }) => $viewMode === 'list' && tw`flex items-center gap-3`}
`;

const Icon = styled(FontAwesomeIcon)<{ $alarm: boolean }>`
  ${tw`w-4 h-4 mr-3 transition-colors duration-300`}
  color: ${({ $alarm }) => $alarm ? '#ef4444' : customAccent};
`;

const ServerTitle = styled.div<{ $viewMode: 'grid' | 'list' }>`
  ${tw`flex items-center font-semibold text-gray-100`}
  ${({ $viewMode }) => $viewMode === 'grid'
    ? tw`text-lg mb-2`
    : tw`text-xl mr-6`}
  
  .icon {
    ${tw`mr-3`}
    color: ${customAccent};
    filter: drop-shadow(0 0 8px ${customAccent}40);
  }
`;

const StatRow = styled.div<{ $viewMode: 'grid' | 'list' }>`
  ${({ $viewMode }) => $viewMode === 'grid'
    ? tw`mt-3 grid grid-cols-3 gap-3`
    : tw`flex gap-4 ml-auto`}
`;

const ResourceValue = styled.span<{ $viewMode: 'grid' | 'list' }>`
  ${tw`font-medium text-gray-100`}
  font-size: ${({ $viewMode }) => $viewMode === 'grid' ? '0.875rem' : '0.9rem'};
`;

const ResourceLimit = styled.span<{ $viewMode: 'grid' | 'list' }>`
  ${tw`text-gray-500 ml-1`}
  font-size: ${({ $viewMode }) => $viewMode === 'grid' ? '0.75rem' : '0.8rem'};
`;

const ServerDescription = styled.div`
  ${tw`text-sm text-gray-400 mb-3 leading-relaxed`}
`;

const EggBackground = styled.div<{ $image?: string; $gradientOpacity: number; $viewMode: 'grid' | 'list' }>`
  position: absolute;
  inset: 0;
  background-image: ${({ $image }) => `url(${$image})`};
  background-size: cover;
  background-position: center;
  pointer-events: none;
  transition: all 0.5s ease;
  mask-image: linear-gradient(to bottom, rgba(0,0,0,${({ $gradientOpacity }) => $gradientOpacity * 2}) 0%, rgba(0,0,0,0) 70%);
  -webkit-mask-image: linear-gradient(to bottom, rgba(0,0,0,${({ $gradientOpacity }) => $gradientOpacity * 2}) 0%, rgba(0,0,0,0) 70%);
  filter: brightness(0.4) contrast(1.2) saturate(1.1);
  opacity: 0.4;
  
  ${({ $viewMode, $gradientOpacity }) => $viewMode === 'list' && `
    mask-image: linear-gradient(to right, rgba(0,0,0,${$gradientOpacity * 2}) 0%, rgba(0,0,0,0) 80%);
    -webkit-mask-image: linear-gradient(to right, rgba(0,0,0,${$gradientOpacity * 2}) 0%, rgba(0,0,0,0) 80%);
  `}
  
  ${ServerCard}:hover & { 
    opacity: 0.2;
    transform: scale(1.05);
  }
`;

const ListContent = styled.div`${tw`flex items-center w-full`}`;
const ListLeft = styled.div`${tw`flex-1 flex flex-col md:flex-row md:items-center gap-4`}`;
const ListRight = styled.div`${tw`ml-auto`}`;

// Mobile-specific components
const MobileServerCard = styled(Link)<{ $status: ServerPowerState | undefined; $delay: number }>`
  ${tw`relative flex flex-col p-4 rounded-2xl transition-all duration-300 overflow-hidden backdrop-blur-lg`}
  background: ${customCardBg};
  border: 1px solid rgba(255, 255, 255, 0.1);
  color: white;
  opacity: 0;
  animation: ${fadeInUp} 0.4s ease-out forwards;
  animation-delay: ${({ $delay }) => $delay * 0.08}s;

  &:hover {
    transform: translateY(-2px);
    border-color: ${customAccent};
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
  }
`;

const MobileHeader = styled.div`
  ${tw`flex items-center justify-between mb-3`}
`;

const MobileTitle = styled.div`
  ${tw`flex items-center font-semibold text-gray-100 text-lg`}
  .icon {
    ${tw`mr-3`}
    color: ${customAccent};
  }
`;

const MobileStatus = styled.div<{ $status: ServerPowerState | undefined }>`
  ${tw`px-3 py-1.5 rounded-full text-xs font-medium flex items-center gap-2 backdrop-blur-sm`}
  background: rgba(15, 23, 42, 0.8);
  border: 1px solid rgba(255, 255, 255, 0.1);
  
  .status-dot {
    ${tw`w-2 h-2 rounded-full`}
    background-color: ${({ $status }) =>
      !$status || $status === 'offline' ? '#ef4444'
        : $status === 'running' ? '#10b981'
        : '#f59e0b'};
    box-shadow: 0 0 8px ${({ $status }) =>
      !$status || $status === 'offline' ? 'rgba(239, 68, 68, 0.4)'
        : $status === 'running' ? 'rgba(16, 185, 129, 0.4)'
        : 'rgba(245, 158, 11, 0.4)'};
  }
`;

const MobileResources = styled.div`
  ${tw`grid grid-cols-3 gap-2 mb-3`}
`;

const MobileResourceItem = styled.div<{ $alarm: boolean }>`
  ${tw`flex flex-col items-center p-3 rounded-lg transition-all duration-300 backdrop-blur-sm`}
  background: rgba(15, 23, 42, 0.6);
  border: 1px solid ${({ $alarm }) => $alarm ? 'rgba(239, 68, 68, 0.3)' : 'rgba(255,255,255,0.08)'};

  &:hover {
    background: rgba(15, 23, 42, 0.8);
    border-color: ${({ $alarm }) => $alarm ? '#ef4444' : customAccent};
  }
`;

const MobileResourceValue = styled.span`
  ${tw`font-medium text-gray-100 text-sm mt-1`}
`;

const MobileResourceLabel = styled.span`
  ${tw`text-gray-500 text-xs mt-1`}
`;

const MobileConnectionInfo = styled.div`
  ${tw`flex items-center justify-center p-3 rounded-lg backdrop-blur-sm text-sm text-gray-400`}
  background: rgba(15, 23, 42, 0.6);
  border: 1px solid rgba(255, 255, 255, 0.08);
`;

export default memo(({ server, viewMode, index }: { server: Server; viewMode: 'grid' | 'list'; index: number }) => {
  const interval = useRef<NodeJS.Timeout | null>(null);
  const [isSuspended, setIsSuspended] = useState(server.status === 'suspended');
  const [stats, setStats] = useState<ServerStats | null>(null);
  const [nestId, setNestId] = useState<number | null>(null);
  const [themeSettings, setThemeSettings] = useState<{ nest_backgrounds: Record<number, string>, nest_gradient_opacity: number }>({
    nest_backgrounds: {},
    nest_gradient_opacity: 0.15,
  });

  // Check if mobile
  const [isMobile, setIsMobile] = useState(false);
  
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  useEffect(() => {
    axios.get('/api/client/theme/api')
      .then(res => setThemeSettings({
        nest_backgrounds: res.data.nest_backgrounds || {},
        nest_gradient_opacity: res.data.nest_gradient_opacity ?? 0.15,
      }))
      .catch(console.error);
  }, []);

  useEffect(() => {
    getServerNestInfo(server.uuid)
      .then(data => data?.nest_id && setNestId(data.nest_id))
      .catch(console.error);
  }, [server.uuid]);

  useEffect(() => {
    setIsSuspended(stats?.isSuspended || server.status === 'suspended');
  }, [stats?.isSuspended, server.status]);

  useEffect(() => {
    if (isSuspended) return;
    const fetch = () => getServerResourceUsage(server.uuid).then(setStats).catch(console.error);
    fetch();
    interval.current = setInterval(fetch, 30000);
    return () => interval.current && clearInterval(interval.current);
  }, [isSuspended]);

  const alarms = {
    cpu: stats ? server.limits.cpu !== 0 && stats.cpuUsagePercent >= server.limits.cpu * 0.9 : false,
    memory: stats ? server.limits.memory !== 0 && stats.memoryUsageInBytes >= mbToBytes(server.limits.memory) * 0.9 : false,
    disk: stats ? server.limits.disk !== 0 && stats.diskUsageInBytes >= mbToBytes(server.limits.disk) * 0.9 : false,
  };

  const formatResourceValue = (value: string) => value.endsWith('MiB') ? `${Math.round(parseFloat(value))} MiB` : value;

  const diskLimit = server.limits.disk ? formatResourceValue(bytesToString(mbToBytes(server.limits.disk))) : 'Unlimited';
  const memoryLimit = server.limits.memory ? formatResourceValue(bytesToString(mbToBytes(server.limits.memory))) : 'Unlimited';
  const cpuLimit = server.limits.cpu ? `${server.limits.cpu}%` : 'Unlimited';

  const getStatusText = () => !stats?.status || stats.status === 'offline' ? 'Offline' : stats.status === 'running' ? 'Online' : 'Starting';

  const bgImage = nestId && themeSettings.nest_backgrounds[nestId]
    ? themeSettings.nest_backgrounds[nestId]
    : 'https://images.unsplash.com/photo-1635863138275-d9b33299680a?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80';

  // Mobile Interface
  if (isMobile) {
    return (
      <MobileServerCard 
        to={`/server/${server.id}`} 
        $status={stats?.status} 
        $delay={index}
      >
        <EggBackground $image={bgImage} $gradientOpacity={themeSettings.nest_gradient_opacity} $viewMode="grid" />
        
        <MobileHeader>
          <MobileTitle>
            <FontAwesomeIcon icon={faServer} className="icon" />
            {server.name}
          </MobileTitle>
          <MobileStatus $status={stats?.status}>
            <div className="status-dot" />
            <span>{getStatusText()}</span>
          </MobileStatus>
        </MobileHeader>

        {!!server.description && (
          <ServerDescription>
            {server.description}
          </ServerDescription>
        )}

        <MobileResources>
          {stats ? (
            <>
              <MobileResourceItem $alarm={alarms.cpu}>
                <Icon icon={faMicrochip} $alarm={alarms.cpu} />
                <MobileResourceValue>{stats.cpuUsagePercent.toFixed(1)}%</MobileResourceValue>
                <MobileResourceLabel>/ {cpuLimit}</MobileResourceLabel>
              </MobileResourceItem>
              <MobileResourceItem $alarm={alarms.memory}>
                <Icon icon={faMemory} $alarm={alarms.memory} />
                <MobileResourceValue>
                  {formatResourceValue(bytesToString(stats.memoryUsageInBytes))}
                </MobileResourceValue>
                <MobileResourceLabel>/ {memoryLimit}</MobileResourceLabel>
              </MobileResourceItem>
              <MobileResourceItem $alarm={alarms.disk}>
                <Icon icon={faHdd} $alarm={alarms.disk} />
                <MobileResourceValue>
                  {formatResourceValue(bytesToString(stats.diskUsageInBytes))}
                </MobileResourceValue>
                <MobileResourceLabel>/ {diskLimit}</MobileResourceLabel>
              </MobileResourceItem>
            </>
          ) : isSuspended ? (
            <div className="col-span-3 text-center py-4 text-red-400 text-sm backdrop-blur-sm rounded-lg bg-red-500/10 border border-red-500/20">
              {server.status === 'suspended' ? 'Suspended' : 'Unavailable'}
            </div>
          ) : (
            <div className="col-span-3 flex justify-center items-center py-6">
              <Spinner size="small" />
            </div>
          )}
        </MobileResources>

        <MobileConnectionInfo>
          {server.allocations
            .filter((a) => a.isDefault)
            .map((a) => (
              <div key={a.port} className="flex items-center">
                <FontAwesomeIcon icon={faEthernet} className="mr-2 text-xs" />
                {a.alias || ip(a.ip)}:{a.port}
              </div>
            ))}
        </MobileConnectionInfo>
      </MobileServerCard>
    );
  }

  // Desktop Interface
  if (viewMode === 'grid') {
    return (
      <ServerCard 
        to={`/server/${server.id}`} 
        $status={stats?.status} 
        $viewMode={viewMode}
        $delay={index}
      >
        <EggBackground $image={bgImage} $gradientOpacity={themeSettings.nest_gradient_opacity} $viewMode={viewMode} />
        
        <div className="status-indicator">
          <div className="status-badge">
            <div className="status-dot" />
            <span>{getStatusText()}</span>
          </div>
        </div>
        
        <ServerTitle $viewMode={viewMode}>
          <FontAwesomeIcon icon={faServer} className="icon" />
          {server.name}
        </ServerTitle>

        {!!server.description && (
          <ServerDescription>
            {server.description}
          </ServerDescription>
        )}

        <ServerInfo $viewMode={viewMode}>
          {server.allocations
            .filter((a) => a.isDefault)
            .map((a) => (
              <div key={a.port} className="flex items-center">
                <FontAwesomeIcon icon={faEthernet} className="mr-2 text-xs" />
                {a.alias || ip(a.ip)}:{a.port}
              </div>
            ))}
        </ServerInfo>

        <StatRow $viewMode={viewMode}>
          {stats ? (
            <>
              <StatBox $alarm={alarms.cpu} $viewMode={viewMode}>
                <Icon icon={faMicrochip} $alarm={alarms.cpu} />
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-center">
                    <ResourceValue $viewMode={viewMode}>{stats.cpuUsagePercent.toFixed(1)}%</ResourceValue>
                    <ResourceLimit $viewMode={viewMode}>/ {cpuLimit}</ResourceLimit>
                  </div>
                </div>
              </StatBox>
              <StatBox $alarm={alarms.memory} $viewMode={viewMode}>
                <Icon icon={faMemory} $alarm={alarms.memory} />
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-center">
                    <ResourceValue $viewMode={viewMode}>
                      {formatResourceValue(bytesToString(stats.memoryUsageInBytes))}
                    </ResourceValue>
                    <ResourceLimit $viewMode={viewMode}>/ {memoryLimit}</ResourceLimit>
                  </div>
                </div>
              </StatBox>
              <StatBox $alarm={alarms.disk} $viewMode={viewMode}>
                <Icon icon={faHdd} $alarm={alarms.disk} />
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-center">
                    <ResourceValue $viewMode={viewMode}>
                      {formatResourceValue(bytesToString(stats.diskUsageInBytes))}
                    </ResourceValue>
                    <ResourceLimit $viewMode={viewMode}>/ {diskLimit}</ResourceLimit>
                  </div>
                </div>
              </StatBox>
            </>
          ) : isSuspended ? (
            <div className="col-span-3 text-center py-4 text-red-400 text-sm backdrop-blur-sm rounded-lg bg-red-500/10 border border-red-500/20">
              {server.status === 'suspended' ? 'Suspended' : 'Unavailable'}
            </div>
          ) : (
            <div className="col-span-3 flex justify-center items-center py-6">
              <Spinner size="small" />
            </div>
          )}
        </StatRow>
      </ServerCard>
    );
  }

  // Desktop List View
  return (
    <ServerCard 
      to={`/server/${server.id}`} 
      $status={stats?.status} 
      $viewMode={viewMode}
      $delay={index}
    >
      <EggBackground $image={bgImage} $gradientOpacity={themeSettings.nest_gradient_opacity} $viewMode={viewMode} />
      
      <ListContent>
        <ListLeft>
          <ServerTitle $viewMode={viewMode}>
            <FontAwesomeIcon icon={faServer} className="icon" />
            <span>{server.name}</span>
          </ServerTitle>
		  
          <div className="status-indicator">
            <div className="status-pill">
              <div className="status-dot" />
              <span>{getStatusText()}</span>
            </div>
          </div>
          
          <ServerInfo $viewMode={viewMode}>
            {server.allocations
              .filter((a) => a.isDefault)
              .map((a) => (
                <div key={a.port} className="flex items-center">
                  <FontAwesomeIcon icon={faEthernet} className="mr-2 text-xs" />
                  <span>{a.alias || ip(a.ip)}:{a.port}</span>
                </div>
              ))}
          </ServerInfo>
        </ListLeft>
        
        <ListRight>
          <StatRow $viewMode={viewMode}>
            {stats ? (
              <>
                <StatBox $alarm={alarms.cpu} $viewMode={viewMode} title={`CPU: ${stats.cpuUsagePercent.toFixed(1)}% / ${cpuLimit}`}>
                  <Icon icon={faMicrochip} $alarm={alarms.cpu} />
                  <div className="text-center min-w-12 ml-2">
                    <ResourceValue $viewMode={viewMode}>{stats.cpuUsagePercent.toFixed(1)}%</ResourceValue>
                  </div>
                </StatBox>
                <StatBox $alarm={alarms.memory} $viewMode={viewMode} title={`Memory: ${bytesToString(stats.memoryUsageInBytes)} / ${memoryLimit}`}>
                  <Icon icon={faMemory} $alarm={alarms.memory} />
                  <div className="text-center min-w-16 ml-2">
                    <ResourceValue $viewMode={viewMode}>
                      {formatResourceValue(bytesToString(stats.memoryUsageInBytes))}
                    </ResourceValue>
                  </div>
                </StatBox>
                <StatBox $alarm={alarms.disk} $viewMode={viewMode} title={`Disk: ${bytesToString(stats.diskUsageInBytes)} / ${diskLimit}`}>
                  <Icon icon={faHdd} $alarm={alarms.disk} />
                  <div className="text-center min-w-16 ml-2">
                    <ResourceValue $viewMode={viewMode}>
                      {formatResourceValue(bytesToString(stats.diskUsageInBytes))}
                    </ResourceValue>
                  </div>
                </StatBox>
              </>
            ) : isSuspended ? (
              <div className="px-4 py-2 text-red-400 text-sm backdrop-blur-sm rounded-lg bg-red-500/10 border border-red-500/20">
                {server.status === 'suspended' ? 'Suspended' : 'Unavailable'}
              </div>
            ) : (
              <div className="flex justify-center items-center px-4">
                <Spinner size="small" />
              </div>
            )}
          </StatRow>
        </ListRight>
      </ListContent>
    </ServerCard>
  );
}, isEqual);