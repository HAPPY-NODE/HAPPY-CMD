import React, { useEffect, useMemo, useRef, useState } from 'react';
import Spinner from '@/components/elements/Spinner';
import tw, { styled, css } from 'twin.macro';
import { breakpoint } from '@/theme';
import Fade from '@/components/elements/Fade';
import { createPortal } from 'react-dom';

export interface RequiredModalProps {
    visible: boolean;
    onDismissed: () => void;
    appear?: boolean;
    top?: boolean;
}

export interface ModalProps extends RequiredModalProps {
    dismissable?: boolean;
    closeOnEscape?: boolean;
    closeOnBackground?: boolean;
    showSpinnerOverlay?: boolean;
}

// Export ModalMask so it can be used directly - SIGNIFICANTLY INCREASED Z-INDEX
export const ModalMask = styled.div`
    ${tw`fixed overflow-auto flex w-full inset-0 items-center justify-center p-4`};
    background: rgba(0, 0, 0, 0.85);
    backdrop-filter: blur(10px);
    z-index: 100000; // Greatly increased to ensure it's above everything
`;

const ModalContainer = styled.div<{ alignTop?: boolean }>`
    max-width: 95%;
    max-height: 90vh;
    ${breakpoint('md')`max-width: 75%`};
    ${breakpoint('lg')`max-width: 50%`};

    ${tw`relative flex flex-col w-full`};
    ${(props) =>
        props.alignTop &&
        css`
            margin-top: 5%;
        `};

    & > .close-icon {
        ${tw`absolute right-4 top-4 z-10 p-2 text-white cursor-pointer opacity-70 transition-all duration-150 ease-linear hover:opacity-100`};
        background: rgba(0, 0, 0, 0.3);
        border-radius: 50%;
        width: 36px;
        height: 36px;
        display: flex;
        align-items: center;
        justify-content: center;

        &:hover {
            ${tw`transform rotate-90 scale-110`};
            background: rgba(239, 68, 68, 0.3);
        }

        & > svg {
            ${tw`w-5 h-5`};
        }
    }
`;

const ModalContent = styled.div`
    ${tw`rounded-xl overflow-hidden`};
    background: rgba(31, 34, 53, 0.95);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.1);
    box-shadow: 
        0 25px 50px rgba(0, 0, 0, 0.3),
        0 0 0 1px rgba(255, 255, 255, 0.05),
        inset 0 0 30px rgba(255, 255, 255, 0.03);
    z-index: 100001; // Increased to be above the mask
`;

const SpinnerOverlayContainer = styled.div`
    ${tw`absolute w-full h-full rounded-xl flex items-center justify-center`};
    background: rgba(31, 34, 53, 0.8);
    z-index: 100002; // Increased for spinner overlay
    
    &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        backdrop-filter: blur(5px);
        z-index: -1;
    }
`;

const Modal: React.FC<ModalProps> = ({
    visible,
    appear,
    dismissable,
    showSpinnerOverlay,
    top = true,
    closeOnBackground = true,
    closeOnEscape = true,
    onDismissed,
    children,
}) => {
    const [render, setRender] = useState(visible);

    const isDismissable = useMemo(() => {
        return (dismissable || true) && !(showSpinnerOverlay || false);
    }, [dismissable, showSpinnerOverlay]);

    useEffect(() => {
        if (!isDismissable || !closeOnEscape) return;

        const handler = (e: KeyboardEvent) => {
            if (e.key === 'Escape') setRender(false);
        };

        window.addEventListener('keydown', handler);
        return () => {
            window.removeEventListener('keydown', handler);
        };
    }, [isDismissable, closeOnEscape, render]);

    useEffect(() => {
        if (visible) {
            document.body.style.overflow = 'hidden';
            // Add a class to body to ensure modal is on top
            document.body.classList.add('modal-open');
        } else {
            document.body.style.overflow = 'auto';
            document.body.classList.remove('modal-open');
        }
        
        setRender(visible);
        
        return () => {
            document.body.style.overflow = 'auto';
            document.body.classList.remove('modal-open');
        };
    }, [visible]);

    return (
        <Fade in={render} timeout={150} appear={appear || true} unmountOnExit onExited={() => onDismissed()}>
            <ModalMask
                onClick={(e) => e.stopPropagation()}
                onContextMenu={(e) => e.stopPropagation()}
                onMouseDown={(e) => {
                    if (isDismissable && closeOnBackground) {
                        e.stopPropagation();
                        if (e.target === e.currentTarget) {
                            setRender(false);
                        }
                    }
                }}
            >
                <ModalContainer alignTop={top}>
                    {isDismissable && (
                        <div className={'close-icon'} onClick={() => setRender(false)}>
                            <svg
                                xmlns={'http://www.w3.org/2000/svg'}
                                fill={'none'}
                                viewBox={'0 0 24 24'}
                                stroke={'currentColor'}
                            >
                                <path
                                    strokeLinecap={'round'}
                                    strokeLinejoin={'round'}
                                    strokeWidth={'2'}
                                    d={'M6 18L18 6M6 6l12 12'}
                                />
                            </svg>
                        </div>
                    )}
                    <ModalContent>
                        {showSpinnerOverlay && (
                            <Fade timeout={150} appear in>
                                <SpinnerOverlayContainer>
                                    <Spinner />
                                </SpinnerOverlayContainer>
                            </Fade>
                        )}
                        <div css={tw`p-5 md:p-6 overflow-y-auto max-h-[80vh]`}>
                            {children}
                        </div>
                    </ModalContent>
                </ModalContainer>
            </ModalMask>
        </Fade>
    );
};

const PortaledModal: React.FC<ModalProps> = ({ children, ...props }) => {
    const element = useRef(document.getElementById('modal-portal'));

    useEffect(() => {
        if (element.current) {
            element.current.style.zIndex = '99999'; // Increased portal z-index
        }
    }, []);

    return createPortal(<Modal {...props}>{children}</Modal>, element.current!);
};

export default PortaledModal;