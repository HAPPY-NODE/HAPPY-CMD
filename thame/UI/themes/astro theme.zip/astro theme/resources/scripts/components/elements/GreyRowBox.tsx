import styled from 'styled-components/macro';
import tw, { css } from 'twin.macro';

export default styled.div<{ $hoverable?: boolean }>`
    ${tw`flex rounded-xl no-underline text-neutral-200 items-center p-4 transition-all duration-300 overflow-hidden`};
    background: rgba(31, 34, 53, 0.6);
    backdrop-filter: blur(8px);
    border: 1px solid rgba(255, 255, 255, 0.09);
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15), 
                0 0 0 1px rgba(255, 255, 255, 0.05),
                inset 0 0 20px rgba(255, 255, 255, 0.03);

    ${(props) => props.$hoverable !== false && css`
        &:hover {
            border-color: rgba(99, 102, 241, 0.4);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.25), 
                        0 0 0 1px rgba(99, 102, 241, 0.2),
                        inset 0 0 25px rgba(99, 102, 241, 0.05);
            transform: translateY(-2px);
        }
    `};

    & .icon {
        ${tw`rounded-xl w-16 h-16 flex items-center justify-center p-3 transition-all duration-300`};
        background: rgba(99, 102, 241, 0.15);
        border: 1px solid rgba(99, 102, 241, 0.2);
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        
        &:hover {
            background: rgba(99, 102, 241, 0.25);
            transform: scale(1.05);
        }
    }
`;