import React, { memo, useState } from 'react';
import { ServerEggVariable } from '@/api/server/types';
import TitledGreyBox from '@/components/elements/TitledGreyBox';
import { usePermissions } from '@/plugins/usePermissions';
import InputSpinner from '@/components/elements/InputSpinner';
import Input from '@/components/elements/Input';
import Switch from '@/components/elements/Switch';
import { debounce } from 'debounce';
import updateStartupVariable from '@/api/server/updateStartupVariable';
import useFlash from '@/plugins/useFlash';
import FlashMessageRender from '@/components/FlashMessageRender';
import getServerStartup from '@/api/swr/getServerStartup';
import Select from '@/components/elements/Select';
import isEqual from 'react-fast-compare';
import { ServerContext } from '@/state/server';
import { RiLockLine, RiQuestionLine } from 'react-icons/ri';
import tw, { css } from 'twin.macro';

interface Props {
    variable: ServerEggVariable;
}

const VariableBox = ({ variable }: Props) => {
    const FLASH_KEY = `server:startup:${variable.envVariable}`;

    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const [loading, setLoading] = useState(false);
    const [canEdit] = usePermissions(['startup.update']);
    const { clearFlashes, clearAndAddHttpError } = useFlash();
    const { mutate } = getServerStartup(uuid);

    const setVariableValue = debounce((value: string) => {
        setLoading(true);
        clearFlashes(FLASH_KEY);

        updateStartupVariable(uuid, variable.envVariable, value)
            .then(([response, invocation]) =>
                mutate(
                    (data) => ({
                        ...data,
                        invocation,
                        variables: (data.variables || []).map((v) =>
                            v.envVariable === response.envVariable ? response : v
                        ),
                    }),
                    false
                )
            )
            .catch((error) => {
                console.error(error);
                clearAndAddHttpError({ error, key: FLASH_KEY });
            })
            .then(() => setLoading(false));
    }, 500);

    const useSwitch = variable.rules.some(
        (v) => v === 'boolean' || v === 'in:0,1' || v === 'in:1,0' || v === 'in:true,false' || v === 'in:false,true'
    );
    const isStringSwitch = variable.rules.some((v) => v === 'string');
    const selectValues = variable.rules.find((v) => v.startsWith('in:'))?.split(',') || [];

    return (
        <TitledGreyBox
            title={
                <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-neutral-200">{variable.name}</span>
                    {!variable.isEditable && (
                        <span className="flex items-center text-xs text-yellow-400">
                            <RiLockLine className="mr-1" />
                            Read Only
                        </span>
                    )}
                </div>
            }
            icon={RiQuestionLine}
            css={tw`h-full`}
        >
            <FlashMessageRender byKey={FLASH_KEY} className="mb-4" />
            
            <div className="mb-4">
                <InputSpinner visible={loading}>
                    {useSwitch ? (
                        <div className="flex items-center justify-between">
                            <span className="text-sm text-neutral-300 mr-3">Toggle Value</span>
                            <Switch
                                readOnly={!canEdit || !variable.isEditable}
                                name={variable.envVariable}
                                defaultChecked={
                                    isStringSwitch ? variable.serverValue === 'true' : variable.serverValue === '1'
                                }
                                onChange={() => {
                                    if (canEdit && variable.isEditable) {
                                        if (isStringSwitch) {
                                            setVariableValue(variable.serverValue === 'true' ? 'false' : 'true');
                                        } else {
                                            setVariableValue(variable.serverValue === '1' ? '0' : '1');
                                        }
                                    }
                                }}
                            />
                        </div>
                    ) : (
                        <>
                            {selectValues.length > 0 ? (
                                <Select
                                    onChange={(e) => setVariableValue(e.target.value)}
                                    name={variable.envVariable}
                                    defaultValue={variable.serverValue ?? variable.defaultValue}
                                    disabled={!canEdit || !variable.isEditable}
                                    className="bg-neutral-800/50"
                                >
                                    {selectValues.map((selectValue) => (
                                        <option
                                            key={selectValue.replace('in:', '')}
                                            value={selectValue.replace('in:', '')}
                                        >
                                            {selectValue.replace('in:', '')}
                                        </option>
                                    ))}
                                </Select>
                            ) : (
                                <Input
                                    onKeyUp={(e) => {
                                        if (canEdit && variable.isEditable) {
                                            setVariableValue(e.currentTarget.value);
                                        }
                                    }}
                                    readOnly={!canEdit || !variable.isEditable}
                                    name={variable.envVariable}
                                    defaultValue={variable.serverValue ?? ''}
                                    placeholder={variable.defaultValue}
                                    className="bg-neutral-800/50"
                                />
                            )}
                        </>
                    )}
                </InputSpinner>
            </div>

            <div className="mt-4 pt-3 border-t border-neutral-700">
                <p className="text-xs text-neutral-300">
                    {variable.description}
                </p>
                <p className="text-xs text-neutral-400 mt-2">
                    <span className="font-medium">Environment Variable:</span> {variable.envVariable}
                </p>
                {variable.defaultValue && (
                    <p className="text-xs text-neutral-400 mt-1">
                        <span className="font-medium">Default Value:</span> {variable.defaultValue}
                    </p>
                )}
            </div>
        </TitledGreyBox>
    );
};

export default memo(VariableBox, isEqual);