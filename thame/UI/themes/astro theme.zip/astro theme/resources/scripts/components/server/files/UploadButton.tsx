import React, { useEffect, useRef, useState } from 'react';
import axios from 'axios';
import getFileUploadUrl from '@/api/server/files/getFileUploadUrl';
import tw from 'twin.macro';
import { Button } from '@/components/elements/button/index';
import { ModalMask } from '@/components/elements/Modal';
import Fade from '@/components/elements/Fade';
import useEventListener from '@/plugins/useEventListener';
import { useFlashKey } from '@/plugins/useFlash';
import useFileManagerSwr from '@/plugins/useFileManagerSwr';
import { ServerContext } from '@/state/server';
import { WithClassname } from '@/components/types';
import Portal from '@/components/elements/Portal';
import { FaCloudUploadAlt, FaTimes } from 'react-icons/fa';

function isFileOrDirectory(event: DragEvent): boolean {
    if (!event.dataTransfer?.types) return false;
    return event.dataTransfer.types.some((value) => value.toLowerCase() === 'files');
}

export default ({ className }: WithClassname) => {
    const fileUploadInput = useRef<HTMLInputElement>(null);
    const [visible, setVisible] = useState(false);
    const [isDragOver, setIsDragOver] = useState(false);
    const [timeouts, setTimeouts] = useState<NodeJS.Timeout[]>([]);

    const { mutate } = useFileManagerSwr();
    const { addError, clearAndAddHttpError, clearFlashes } = useFlashKey('files');
	const [isUploading, setIsUploading] = useState(false);

    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const directory = ServerContext.useStoreState((state) => state.files.directory);
    const { clearFileUploads, removeFileUpload, pushFileUpload, setUploadProgress } =
        ServerContext.useStoreActions((actions) => actions.files);

    //
    // IMPORTANT:
    // Removed global "drop" event listener completely (this caused duplicate uploads)
    //

    useEventListener(
        'dragenter',
        (e) => {
			if (isFileOrDirectory(e) && !isUploading) {
				e.preventDefault();
				e.stopPropagation();
				setVisible(true);
			}
        },
        { capture: true }
    );

    useEventListener(
        'dragleave',
        (e) => {
            if (!e.relatedTarget || (e.relatedTarget as Node).nodeName === 'HTML') {
                setVisible(false);
                setIsDragOver(false);
            }
        },
        { capture: true }
    );

    useEventListener(
        'dragover',
        (e) => {
            if (isFileOrDirectory(e)) {
                e.preventDefault();
                e.stopPropagation();
            }
        },
        { capture: true }
    );

    // Removed duplicate global drop listener
    // Drop logic is handled ONLY inside handleDrop()

    useEventListener('keydown', (e: KeyboardEvent) => {
        if (e.key === 'Escape' && visible) {
            setVisible(false);
            setIsDragOver(false);
        }
    });

    useEffect(() => {
        return () => timeouts.forEach(clearTimeout);
    }, [timeouts]);

    const onUploadProgress = (data: ProgressEvent, name: string) => {
        setUploadProgress({ name, loaded: data.loaded });
    };

    const onFileSubmission = (files: FileList) => {
		clearFlashes();
		setIsUploading(true);        // <-- added
		setVisible(false);           // <-- ensure modal closes
        const list = Array.from(files);

        if (list.some((file) => !file.size || (!file.type && file.size === 4096))) {
            return addError('Folder uploads are not supported at this time.', 'Error');
        }

        if (list.length === 0) {
            return addError('No valid files selected.', 'Error');
        }

        const uploads = list.map((file) => {
            const controller = new AbortController();

            pushFileUpload({
                name: file.name,
                data: { abort: controller, loaded: 0, total: file.size },
            });

            return () =>
                getFileUploadUrl(uuid)
                    .then((url) =>
                        axios.post(
                            url,
                            { files: file },
                            {
                                signal: controller.signal,
                                headers: { 'Content-Type': 'multipart/form-data' },
                                params: { directory },
                                onUploadProgress: (data) => onUploadProgress(data, file.name),
                            }
                        )
                    )
                    .then(() => {
                        const newTimeout = setTimeout(() => removeFileUpload(file.name), 500);
                        setTimeouts((prev) => [...prev, newTimeout]);
                    })
                    .catch((error) => {
                        removeFileUpload(file.name);
                        throw error;
                    });
        });

        Promise.all(uploads.map((fn) => fn()))
			.then(() => {
				mutate();
				clearFileUploads();          // <-- ensures header resets immediately
				setIsUploading(false);       // <-- uploading finished
				setVisible(false);
				setIsDragOver(false);


				if (list.length === 1)
					console.log(`Successfully uploaded "${list[0].name}"`);
				else
					console.log(`Successfully uploaded ${list.length} files`);
			})
			.catch((error) => {
				clearFileUploads();
				clearAndAddHttpError(error);
				setIsUploading(false);        // <-- ensure cleanup even on error
			});
    };

    const handleDragOver = (e: React.DragEvent) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragOver(true);
    };

    const handleDragLeave = (e: React.DragEvent) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragOver(false);
    };

    // ✔ This is the ONLY place drop is handled now
    const handleDrop = (e: React.DragEvent) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragOver(false);
        setVisible(false);

        if (!e.dataTransfer?.files.length) return;

        onFileSubmission(e.dataTransfer.files);
    };

    return (
        <>
            <Fade appear in={visible} timeout={100} unmountOnExit>
                <ModalMask
                    onClick={() => {
                        setVisible(false);
                        setIsDragOver(false);
                    }}
                    onDragOver={handleDragOver}
                    onDragLeave={handleDragLeave}
                    onDrop={handleDrop}
                    css={[
                        tw`flex flex-col items-center justify-center`,
                        isDragOver && tw`bg-blue-500 bg-opacity-20`,
                    ]}
                >
                    {/* Close button */}
                    <button
                        onClick={() => {
                            setVisible(false);
                            setIsDragOver(false);
                        }}
                        css={tw`absolute top-6 right-6 text-white p-2 rounded-full hover:bg-white hover:bg-opacity-10 transition-all duration-200 z-50`}
                    >
                        <FaTimes size={24} />
                    </button>

                    {/* Drop zone */}
                    <div
                        css={[
                            tw`flex flex-col items-center justify-center p-8 rounded-2xl border-4 border-dashed transition-all duration-300`,
                            isDragOver
                                ? tw`border-blue-400 bg-blue-500 bg-opacity-10 scale-105`
                                : tw`border-white border-opacity-30 bg-black bg-opacity-50`,
                        ]}
                        className="backdrop-blur-lg"
                    >
                        <div
                            css={[
                                tw`p-6 rounded-full mb-6 transition-all duration-300`,
                                isDragOver
                                    ? tw`bg-blue-500 text-white scale-110`
                                    : tw`bg-white bg-opacity-10 text-white`,
                            ]}
                        >
                            <FaCloudUploadAlt size={48} />
                        </div>

                        <h2 css={tw`text-2xl font-bold text-white mb-3 text-center`}>
                            {isDragOver ? 'Drop to Upload' : 'Drag Files to Upload'}
                        </h2>

                        <p css={tw`text-white text-opacity-80 text-center max-w-md mb-4`}>
                            Drag and drop your files anywhere on this screen to upload them to your server.
                        </p>

                        <div css={tw`flex items-center gap-4 mt-4`}>
                            <div css={tw`h-px bg-white bg-opacity-20 flex-1`} />
                            <span css={tw`text-white text-opacity-60 text-sm`}>OR</span>
                            <div css={tw`h-px bg-white bg-opacity-20 flex-1`} />
                        </div>

                        <Button
                            onClick={() => {
                                setVisible(false);
                                fileUploadInput.current?.click();
                            }}
                            css={tw`mt-6 bg-white bg-opacity-20 hover:bg-opacity-30 border-white border-opacity-30 text-white`}
                            className="group"
                        >
                            <FaCloudUploadAlt
                                css={tw`mr-2 group-hover:scale-110 transition-transform`}
                            />
                            Select Files
                        </Button>
                    </div>
                </ModalMask>
            </Fade>

            {/* Hidden file input */}
            <input
                type="file"
                ref={fileUploadInput}
                css={tw`hidden`}
                onChange={(e) => {
                    if (!e.currentTarget.files) return;
                    onFileSubmission(e.currentTarget.files);
                    if (fileUploadInput.current) fileUploadInput.current.value = '';
                }}
                multiple
            />

            {/* Upload button */}
            <Button
                className={className}
                onClick={() => fileUploadInput.current?.click()}
                css={tw`flex items-center gap-2`}
            >
                <FaCloudUploadAlt css={tw`w-4 h-4`} />
                Upload
            </Button>
        </>
    );
};
