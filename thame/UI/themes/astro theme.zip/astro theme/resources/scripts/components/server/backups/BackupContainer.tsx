import React, { useContext, useEffect, useState } from 'react';
import Spinner from '@/components/elements/Spinner';
import useFlash from '@/plugins/useFlash';
import Can from '@/components/elements/Can';
import CreateBackupButton from '@/components/server/backups/CreateBackupButton';
import FlashMessageRender from '@/components/FlashMessageRender';
import BackupRow from '@/components/server/backups/BackupRow';
import tw, { styled } from 'twin.macro';
import getServerBackups, { Context as ServerBackupContext } from '@/api/swr/getServerBackups';
import { ServerContext } from '@/state/server';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import Pagination from '@/components/elements/Pagination';
import { bytesToString } from '@/lib/formatters';
import { RiHardDriveLine, RiInformationLine, RiHistoryLine } from 'react-icons/ri';

const Header = styled.div`
    ${tw`flex items-center mb-6`};
    
    h1 {
        ${tw`text-2xl font-bold`};
        background: linear-gradient(90deg, #EEE 0%, #CCC 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
    }
`;

const StatsContainer = styled.div`
    ${tw`grid grid-cols-1 md:grid-cols-4 gap-4 mb-6`};
`;

const StatBox = styled.div`
    ${tw`p-4 rounded-xl`};
    background: rgba(31, 34, 53, 0.7);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.1);
    box-shadow: 
        0 4px 15px rgba(0, 0, 0, 0.15), 
        0 0 0 1px rgba(255, 255, 255, 0.05),
        inset 0 0 20px rgba(255, 255, 255, 0.03);
`;

const StatValue = styled.div`
    ${tw`text-2xl font-bold text-neutral-200`};
`;

const StatLabel = styled.div`
    ${tw`text-sm text-neutral-400 mt-1`};
`;

const BackupListContainer = styled.div`
    ${tw`space-y-4`};
`;

const EmptyState = styled.div`
    ${tw`text-center py-12 rounded-xl`};
    background: rgba(31, 34, 53, 0.5);
    border: 1px dashed rgba(255, 255, 255, 0.1);
`;

const ActionContainer = styled.div`
    ${tw`mt-6 flex flex-col sm:flex-row items-center justify-between p-4 rounded-xl`};
    background: rgba(31, 34, 53, 0.5);
    border: 1px solid rgba(255, 255, 255, 0.07);
`;

const InfoText = styled.p`
    ${tw`text-sm text-neutral-300 mb-4 sm:mb-0`};
`;

const BackupContainer = () => {
    const { page, setPage } = useContext(ServerBackupContext);
    const { clearFlashes, clearAndAddHttpError } = useFlash();
    const { data: backups, error, isValidating } = getServerBackups();

    const backupLimit = ServerContext.useStoreState((state) => state.server.data!.featureLimits.backups);

    // Calculate backup statistics safely
    const totalSize = backups?.items?.reduce((acc, backup) => acc + (backup?.bytes || 0), 0) || 0;
    const successfulBackups = backups?.items?.filter(b => b?.isSuccessful).length || 0;
    const lockedBackups = backups?.items?.filter(b => b?.isLocked).length || 0;

    useEffect(() => {
        if (!error) {
            clearFlashes('backups');
            return;
        }

        clearAndAddHttpError({ error, key: 'backups' });
    }, [error]);

    if (!backups || (error && isValidating)) {
        return <Spinner size={'large'} centered />;
    }

    return (
        <ServerContentBlock title={'Backups'}>
            <Header>
                <RiHistoryLine className="text-indigo-400 mr-3 text-2xl" />
                <h1>Backup Management</h1>
            </Header>
            
            <StatsContainer>
                <StatBox>
                    <StatValue>{backups.backupCount || 0}</StatValue>
                    <StatLabel>Total Backups</StatLabel>
                </StatBox>
                
                <StatBox>
                    <StatValue>{successfulBackups}</StatValue>
                    <StatLabel>Successful</StatLabel>
                </StatBox>
                
                <StatBox>
                    <StatValue>{lockedBackups}</StatValue>
                    <StatLabel>Locked</StatLabel>
                </StatBox>
                
                <StatBox>
                    <StatValue>{bytesToString(totalSize)}</StatValue>
                    <StatLabel>Total Size</StatLabel>
                </StatBox>
            </StatsContainer>

            <FlashMessageRender byKey={'backups'} css={tw`mb-4`} />
            
            <BackupListContainer>
                <Pagination data={backups} onPageSelect={setPage}>
                    {({ items }) =>
                        !items || items.length === 0 ? (
                            !backupLimit ? null : (
                                <EmptyState>
									<div className="flex justify-center items-center">
										<RiHardDriveLine className="text-neutral-500 text-4xl mb-4" />
									</div>
                                    <p css={tw`text-center text-sm text-neutral-400`}>
                                        {page > 1
                                            ? "No more backups found on this page."
                                            : 'No backups have been created for this server yet.'}
                                    </p>
                                    {page === 1 && backupLimit > 0 && (
                                        <p css={tw`text-center text-sm text-neutral-500 mt-2`}>
                                            Create your first backup to get started.
                                        </p>
                                    )}
                                </EmptyState>
                            )
                        ) : (
                            items.map((backup, index) => (
                                backup && <BackupRow key={backup.uuid} backup={backup} />
                            ))
                        )
                    }
                </Pagination>
            </BackupListContainer>
            
            {backupLimit === 0 && (
                <EmptyState>
					<div className="flex justify-center items-center">
						<RiInformationLine className="text-neutral-500 text-4xl mb-4" />
					</div>
                    <p css={tw`text-center text-sm text-neutral-300`}>
                        Backups cannot be created for this server because the backup limit is set to 0.
                    </p>
                </EmptyState>
            )}
            
            <Can action={'backup.create'}>
                <ActionContainer>
                    {backupLimit > 0 && backups.backupCount > 0 && (
                        <InfoText>
                            <RiInformationLine className="mr-2" />
                            {backups.backupCount} of {backupLimit} backups have been created for this server.
                        </InfoText>
                    )}
                    {backupLimit > 0 && backupLimit > backups.backupCount && (
                        <CreateBackupButton css={tw`w-full sm:w-auto`} />
                    )}
                </ActionContainer>
            </Can>
        </ServerContentBlock>
    );
};

export default () => {
    const [page, setPage] = useState<number>(1);
    return (
        <ServerBackupContext.Provider value={{ page, setPage }}>
            <BackupContainer />
        </ServerBackupContext.Provider>
    );
};