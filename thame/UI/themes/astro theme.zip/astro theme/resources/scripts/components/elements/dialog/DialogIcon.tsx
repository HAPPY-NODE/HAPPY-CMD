import React, { useContext, useEffect } from 'react';
import { 
    RiCheckboxCircleFill, 
    RiErrorWarningFill, 
    RiInformationFill, 
    RiAlarmWarningFill 
} from 'react-icons/ri';
import classNames from 'classnames';
import { DialogContext, DialogIconProps } from './';
import tw, { styled } from 'twin.macro';

const IconContainer = styled.div<{ type: 'danger' | 'warning' | 'success' | 'info' }>`
  ${tw`flex items-center justify-center w-12 h-12 rounded-full mx-auto mb-4`};
  
  ${({ type }) => {
    switch (type) {
      case 'danger':
        return tw`bg-red-500 text-red-400`;
      case 'warning':
        return tw`bg-yellow-500 text-yellow-400`;
      case 'success':
        return tw`bg-green-500 text-green-400`;
      case 'info':
        return tw`bg-blue-500 text-blue-400`;
    }
  }};
`;

const icons = {
    danger: RiAlarmWarningFill,
    warning: RiErrorWarningFill,
    success: RiCheckboxCircleFill,
    info: RiInformationFill,
};

export default ({ type, position, className }: DialogIconProps) => {
    const { setIcon, setIconPosition } = useContext(DialogContext);

    useEffect(() => {
        const Icon = icons[type];

        setIcon(
            <IconContainer type={type} className={className}>
                <Icon className="w-6 h-6" />
            </IconContainer>
        );
    }, [type, className]);

    useEffect(() => {
        setIconPosition(position);
    }, [position]);

    return null;
};