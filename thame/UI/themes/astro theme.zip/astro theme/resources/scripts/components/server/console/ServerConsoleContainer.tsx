// resources/scripts/components/server/console/ServerConsoleContainer.tsx
import React, { memo, useEffect, useState } from 'react';
import { ServerContext } from '@/state/server';
import Can from '@/components/elements/Can';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import { SocketEvent, SocketRequest } from '@/components/server/events';
import useWebsocketEvent from '@/plugins/useWebsocketEvent';
import isEqual from 'react-fast-compare';
import Spinner from '@/components/elements/Spinner';
import Features from '@feature/Features';
import Console from '@/components/server/console/Console';
import StatGraphs from '@/components/server/console/StatGraphs';
import PowerButtons from '@/components/server/console/PowerButtons';
import ServerDetailsBlock from '@/components/server/console/ServerDetailsBlock';
import { Alert } from '@/components/elements/alert';
import tw from 'twin.macro';
import styled from 'styled-components/macro';
import { motion, AnimatePresence } from 'framer-motion';
import {
    faServer,
    faUsers,
    faCube,
    faNetworkWired,
    faCopy,
    faCheck,
    faMicrochip,
    faMemory,
    faHdd,
    faSignal,
    faClock,
    faMapMarkerAlt
} from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import getServerNestInfo from '@/api/server/getServerNestInfo';
import axios from 'axios';
import UptimeDuration from '@/components/server/UptimeDuration';

// Enhanced Header with Background Support
const HeaderBackground = styled.div<{ $image?: string }>`
    ${tw`absolute inset-0 rounded-xl overflow-hidden pointer-events-none z-0`}
    background-image: ${({ $image }) => $image ? `url(${$image})` : 'none'};
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    filter: brightness(0.3) contrast(1.1) saturate(1.2);
    opacity: 0.4;
    transition: all 0.5s ease;
    
    &::after {
        content: '';
        ${tw`absolute inset-0`}
        background: linear-gradient(
            135deg,
            rgba(23, 26, 45, 0.9) 0%,
            rgba(23, 26, 45, 0.7) 50%,
            rgba(23, 26, 45, 0.9) 100%
        );
    }
`;

const HeaderBlock = styled.div`
    ${tw`col-span-1 sm:col-span-2 lg:col-span-3 pr-0 sm:pr-4 relative z-10`}
    
    h1 {
        ${tw`font-header text-xl sm:text-3xl text-white font-bold truncate mb-2`};
        text-shadow: 0 2px 12px rgba(0,0,0,0.8);
        background: linear-gradient(135deg, #ffffff 0%, #a5b4fc 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }
    
    p {
        ${tw`text-sm text-neutral-300 mb-3 truncate`};
        max-width: 100%;
        text-shadow: 0 1px 4px rgba(0,0,0,0.6);
    }
`;

const InfoRow = styled.div`
    ${tw`flex flex-wrap items-center justify-start gap-3`}
`;

const StatusBadge = styled.div<{ $color: string }>`
    ${tw`inline-flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium mb-2 transition-all duration-300`}
    background: ${props => `${props.$color}15`};
    border: 1px solid ${props => `${props.$color}30`};
    color: ${props => props.$color};
    backdrop-filter: blur(8px);
    
    .dot {
        ${tw`w-2 h-2 rounded-full`}
        background-color: ${props => props.$color};
        box-shadow: 0 0 8px ${props => props.$color};
    }
`;

const StatBadge = styled.div`
    ${tw`inline-flex items-center gap-2 text-sm px-3 py-1.5 rounded-lg transition-all duration-300 cursor-default`}
    background: rgba(255, 255, 255, 0.08);
    border: 1px solid rgba(255, 255, 255, 0.12);
    color: #e5e7eb;
    backdrop-filter: blur(8px);
    
    &:hover {
        background: rgba(255, 255, 255, 0.12);
        border-color: rgba(255, 255, 255, 0.2);
        transform: translateY(-1px);
    }
    
    svg { 
        ${tw`text-sm opacity-80`} 
    }
`;

const ContainerGrid = styled.div`
    ${tw`grid grid-cols-1 sm:grid-cols-4 gap-4 mb-4 relative overflow-hidden`}
    background: rgba(23, 26, 45, 0.8);
    backdrop-filter: blur(16px);
    border-radius: 16px;
    padding: 1.5rem;
    border: 1px solid rgba(255, 255, 255, 0.1);
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
    
    &::before {
        content: '';
        ${tw`absolute inset-0 rounded-xl pointer-events-none`}
        background: linear-gradient(135deg, rgba(59, 130, 246, 0.1) 0%, transparent 50%);
        opacity: 0.6;
    }
`;

/* Enhanced IP Pill */
const IPPill = styled.div`
    ${tw`flex items-center gap-3 px-4 py-3 rounded-xl w-full sm:w-auto relative z-10`}
    background: rgba(23, 26, 45, 0.9);
    border: 1px solid rgba(99, 102, 241, 0.3);
    backdrop-filter: blur(12px);
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);

    .ip-text {
        ${tw`text-sm font-semibold truncate`}
        background: linear-gradient(90deg, #65c6ff, #3a92ed);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        text-shadow: 0 0 20px rgba(101, 198, 255, 0.3);
    }

    .copy-indicator {
        ${tw`text-xs font-semibold flex items-center gap-1`}
        color: #10b981;
        text-shadow: 0 0 10px rgba(16, 185, 129, 0.4);
    }
`;

/* Enhanced Copy Button */
const CopyButton = styled.button`
    ${tw`inline-flex items-center gap-2 text-xs px-3 py-1.5 rounded-lg transition-all duration-300`}
    background: rgba(59, 130, 246, 0.15);
    border: 1px solid rgba(59, 130, 246, 0.3);
    color: #3b82f6;
    
    &:hover { 
        background: rgba(59, 130, 246, 0.25);
        border-color: rgba(59, 130, 246, 0.5);
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(59, 130, 246, 0.2);
    }
    
    &:disabled { 
        opacity: 0.5; 
        cursor: not-allowed; 
        transform: none; 
    }
`;

const RightColumn = styled.div`
    ${tw`col-span-1 flex flex-col items-stretch sm:items-end justify-between gap-4 relative z-10`}
    width: 100%;
`;

const SmallMeta = styled.div`
    ${tw`flex items-center gap-2 mt-3 w-full sm:hidden flex-wrap`}
    
    .meta-item {
        ${tw`flex items-center gap-2 text-xs text-neutral-300 px-2 py-1 rounded-lg transition-all duration-200`}
        background: rgba(255, 255, 255, 0.06);
        border: 1px solid rgba(255, 255, 255, 0.1);
        
        &:hover {
            background: rgba(255, 255, 255, 0.1);
        }
    }
`;

// New Components for Enhanced UI
const QuickStatsGrid = styled.div`
    ${tw`grid grid-cols-2 md:grid-cols-4 gap-3 mb-4`}
`;

const QuickStatCard = styled.div`
    ${tw`p-4 rounded-xl backdrop-blur-lg transition-all duration-300 cursor-default`}
    background: rgba(30, 30, 46, 0.7);
    border: 1px solid rgba(255, 255, 255, 0.1);
    
    &:hover {
        border-color: rgba(59, 130, 246, 0.3);
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
    }
    
    .stat-icon {
        ${tw`text-lg mb-2 opacity-80`}
    }
    
    .stat-value {
        ${tw`text-xl font-bold text-gray-100 mb-1`}
    }
    
    .stat-label {
        ${tw`text-gray-400 text-xs`}
    }
`;

const ConnectionStatus = styled.div<{ $connected: boolean }>`
    ${tw`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-all mb-2 duration-300`}
    background: ${props => props.$connected ? 'rgba(34, 197, 94, 0.1)' : 'rgba(239, 68, 68, 0.1)'};
    border: 1px solid ${props => props.$connected ? 'rgba(34, 197, 94, 0.3)' : 'rgba(239, 68, 68, 0.3)'};
    color: ${props => props.$connected ? '#10b981' : '#ef4444'};
    
    .dot {
        ${tw`w-2 h-2 rounded-full animate-pulse`}
        background-color: ${props => props.$connected ? '#10b981' : '#ef4444'};
    }
`;


const ServerConsoleContainer = () => {
    // store-derived safe selectors
    const name = ServerContext.useStoreState((s) => s.server.data?.name ?? 'N/A');
    const description = ServerContext.useStoreState((s) => s.server.data?.description ?? '');
    const isInstalling = ServerContext.useStoreState((s) => !!s.server.data?.isInstalling);
    const isTransferring = ServerContext.useStoreState((s) => !!s.server.data?.isTransferring);
    const eggFeaturesStore = ServerContext.useStoreState((s) => s.server.data?.eggFeatures ?? {});
    const isNodeUnderMaintenance = ServerContext.useStoreState((s) => !!s.server.data?.isNodeUnderMaintenance);
    const uuid = ServerContext.useStoreState((s) => s.server.data?.uuid ?? null);
    const eggNameStore = ServerContext.useStoreState((s) => s.server.data?.egg?.name ?? 'N/A');
    const nodeNameStore = ServerContext.useStoreState((s) => s.server.data?.nodeName ?? s.server.data?.node?.name ?? 'N/A');
    const locationStore = ServerContext.useStoreState((s) => s.server.data?.nodeLocation ?? s.server.data?.location?.short ?? 'N/A');
    const versionStore = ServerContext.useStoreState((s) => s.server.data?.version ?? s.server.data?.installed_version ?? 'N/A');
    const status = ServerContext.useStoreState((s) => s.status.value);
	const [stats, setStats] = useState({ memory: 0, cpu: 0, disk: 0, uptime: 0, tx: 0, rx: 0 });
	const connected = ServerContext.useStoreState((state) => state.socket.connected);
	const instance = ServerContext.useStoreState((state) => state.socket.instance);

    // Nest background state
    const [nestId, setNestId] = useState<number | null>(null);
    const [themeSettings, setThemeSettings] = useState<{ nest_backgrounds: Record<number, string> }>({
        nest_backgrounds: {},
    });
	
    useEffect(() => {
        if (!connected || !instance) return;
        instance.send(SocketRequest.SEND_STATS);
    }, [connected, instance]);

    useWebsocketEvent(SocketEvent.STATS, (data: string) => {
        try {
            const parsed = JSON.parse(data);
            setStats({
                memory: parsed.memory_bytes,
                cpu: parsed.cpu_absolute,
                disk: parsed.disk_bytes,
                tx: parsed.network.tx_bytes,
                rx: parsed.network.rx_bytes,
                uptime: parsed.uptime || 0,
            });
        } catch (_) {}
    });

    // Fetch nest info and theme settings
    useEffect(() => {
        if (!uuid) return;

        // Fetch nest info
        getServerNestInfo(uuid)
            .then(data => data?.nest_id && setNestId(data.nest_id))
            .catch(console.error);

        // Fetch theme settings
        axios.get('/api/client/theme/api')
            .then(res => setThemeSettings({
                nest_backgrounds: res.data.nest_backgrounds || {},
            }))
            .catch(console.error);
    }, [uuid]);

    const bgImage = nestId && themeSettings.nest_backgrounds[nestId]
        ? themeSettings.nest_backgrounds[nestId]
        : 'https://images.unsplash.com/photo-1635863138275-d9b33299680a?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80';

    // players (unchanged)
    const [players, setPlayers] = useState<{ online: number; max: number }>({ online: 0, max: 0 });

    useEffect(() => {
        if (!uuid) { setPlayers({ online: 0, max: 0 }); return; }
        let cancelled = false;
        const fetchPlayers = async () => {
            try {
                const res = await fetch(`/api/client/servers/${encodeURIComponent(uuid)}/players`);
                if (!res.ok) return;
                const data = await res.json();
                if (cancelled) return;
                if (data && typeof data.players === 'object') {
                    setPlayers({ online: Number(data.players.online || 0), max: Number(data.players.max || 0) });
                }
            } catch {}
        };
        fetchPlayers();
        const interval = setInterval(fetchPlayers, 30000);
        return () => { cancelled = true; clearInterval(interval); };
    }, [uuid]);

    // Local meta state: prefer store values but allow filling missing ones via server-side controller
    const [meta, setMeta] = useState({
        eggName: eggNameStore,
        nodeName: nodeNameStore,
        location: locationStore,
        version: versionStore,
        eggFeatures: eggFeaturesStore,
    });

    // Keep meta in sync when store updates (useful when server store gets populated later)
    useEffect(() => {
        setMeta((prev) => ({
            eggName: eggNameStore ?? prev.eggName,
            nodeName: nodeNameStore ?? prev.nodeName,
            location: locationStore ?? prev.location,
            version: versionStore ?? prev.version,
            eggFeatures: Object.keys(eggFeaturesStore ?? {}).length ? eggFeaturesStore : prev.eggFeatures,
        }));
    }, [eggNameStore, nodeNameStore, locationStore, versionStore, eggFeaturesStore]);

    // Fetch from your server-side endpoint when store values are missing.
    useEffect(() => {
        if (!uuid) return;

        const missingEgg = !meta.eggName || meta.eggName === 'N/A';
        const missingNode = !meta.nodeName || meta.nodeName === 'N/A';
        const missingLocation = !meta.location || meta.location === 'N/A';
        const missingVersion = !meta.version || meta.version === 'N/A';
        const missingFeatures = !meta.eggFeatures || Object.keys(meta.eggFeatures).length === 0;

        if (!missingEgg && !missingNode && !missingLocation && !missingVersion && !missingFeatures) return;

        let aborted = false;
        (async () => {
            try {
                const res = await fetch(`/api/client/servers/${encodeURIComponent(uuid)}/meta`);
                if (!res.ok) {
                    return;
                }
                const json = await res.json();
                if (aborted) return;

                setMeta((prev) => ({
                    eggName: prev.eggName && prev.eggName !== 'N/A' ? prev.eggName : (json.eggName ?? prev.eggName),
                    nodeName: prev.nodeName && prev.nodeName !== 'N/A' ? prev.nodeName : (json.nodeName ?? prev.nodeName),
                    location: prev.location && prev.location !== 'N/A' ? prev.location : (json.location ?? prev.location),
                    version: prev.version && prev.version !== 'N/A' ? prev.version : (json.version ?? prev.version),
                    eggFeatures: Object.keys(prev.eggFeatures ?? {}).length ? prev.eggFeatures : (json.eggFeatures ?? prev.eggFeatures),
                }));
            } catch (e) {
                // ignore
            }
        })();

        return () => { aborted = true; };
    }, [uuid, meta]);

    // Allocation / IP handling
    const allocationStore = ServerContext.useStoreState((s) => s.server.data?.allocation ?? s.server.data?.allocations?.[0] ?? null);
    const [allocation, setAllocation] = useState<{ ip?: string; port?: number; alias?: string } | null>(
        allocationStore ? { 
            ip: allocationStore.ip ?? allocationStore.ip_alias ?? allocationStore.ipAddress ?? null, 
            port: allocationStore.port ?? allocationStore.port ?? null, 
            alias: allocationStore.ip_alias ?? allocationStore.alias ?? null 
        } : null,
    );

    useEffect(() => {
        if (!uuid || allocation) return;

        let aborted = false;
        (async () => {
            try {
                const res = await fetch(`/api/client/servers/${encodeURIComponent(uuid)}/allocations`);
                if (!res.ok) return;
                const json = await res.json();
                if (aborted) return;

                let ip: string | undefined;
                let port: number | undefined;
                let alias: string | undefined;

                if (Array.isArray(json.allocations) && json.allocations[0]) {
                    const a = json.allocations[0];
                    alias = a.ip_alias ?? a.alias ?? a.attributes?.ip_alias ?? a.attributes?.alias;
                    ip = a.ip ?? a.ipAddress ?? a.attributes?.ip;
                    port = a.port ?? a.attributes?.port;
                } else if (Array.isArray(json.data) && json.data[0]) {
                    const attrs = json.data[0].attributes ?? {};
                    alias = attrs.ip_alias ?? attrs.alias;
                    ip = attrs.ip ?? attrs.address;
                    port = attrs.port;
                } else if (Array.isArray(json) && json[0]) {
                    const a = json[0];
                    alias = a.ip_alias ?? a.alias ?? a.attributes?.ip_alias ?? a.attributes?.alias;
                    ip = a.ip ?? a.attributes?.ip;
                    port = a.port ?? a.attributes?.port;
                }

                if (ip) {
                    setAllocation({ ip, port, alias });
                }
            } catch (e) {
                // ignore
            }
        })();

        return () => {
            aborted = true;
        };
    }, [uuid, allocation]);

    // Copy to clipboard UI
    const [copied, setCopied] = useState(false);
    const handleCopy = async (text?: string) => {
        if (!text) return;
        try {
            if (navigator.clipboard && navigator.clipboard.writeText) {
                await navigator.clipboard.writeText(text);
            } else {
                const ta = document.createElement('textarea');
                ta.value = text;
                ta.style.position = 'fixed';
                ta.style.left = '-9999px';
                document.body.appendChild(ta);
                ta.select();
                document.execCommand('copy');
                ta.remove();
            }
            setCopied(true);
            window.setTimeout(() => setCopied(false), 1800);
        } catch (e) {
            // ignore
        }
    };

    // status mapping
    const mapStatusLabel = (s?: string) => {
        if (!s) return 'Connecting...';
        const normalized = s.toLowerCase();
        switch (normalized) {
            case 'running':
            case 'online':
                return 'Online';
            case 'starting':
                return 'Starting';
            case 'stopping':
                return 'Stopping';
            case 'stopped':
                return 'Offline';
            case 'suspended':
                return 'Suspended';
            default:
                return s.charAt(0).toUpperCase() + s.slice(1);
        }
    };

    const statusLabel =
        isNodeUnderMaintenance ? 'Maintenance' : isInstalling ? 'Installing' : isTransferring ? 'Transferring' : mapStatusLabel(status);

    const getStatusColor = () => {
        if (statusLabel === 'Online') return '#10b981';
        if (['Installing', 'Transferring', 'Starting', 'Stopping'].includes(statusLabel)) return '#f59e0b';
        if (statusLabel === 'Maintenance') return '#8b5cf6';
        if (statusLabel === 'Suspended') return '#6b7280';
        return '#ef4444';
    };

    const statusColor = getStatusColor();

    const playersLabel = players.max > 0 ? `${players.online}/${players.max} Players` : players.online > 0 ? `${players.online} Players` : 'N/A';

    // Show allocation alias if available, otherwise show IP
    const displayAddress = allocation ? (allocation.alias || allocation.ip) : 'N/A';
    const ipLabel = allocation ? `${displayAddress}${allocation.port ? `:${allocation.port}` : ''}` : 'N/A';

    return (
        <ServerContentBlock title="Console">
            {(isNodeUnderMaintenance || isInstalling || isTransferring) && (
                <Alert type="warning" className="mb-4">
                    {isNodeUnderMaintenance
                        ? 'Node maintenance in progress. Actions unavailable.'
                        : isInstalling
                        ? 'Server installation in progress. Most actions unavailable.'
                        : 'Server is being transferred. Actions unavailable.'}
                </Alert>
            )}

            <ContainerGrid
                initial={{ opacity: 0, y: -12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4 }}
            >
                {/* Background Image */}
                <HeaderBackground $image={bgImage} />

                {/* Header: occupies first column(s) on larger screens, stacked on mobile */}
                <HeaderBlock>
                    <h1 title={name}>{name}</h1>
                    <p title={description}>{description}</p>

                    <InfoRow>
                        <StatusBadge $color={statusColor}>
                            <div className="dot" />
                            <span>{statusLabel}</span>
                        </StatusBadge>
                        
                        <ConnectionStatus $connected={statusLabel === 'Online'}>
                            <div className="dot" />
                            <span>{stats.uptime > 0 ? <UptimeDuration uptime={stats.uptime/1000} /> : 'Disconnected'}</span>
                        </ConnectionStatus>
                    </InfoRow>

                    {/* on small screens show compact meta badges below the description */}
                    <SmallMeta>
                        <div className="meta-item">
                            <FontAwesomeIcon icon={faUsers} /> 
                            <span>{playersLabel}</span>
                        </div>
                        <div className="meta-item" title={`Egg: ${meta.eggName ?? 'N/A'}`}>
                            <FontAwesomeIcon icon={faCube} /> 
                            <span>{meta.eggName ?? 'N/A'}</span>
                        </div>
                        <div className="meta-item" title={`Node: ${meta.nodeName ?? 'N/A'}`}>
                            <FontAwesomeIcon icon={faServer} /> 
                            <span>{meta.nodeName ?? 'N/A'}</span>
                        </div>
                        <div className="meta-item" title={`Location: ${meta.location ?? 'N/A'}`}>
                            <FontAwesomeIcon icon={faMapMarkerAlt} /> 
                            <span>{meta.location ?? 'N/A'}</span>
                        </div>
                    </SmallMeta>

                    {/* on larger screens show the full badges row */}
                    <InfoRow css={tw`hidden sm:flex`}>
                        <StatBadge whileHover={{ scale: 1.05 }} title="Player Count">
                            <FontAwesomeIcon icon={faUsers} /> 
                            <span>{playersLabel}</span>
                        </StatBadge>
                        <StatBadge whileHover={{ scale: 1.05 }} title={`Egg: ${meta.eggName ?? 'N/A'}`}>
                            <FontAwesomeIcon icon={faCube} /> 
                            <span>{meta.eggName ?? 'N/A'}</span>
                        </StatBadge>
                        <StatBadge whileHover={{ scale: 1.05 }} title={`Node: ${meta.nodeName ?? 'N/A'} (${meta.location ?? 'N/A'})`}>
                            <FontAwesomeIcon icon={faServer} /> 
                            <span>{meta.nodeName ?? 'N/A'}</span>
                        </StatBadge>
                        <StatBadge whileHover={{ scale: 1.05 }} title={`Location: ${meta.location ?? 'N/A'}`}>
                            <FontAwesomeIcon icon={faMapMarkerAlt} /> 
                            <span>{meta.location ?? 'N/A'}</span>
                        </StatBadge>
                    </InfoRow>
                </HeaderBlock>

                {/* Right column: IP pill + actions (stacked nicely on mobile) */}
                <RightColumn>
                    <div style={{ display: 'flex', width: '100%', justifyContent: 'flex-end' }}>
                        <IPPill
                            initial={{ opacity: 0, x: 20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ duration: 0.4 }}
                            whileHover={{ scale: 1.02 }}
                            title={ipLabel !== 'N/A' ? `Copy ${ipLabel}` : 'No IP available'}
                        >
                            <FontAwesomeIcon icon={faNetworkWired} className="text-[#64c5fe]" />
                            <span className="ip-text" title={ipLabel}>{ipLabel}</span>

                            <AnimatePresence mode="wait">
                                {copied ? (
                                    <motion.span
                                        key="copied"
                                        className="copy-indicator"
                                        initial={{ opacity: 0, scale: 0.8 }}
                                        animate={{ opacity: 1, scale: 1 }}
                                        exit={{ opacity: 0, scale: 0.8 }}
                                        transition={{ duration: 0.2 }}
                                    >
                                        <FontAwesomeIcon icon={faCheck} /> Copied
                                    </motion.span>
                                ) : (
                                    <CopyButton 
                                        onClick={() => handleCopy(ipLabel !== 'N/A' ? ipLabel : undefined)} 
                                        disabled={ipLabel === 'N/A'}
                                        whileHover={{ scale: 1.1 }}
                                        whileTap={{ scale: 0.9 }}
                                    >
                                        <FontAwesomeIcon icon={faCopy} />
                                    </CopyButton>
                                )}
                            </AnimatePresence>
                        </IPPill>
                    </div>

                    <div className="flex justify-end">
                        <Can action={['control.start', 'control.stop', 'control.restart']} matchAny>
                            <PowerButtons className="flex sm:justify-end space-x-2" />
                        </Can>
                    </div>
                </RightColumn>
            </ContainerGrid>

            <div className="grid grid-cols-1 lg:grid-cols-4 gap-3 mb-4">
                <div className="flex col-span-1 lg:col-span-3 shadow-lg overflow-hidden">
                    <Spinner.Suspense>
                        <Console />
                    </Spinner.Suspense>
                </div>
                <ServerDetailsBlock className="col-span-1 lg:col-span-1" />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <Spinner.Suspense>
                    <StatGraphs />
                </Spinner.Suspense>
            </div>

            <Features enabled={meta.eggFeatures ?? {}} />
        </ServerContentBlock>
    );
};

export default memo(ServerConsoleContainer, isEqual);