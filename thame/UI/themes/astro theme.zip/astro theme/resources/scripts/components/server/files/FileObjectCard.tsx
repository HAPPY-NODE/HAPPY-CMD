import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faFileAlt, faFileArchive, faFileImport, faFolder } from '@fortawesome/free-solid-svg-icons';
import { encodePathSegments } from '@/helpers';
import { differenceInHours, format, formatDistanceToNow } from 'date-fns';
import { FileObject } from '@/api/server/files/loadDirectory';
import SelectFileCheckbox from '@/components/server/files/SelectFileCheckbox';
import FileDropdownMenu from '@/components/server/files/FileDropdownMenu';
import { bytesToString } from '@/lib/formatters';
import styles from './style.module.css';
import { usePermissions } from '@/plugins/usePermissions';
import { ServerContext } from '@/state/server';
import { NavLink, useRouteMatch } from 'react-router-dom';
import { join } from 'path';

const Clickable: React.FC<{ file: FileObject; children: React.ReactNode }> = ({ file, children }) => {
    const [canRead] = usePermissions(['file.read']);
    const [canReadContents] = usePermissions(['file.read-content']);
    const directory = ServerContext.useStoreState((state) => state.files.directory);

    const match = useRouteMatch();

    return (file.isFile && (!file.isEditable() || !canReadContents)) || (!file.isFile && !canRead) ? (
        <div className={styles.details}>{children}</div>
    ) : (
        <NavLink
            className={styles.details}
            to={`${match.url}${file.isFile ? '/edit' : ''}#${encodePathSegments(join(directory, file.name))}`}
        >
            {children}
        </NavLink>
    );
};

const FileObjectCard = ({ file }: { file: FileObject }) => {
    const icon =
        file.isFile
            ? file.isSymlink
                ? faFileImport
                : file.isArchiveType()
                ? faFileArchive
                : faFileAlt
            : faFolder;

    const iconColor = file.isFile
        ? file.isArchiveType()
            ? 'bg-red-500/20 text-red-400'
            : 'bg-blue-500/20 text-blue-400'
        : 'bg-yellow-500/20 text-yellow-400';

    return (
        <div className={`${styles.file_card} group relative`}>
            {/* Checkbox (top-left) */}
            <div className="absolute top-2 left-2 z-10">
                <SelectFileCheckbox name={file.name} />
            </div>

            {/* Clickable wrapper for navigation */}
            <Clickable file={file}>
                <div className="flex flex-col items-center w-full">
                    {/* Icon */}
                    <div
                        className={`w-14 h-14 rounded-xl flex items-center justify-center mb-3 ${iconColor}`}
                    >
                        <FontAwesomeIcon icon={icon} className="text-2xl" />
                    </div>

                    {/* Name */}
                    <div className="text-sm font-medium text-gray-100 text-center truncate w-full">
                        {file.name}
                    </div>

                    {/* Size */}
                    {file.isFile && (
                        <div className="text-xs text-gray-400 mt-1">
                            {bytesToString(file.size)}
                        </div>
                    )}

                    {/* Date */}
                    <div className="text-[0.7rem] text-gray-500 mt-1">
                        {Math.abs(differenceInHours(file.modifiedAt, new Date())) > 48
                            ? format(file.modifiedAt, 'MMM do, yyyy')
                            : formatDistanceToNow(file.modifiedAt, { addSuffix: true })}
                    </div>
                </div>
            </Clickable>

            {/* Dropdown menu (always positioned, only fades on hover) */}
            <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity z-20">
                <FileDropdownMenu file={file} />
            </div>
        </div>
    );
};

export default FileObjectCard;
