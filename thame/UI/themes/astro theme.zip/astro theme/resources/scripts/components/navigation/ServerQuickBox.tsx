import React, { useEffect, useState } from 'react';
import tw from 'twin.macro';
import http from '@/api/http';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPlay, faRedo, faStop, faCopy, faServer } from '@fortawesome/free-solid-svg-icons';
import Spinner from '@/components/elements/Spinner';
import { Button } from '@/components/elements/button';
import classNames from 'classnames';
import { ServerContext } from '@/state/server';
import styled from 'styled-components/macro';

interface Props {
    serverId: string; // uuid or identifier from URL
    collapsed?: boolean;
}

type Allocation = { ip: string; port: number; isDefault?: boolean; alias?: string };
type ServerSummary = {
    id: string;
    uuid?: string;
    identifier?: string;
    name: string;
    node?: string;
    allocations: Allocation[];
    status?: string;
};

// Enhanced Styled Components with Blue Theme
const ServerQuickBoxContainer = styled.div<{ $collapsed?: boolean }>`
  ${tw`mx-3 mb-4 transition-all duration-300`};
  display: ${props => props.$collapsed ? 'none' : 'block'};
  
  @media (max-width: 768px) {
    display: block;
  }
`;

const QuickBox = styled.div`
  ${tw`rounded-xl border p-4 transition-all duration-300`};
  background: linear-gradient(135deg, rgba(59, 130, 246, 0.15) 0%, rgba(37, 99, 235, 0.08) 100%);
  border: 1px solid rgba(59, 130, 246, 0.25);
  backdrop-filter: blur(10px);
  box-shadow: 0 8px 32px rgba(37, 99, 235, 0.15);
  
  &:hover {
    border-color: rgba(59, 130, 246, 0.4);
    box-shadow: 0 12px 40px rgba(37, 99, 235, 0.2);
  }
`;

const ServerHeaderBox = styled.div`
  ${tw`flex items-center justify-between mb-3`};
`;

const ServerInfo = styled.div`
  ${tw`flex items-center min-w-0 flex-1`};
`;

const ServerIcon = styled.div`
  ${tw`w-10 h-10 flex items-center justify-center rounded-lg mr-3 flex-shrink-0`};
  background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
  color: white;
  box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
`;

const ServerDetails = styled.div`
  ${tw`min-w-0 flex-1`};
`;

const ServerName = styled.div`
  ${tw`text-sm font-semibold text-white truncate`};
`;

const ServerId = styled.div`
  ${tw`text-xs text-blue-300 truncate`};
`;

const StatusIndicator = styled.div<{ $status: string }>`
  ${tw`flex items-center text-xs font-medium px-2 py-1 rounded-full`};
  background: ${props => {
    const status = props.$status || 'offline';
    switch (status) {
      case 'running': return 'rgba(34, 197, 94, 0.15)';
      case 'starting': return 'rgba(234, 179, 8, 0.15)';
      case 'stopping': return 'rgba(234, 179, 8, 0.15)';
      case 'restarting': return 'rgba(234, 179, 8, 0.15)';
      default: return 'rgba(100, 116, 139, 0.15)';
    }
  }};
  color: ${props => {
    const status = props.$status || 'offline';
    switch (status) {
      case 'running': return '#22c55e';
      case 'starting': return '#eab308';
      case 'stopping': return '#eab308';
      case 'restarting': return '#eab308';
      default: return '#64748b';
    }
  }};
  
  &::before {
    content: '';
    ${tw`w-2 h-2 rounded-full mr-2`};
    background: ${props => {
      const status = props.$status || 'offline';
      switch (status) {
        case 'running': return '#22c55e';
        case 'starting': return '#eab308';
        case 'stopping': return '#eab308';
        case 'restarting': return '#eab308';
        default: return '#64748b';
      }
    }};
    animation: ${props => props.$status && props.$status.includes('ing') ? 'pulse 2s infinite' : 'none'};
  }
`;

const ConnectionInfo = styled.div`
  ${tw`flex items-center justify-between mb-3`};
`;

const IpAddress = styled.div`
  ${tw`font-mono text-sm text-blue-100 truncate flex-1`};
`;

const CopyButton = styled.button`
  ${tw`ml-2 p-1 rounded text-blue-300 hover:text-white hover:bg-blue-500 transition-colors`};
`;

const PowerButtons = styled.div`
  ${tw`grid grid-cols-3 gap-2`};
`;

const PowerButton = styled.button<{ $action: string; $loading: boolean }>`
  ${tw`flex items-center justify-center py-2 rounded-lg text-sm font-medium transition-all duration-200`};
  background: ${props => {
    switch (props.$action) {
      case 'start': return 'linear-gradient(135deg, #10b981 0%, #059669 100%)';
      case 'restart': return 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)';
      default: return 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)';
    }
  }};
  color: white;
  opacity: ${props => props.$loading ? 0.7 : 1};
  
  &:hover:not(:disabled) {
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
  }
  
  &:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
`;

// Pulse animation keyframes
const PulseAnimation = styled.div`
  @keyframes pulse {
    0% { transform: scale(1); opacity: 1; }
    50% { transform: scale(1.35); opacity: 0.6; }
    100% { transform: scale(1); opacity: 1; }
  }
`;

const normalizeServerResponse = (payload: any): ServerSummary | null => {
    if (!payload) return null;

    const candidate =
        payload.data ||
        payload.object ||
        payload.attributes ||
        (payload.data && payload.data.attributes ? payload.data : null) ||
        payload;

    const attrs = (candidate && candidate.attributes) || candidate;

    let allocationsSource: any[] = [];
    if (candidate && candidate.relationships && candidate.relationships.allocations && Array.isArray(candidate.relationships.allocations.data)) {
        allocationsSource = candidate.relationships.allocations.data;
    } else if (attrs && attrs.relationships && attrs.relationships.allocations && Array.isArray(attrs.relationships.allocations.data)) {
        allocationsSource = attrs.relationships.allocations.data;
    } else if (Array.isArray(attrs.allocations) && attrs.allocations.length) {
        allocationsSource = attrs.allocations;
    } else if (Array.isArray(candidate.allocations) && candidate.allocations.length) {
        allocationsSource = candidate.allocations;
    } else if (Array.isArray(payload.allocations) && payload.allocations.length) {
        allocationsSource = payload.allocations;
    }

    const allocations: Allocation[] = (allocationsSource || []).map((a: any) => {
        const item = a.attributes || a;
        const ip = item.ip || item.address || item.node_ip || item.host || item.node_address || item.socket || '';
        const port = Number(item.port || item.node_port || item.socket || item.node_port || 0) || 0;
        const isDefault = item.is_default ?? item.isDefault ?? item.default ?? item.isDefaultAllocation ?? false;
        const alias = item.alias || item.ip_alias || '';
        return { ip: String(ip || ''), port, isDefault: Boolean(isDefault), alias: String(alias || '') };
    });

    const safeAllocations = allocations.filter((x) => x.ip || x.port) || [];

    const id =
        (attrs && (attrs.id || attrs.uuid || attrs.identifier)) ||
        (candidate && (candidate.id || candidate.uuid || candidate.identifier)) ||
        (payload && (payload.id || payload.uuid || payload.identifier)) ||
        null;

    const uuid = (attrs && (attrs.uuid || attrs.id)) || (candidate && candidate.uuid) || (payload && payload.uuid) || null;
    const identifier = (attrs && attrs.identifier) || (candidate && candidate.identifier) || null;
    const name = (attrs && (attrs.name || attrs.server_name)) || candidate.name || payload.name || String(id || 'server');
    const status = (attrs && (attrs.status || attrs.state)) || (candidate && candidate.status) || 'unknown';

    return {
        id: String(id || uuid || identifier || name),
        uuid: uuid ? String(uuid) : undefined,
        identifier: identifier ? String(identifier) : undefined,
        name: String(name),
        node: (attrs && attrs.node) || (candidate && candidate.node) || undefined,
        allocations: safeAllocations,
        status: String(status || 'unknown'),
    };
};

const ServerQuickBox: React.FC<Props> = ({ serverId, collapsed = false }) => {
    const ctxServer = (() => {
        try {
            return ServerContext.useStoreState((s) => s.server.data);
        } catch (e) {
            return undefined;
        }
    })();

    const [loading, setLoading] = useState<boolean>(true);
    const [server, setServer] = useState<ServerSummary | null>(null);
    const [actionLoading, setActionLoading] = useState<string | null>(null);
    const [allocationData, setAllocationData] = useState<{ displayAddress: string; fullAddress: string } | null>(null);

    useEffect(() => {
        let cancelled = false;

        const initFromContext = () => {
            if (!ctxServer) return false;
            const matches =
                String(ctxServer.uuid || ctxServer.id || ctxServer.identifier || '').startsWith(String(serverId)) ||
                String(serverId).startsWith(String(ctxServer.uuid || ctxServer.id || ctxServer.identifier || ''));
            if (matches) {
                const normalized = normalizeServerResponse(ctxServer);
                if (!cancelled) {
                    setServer(normalized);
                    setLoading(false);
                }
                return true;
            }
            return false;
        };

        if (initFromContext()) return;

        setLoading(true);
        http.get(`/api/client/servers/${encodeURIComponent(serverId)}`)
            .then((res) => res.data)
            .then((data) => {
                if (cancelled) return;
                const normalized = normalizeServerResponse(data);
                setServer(normalized);
            })
            .catch((e) => {
                console.warn('Primary server fetch failed; attempting fallback fetch by uuid/identifier.', e);
                return http
                    .get(`/api/client/servers/${encodeURIComponent(serverId)}`)
                    .then((r) => r.data)
                    .then((d) => {
                        if (cancelled) return;
                        setServer(normalizeServerResponse(d));
                    })
                    .catch(() => {
                        if (!cancelled) setServer(null);
                    });
            })
            .finally(() => {
                if (!cancelled) setLoading(false);
            });

        return () => {
            cancelled = true;
        };
    }, [serverId, ctxServer]);

    // Fetch allocation data separately to get alias information
    useEffect(() => {
        if (!server || !server.uuid) return;

        let cancelled = false;

        const fetchAllocations = async () => {
            try {
                const response = await http.get(`/api/client/servers/${encodeURIComponent(server.uuid!)}/allocations`);
                const data = response.data;

                let allocations: any[] = [];
                
                // Handle different response formats
                if (Array.isArray(data.allocations)) {
                    allocations = data.allocations;
                } else if (Array.isArray(data.data)) {
                    allocations = data.data;
                } else if (Array.isArray(data)) {
                    allocations = data;
                }

                if (allocations.length > 0) {
                    const primaryAllocation = allocations[0];
                    const attributes = primaryAllocation.attributes || primaryAllocation;
                    
                    // Extract alias and IP information
                    const alias = attributes.alias || attributes.ip_alias || '';
                    const ip = attributes.ip || attributes.address || '';
                    const port = attributes.port || 0;

                    // Use alias if available, otherwise use IP
                    const displayAddress = alias || ip;
                    const fullAddress = `${displayAddress}${port ? `:${port}` : ''}`;

                    if (!cancelled) {
                        setAllocationData({
                            displayAddress: fullAddress,
                            fullAddress: fullAddress
                        });
                    }
                }
            } catch (error) {
                console.warn('Failed to fetch allocation data, using server data instead', error);
                // Fallback to server allocation data
                if (!cancelled && server.allocations && server.allocations.length > 0) {
                    const alloc = server.allocations[0];
                    const displayAddress = alloc.alias || alloc.ip;
                    const fullAddress = `${displayAddress}${alloc.port ? `:${alloc.port}` : ''}`;
                    setAllocationData({
                        displayAddress: fullAddress,
                        fullAddress: fullAddress
                    });
                }
            }
        };

        fetchAllocations();

        return () => {
            cancelled = true;
        };
    }, [server]);

    // Fallback: if allocation fetch fails, use server allocation data
    useEffect(() => {
        if (!allocationData && server && server.allocations && server.allocations.length > 0) {
            const alloc = server.allocations[0];
            const displayAddress = alloc.alias || alloc.ip;
            const fullAddress = `${displayAddress}${alloc.port ? `:${alloc.port}` : ''}`;
            setAllocationData({
                displayAddress: fullAddress,
                fullAddress: fullAddress
            });
        }
    }, [server, allocationData]);

    const copyToClipboard = async (text: string) => {
        try {
            await navigator.clipboard.writeText(text);
        } catch (e) {
            console.error('Failed to copy IP', e);
        }
    };

    const doPowerAction = async (signal: 'start' | 'stop' | 'restart') => {
        if (!server) return;
        setActionLoading(signal);
        try {
            await http.post(`/api/client/servers/${encodeURIComponent(serverId)}/power`, { signal });
        } catch (e) {
            console.error('Failed to send power action', e);
        } finally {
            setActionLoading(null);
        }
    };

    if (loading) {
        return (
            <ServerQuickBoxContainer $collapsed={collapsed}>
                <QuickBox>
                    <div className="flex items-center justify-center py-4">
                        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-500"></div>
                    </div>
                </QuickBox>
            </ServerQuickBoxContainer>
        );
    }

    if (!server) return null;

    // Use allocationData if available, otherwise fallback to server allocation
    const ipLabel = allocationData ? allocationData.displayAddress : 
                   (server.allocations && server.allocations.length ? 
                    `${server.allocations[0].alias || server.allocations[0].ip}${server.allocations[0].port ? `:${server.allocations[0].port}` : ''}` : 
                    'n/a');

    return (
        <>
            <PulseAnimation />
            <ServerQuickBoxContainer $collapsed={collapsed}>
                <QuickBox>
                    <ServerHeaderBox>
                        <ServerInfo>
                            <ServerIcon>
                                <FontAwesomeIcon icon={faServer} />
                            </ServerIcon>
                            <ServerDetails>
                                <ServerName title={server.name}>{server.name}</ServerName>
                                <ServerId>ID: {server.identifier || server.id || server.uuid || 'n/a'}</ServerId>
                            </ServerDetails>
                        </ServerInfo>
                    </ServerHeaderBox>

                    <ConnectionInfo>
                        <IpAddress title={ipLabel}>{ipLabel}</IpAddress>
                        <CopyButton onClick={() => copyToClipboard(ipLabel)} title="Copy IP">
                            <FontAwesomeIcon icon={faCopy} size="xs" />
                        </CopyButton>
                    </ConnectionInfo>

                    <PowerButtons>
                        <PowerButton
                            $action="start"
                            $loading={actionLoading === 'start'}
                            onClick={() => doPowerAction('start')}
                            disabled={actionLoading !== null}
                        >
                            {actionLoading === 'start' ? '...' : <FontAwesomeIcon icon={faPlay} />}
                        </PowerButton>
                        <PowerButton
                            $action="restart"
                            $loading={actionLoading === 'restart'}
                            onClick={() => doPowerAction('restart')}
                            disabled={actionLoading !== null}
                        >
                            {actionLoading === 'restart' ? '...' : <FontAwesomeIcon icon={faRedo} />}
                        </PowerButton>
                        <PowerButton
                            $action="stop"
                            $loading={actionLoading === 'stop'}
                            onClick={() => doPowerAction('stop')}
                            disabled={actionLoading !== null}
                        >
                            {actionLoading === 'stop' ? '...' : <FontAwesomeIcon icon={faStop} />}
                        </PowerButton>
                    </PowerButtons>
                </QuickBox>
            </ServerQuickBoxContainer>
        </>
    );
};

export default ServerQuickBox;