import * as React from 'react';
import { useState, useEffect } from 'react';
import { Link, NavLink, useLocation, useParams } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faCogs,
  faLayerGroup,
  faSignOutAlt,
  faServer,
  faTerminal,
  faFolder,
  faDatabase,
  faClock,
  faUsers,
  faArchive,
  faNetworkWired,
  faCog,
  faBars,
  faTimes,
  faChevronDown,
  faChevronRight,
  faHome,
  faUser,
  faSlidersH,
  faChartBar,
  faFileContract,
  faCreditCard,
  faShieldAlt,
  faComments,
  faBook,
  faBell,
  faEnvelope,
  faLink,
  faQuestionCircle,
  faTools,
  faCalendarAlt,
  faPuzzlePiece
} from '@fortawesome/free-solid-svg-icons';
import { useStoreState } from 'easy-peasy';
import { ApplicationStore } from '@/state';
import SearchContainer from '@/components/dashboard/search/SearchContainer';
import tw, { theme } from 'twin.macro';
import styled from 'styled-components/macro';
import http from '@/api/http';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';
import Tooltip from '@/components/elements/tooltip/Tooltip';
import Avatar from '@/components/Avatar';
import { motion, AnimatePresence } from 'framer-motion';
import ServerQuickBox from '@/components/navigation/ServerQuickBox';

// ---------- Styled components (improved) ----------
const SidebarContainer = styled.div<{ $collapsed: boolean; $mobileOpen: boolean }>`
  ${tw`fixed left-0 top-0 h-screen z-50 flex flex-col transition-all duration-300`};
  background: rgb(26 27 47 / 67%);
  backdrop-filter: blur(20px);
  border-right: 1px solid rgba(255, 255, 255, 0.15);
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
  width: ${props => props.$collapsed ? '80px' : '280px'};
  
  @media (max-width: 768px) {
    transform: ${props => props.$mobileOpen ? 'translateX(0)' : 'translateX(-100%)'};
    width: 280px;
    background: rgba(26, 27, 47, 0.98);
  }
`;

const Overlay = styled.div<{ $visible: boolean }>`
  ${tw`fixed inset-0 bg-black bg-opacity-60 z-40 transition-opacity duration-300`};
  opacity: ${props => props.$visible ? 1 : 0};
  pointer-events: ${props => props.$visible ? 'auto' : 'none'};
  
  @media (min-width: 769px) {
    ${tw`hidden`};
  }
`;

const LogoArea = styled.div`
  ${tw`flex items-center justify-between p-6 border-b border-neutral-700`};
  height: 75px;
  min-height: 75px;
`;

const LogoContainer = styled.div<{ $collapsed: boolean }>`
  ${tw`flex items-center transition-all duration-300`};
  width: ${props => props.$collapsed ? '40px' : '180px'};
  overflow: hidden;
`;

const LogoImage = styled.img.attrs((props: any) => ({
  src: props.src || '',
  onError: (e: any) => {
    e.target.style.display = 'none';
  }
}))`
  ${tw`object-contain transition-all duration-300`};
  height: ${props => props.$collapsed ? '30px' : '38px'};
  filter: brightness(1.1);
`;

const ToggleButton = styled.button`
  ${tw`p-2 rounded-lg text-neutral-400 hover:text-white hover:bg-blue-500 transition-all duration-200`};
  
  @media (max-width: 768px) {
    ${tw`hidden`};
  }
`;

const Navigation = styled.nav`
  ${tw`flex-1 overflow-y-auto py-6`};
  
  &::-webkit-scrollbar {
    width: 4px;
  }
  
  &::-webkit-scrollbar-track {
    background: transparent;
  }
  
  &::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.2);
    border-radius: 2px;
  }
`;

const NavSection = styled.div`
  ${tw`mb-8`};
`;

const SectionLabel = styled.div<{ $collapsed: boolean }>`
  ${tw`px-6 py-3 text-xs font-semibold text-neutral-400 uppercase tracking-wider transition-all duration-300`};
  display: ${props => props.$collapsed ? 'none' : 'block'};
  
  @media (max-width: 768px) {
    display: block;
  }
`;

const NavItem = styled(NavLink)`
  ${tw`flex items-center mx-4 px-4 py-3 rounded-xl text-neutral-300 transition-all duration-200 relative overflow-hidden mb-2`};
  
  /* Shining hover effect */
  &:after {
    content: '';
    ${tw`absolute inset-0 opacity-0 transition-opacity duration-300`};
    background: linear-gradient(
      90deg,
      transparent 0%,
      rgba(59, 130, 246, 0.1) 50%,
      transparent 100%
    );
    transform: translateX(-100%);
  }
  
  &:hover {
    ${tw`text-white bg-white bg-opacity-5`};
    transform: translateX(2px);
    
    /* Shining animation on hover */
    &:after {
      opacity: 1;
      transform: translateX(100%);
      transition: transform 0.6s ease, opacity 0.3s ease;
    }
  }
  
  &.active {
    ${tw`text-white`};
    background: linear-gradient(135deg, rgba(59, 130, 246, 0.15) 0%, rgb(12 165 255 / 25%) 100%);
    box-shadow: 0 4px 15px rgb(0 0 0 / 26%);
    
    /* Show blue border only when active */
    &:before {
      opacity: 1;
      transform: scaleY(1);
    }
  }
`;

const ExternalNavItem = styled.a`
  ${tw`flex items-center mx-4 px-4 py-3 rounded-xl text-neutral-300 transition-all duration-200 relative overflow-hidden mb-2`};
  
  /* Blue border - only visible when active */
  &:before {
    content: '';
    ${tw`absolute left-0 top-0 h-full w-1 bg-blue-500 transform scale-y-0 transition-transform duration-200`};
    border-radius: 0 2px 2px 0;
    opacity: 0;
  }
  
  /* Shining hover effect */
  &:after {
    content: '';
    ${tw`absolute inset-0 opacity-0 transition-opacity duration-300`};
    background: linear-gradient(
      90deg,
      transparent 0%,
      rgba(59, 130, 246, 0.1) 50%,
      transparent 100%
    );
    transform: translateX(-100%);
  }
  
  &:hover {
    ${tw`text-white bg-white bg-opacity-5`};
    transform: translateX(2px);
    
    /* Shining animation on hover */
    &:after {
      opacity: 1;
      transform: translateX(100%);
      transition: transform 0.6s ease, opacity 0.3s ease;
    }
  }
  
  &.active {
    ${tw`text-white`};
    background: linear-gradient(135deg, rgba(59, 130, 246, 0.15) 0%, rgba(147, 51, 234, 0.1) 100%);
    box-shadow: 0 4px 15px rgba(59, 130, 246, 0.2);
    
    /* Show blue border only when active */
    &:before {
      opacity: 1;
      transform: scaleY(1);
    }
  }
`;

const NavIcon = styled.div<{ $collapsed: boolean }>`
  ${tw`flex items-center justify-center text-lg transition-all duration-200`};
  width: ${props => props.$collapsed ? '100%' : '24px'};
  min-width: ${props => props.$collapsed ? '100%' : '24px'};
`;

const NavText = styled.span<{ $collapsed: boolean }>`
  ${tw`transition-all duration-300 font-medium`};
  margin-left: ${props => props.$collapsed ? '0' : '1rem'};
  opacity: ${props => props.$collapsed ? 0 : 1};
  display: ${props => props.$collapsed ? 'none' : 'inline'};
  
  @media (max-width: 768px) {
    opacity: 1;
    display: inline;
    margin-left: 1rem;
  }
`;

const ServerSection = styled.div<{ $collapsed: boolean }>`
  ${tw`border-t border-neutral-700 pt-6 mt-6 transition-all duration-300`};
  display: ${props => props.$collapsed ? 'none' : 'block'};
  
  @media (max-width: 768px) {
    display: block;
  }
`;

const ServerHeader = styled.div<{ $collapsed: boolean }>`
  ${tw`flex items-center justify-between px-4 py-3 mx-2 cursor-pointer rounded-xl text-neutral-400 hover:text-white transition-all duration-200 mb-3`};
  background: ${props => !props.$collapsed ? 'rgba(255, 255, 255, 0.05)' : 'transparent'};
  border: 1px solid rgba(255, 255, 255, 0.1);
  
  &:hover {
    background: rgba(255, 255, 255, 0.08);
    border-color: rgba(255, 255, 255, 0.2);
  }
  
  @media (max-width: 768px) {
    background: rgba(255, 255, 255, 0.05);
  }
`;

const ServerNavItems = styled.div<{ $expanded: boolean }>`
  ${tw`overflow-hidden transition-all duration-300`};
  max-height: ${props => props.$expanded ? '1900px' : '0'};
`;

// New component for server navlinks in collapsed mode
const CollapsedServerNavSection = styled.div`
  ${tw`border-t border-neutral-700 pt-4 mt-4`};
`;

const UserArea = styled.div<{ $collapsed: boolean }>`
  ${tw`p-6 border-t border-neutral-700 transition-all duration-300`};
  min-height: ${props => props.$collapsed ? '100px' : '120px'};
`;

const UserInfo = styled.div<{ $collapsed: boolean }>`
  ${tw`flex items-center transition-all duration-300`};
  opacity: ${props => props.$collapsed ? 0 : 1};
  justify-content: ${props => props.$collapsed ? 'center' : 'flex-start'};
  
  @media (max-width: 768px) {
    opacity: 1;
    justify-content: flex-start;
  }
`;

const UserDetails = styled.div<{ $collapsed: boolean }>`
  ${tw`transition-all duration-300`};
  margin-left: ${props => props.$collapsed ? '0' : '0.75rem'};
  display: ${props => props.$collapsed ? 'none' : 'block'};
  
  @media (max-width: 768px) {
    display: block;
    margin-left: 0.75rem;
  }
`;

const UserName = styled.div`
  ${tw`text-sm font-semibold text-white`};
`;

const UserRole = styled.div`
  ${tw`text-xs text-neutral-400 mt-1`};
`;

const LogoutButton = styled.button<{ $collapsed: boolean }>`
  ${tw`w-full mt-4 flex items-center justify-center p-3 rounded-xl text-neutral-300 hover:text-white transition-all duration-200`};
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid rgba(255, 255, 255, 0.1);
  justify-content: ${props => props.$collapsed ? 'center' : 'flex-start'};
  
  &:hover {
    background: rgba(239, 68, 68, 0.2);
    border-color: rgba(239, 68, 68, 0.3);
    transform: translateY(-1px);
  }
`;

const MobileMenuButton = styled.button<{ $visible: boolean }>`
  ${tw`fixed top-5 left-5 z-50 p-3 rounded-xl text-neutral-400 hover:text-white transition-all duration-300`};
  background: rgba(26, 27, 47, 0.9);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.15);
  display: ${props => props.$visible ? 'block' : 'none'} !important;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
  
  &:hover {
    background: rgba(59, 130, 246, 0.3);
    border-color: rgba(59, 130, 246, 0.5);
  }
  
  @media (min-width: 769px) {
    ${tw`hidden`};
  }
`;

const CloseSidebarButton = styled.button`
  ${tw`absolute top-5 right-5 z-50 p-2 rounded-lg text-neutral-400 hover:text-white hover:bg-red-500 transition-all duration-200`};
  
  @media (min-width: 769px) {
    ${tw`hidden`};
  }
`;

const QuickActionsSection = styled.div<{ $collapsed: boolean }>`
  ${tw`mt-6 mx-4 rounded-xl transition-all duration-300`};
  display: ${props => props.$collapsed ? 'none' : 'block'};
  
  @media (max-width: 768px) {
    display: block;
  }
`;

const ActionTitle = styled.div`
  ${tw`text-xs font-semibold text-neutral-400 uppercase tracking-wider mb-3 px-2`};
`;

const ActionGrid = styled.div`
  ${tw`grid grid-cols-2 gap-3`};
`;

const ActionButton = styled.a`
  ${tw`flex flex-col items-center justify-center p-3 rounded-xl text-neutral-300 transition-all duration-200 cursor-pointer`};
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid rgba(255, 255, 255, 0.1);
  text-decoration: none;
  min-height: 70px;
  
  &:hover {
    ${tw`text-white`};
    background: rgba(59, 130, 246, 0.2);
    border-color: rgba(59, 130, 246, 0.4);
    transform: translateY(-2px);
    box-shadow: 0 4px 15px rgba(59, 130, 246, 0.2);
  }
  
  .action-icon {
    ${tw`text-lg mb-2 transition-all duration-200`};
  }
  
  span {
    ${tw`text-xs text-center leading-tight`};
  }
`;

// Collapsed tooltip for nav items
const TooltipContent = styled.div`
  ${tw`px-3 py-2 text-sm bg-black bg-opacity-90 backdrop-blur-md rounded-lg border border-neutral-700`};
`;

// ---------- Helper: map icon name strings to FA icon objects ----------
const mapIconNameToFa = (name?: string) => {
  if (!name) return faComments;

  const n = name.toString().toLowerCase();

  switch (n) {
    case 'file-contract': case 'file-contract-o': return faFileContract;
    case 'credit-card': case 'creditcard': return faCreditCard;
    case 'shield-alt': case 'shield': return faShieldAlt;
    case 'comments': case 'discord': return faComments;
    case 'home': return faHome;
    case 'user': return faUser;
    case 'cogs': case 'cog': return faCogs;
    case 'server': return faServer;
    case 'terminal': return faTerminal;
    case 'folder': return faFolder;
    case 'database': return faDatabase;
    case 'clock': case 'time': return faClock;
    case 'archive': return faArchive;
    case 'network': case 'network-wired': return faNetworkWired;
    case 'chart': case 'chart-bar': return faChartBar;
    case 'book': return faBook;
    case 'bell': return faBell;
    case 'mail': case 'envelope': return faEnvelope;
    case 'link': return faLink;
    case 'help': case 'question': case 'question-circle': return faQuestionCircle;
    case 'tools': return faTools;
    case 'calendar': case 'calendar-alt': return faCalendarAlt;
    case 'sliders-h': case 'sliders': return faSlidersH;
    case 'puzzle-piece': case 'plugins': case 'plugin': return faPuzzlePiece;
    default:
      if (n.includes('term') || n.includes('console')) return faTerminal;
      if (n.includes('server')) return faServer;
      if (n.includes('user')) return faUser;
      if (n.includes('plugin') || n.includes('module')) return faPuzzlePiece;
      return faComments;
  }
};

// ---------- Types for Navigation Links ----------
interface NavigationLink {
  id: string;
  type: string;
  name: string;
  icon: string;
  link: string;
  target: string;
  enabled: boolean;
  order: number;
  category: string;
  requires_root?: boolean;
}

interface QuickAction {
  title: string;
  icon: any;
  url: string;
  target: string;
  rel: string;
}

interface ThemeSettings {
  collapsedLogoUrl: string;
  expandedLogoUrl: string;
  remoteQuickLinksEnabled: boolean;
  quickActions: QuickAction[];
  navigationLinks: NavigationLink[];
}

// ---------- Helper functions for localStorage ----------
const loadThemeSettings = (): ThemeSettings | null => {
  try {
    const saved = localStorage.getItem('theme-settings');
    if (saved) {
      return JSON.parse(saved);
    }
  } catch (error) {
    console.warn('Failed to load theme settings from localStorage:', error);
  }
  return null;
};

const saveThemeSettings = (settings: ThemeSettings) => {
  try {
    localStorage.setItem('theme-settings', JSON.stringify(settings));
  } catch (error) {
    console.warn('Failed to save theme settings to localStorage:', error);
  }
};

// ---------- Component ----------
export default () => {
  const location = useLocation();
  const params = useParams<{ id?: string }>();
  const name = useStoreState((state: ApplicationStore) => state.settings.data!.name);
  const user = useStoreState((state: ApplicationStore) => state.user.data!);
  const rootAdmin = useStoreState((state: ApplicationStore) => state.user.data!.rootAdmin);
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const [collapsed, setCollapsed] = useState(() => {
    // Load collapsed state from localStorage on initial render
    const saved = localStorage.getItem('sidebar-collapsed');
    return saved ? JSON.parse(saved) : false;
  });
  const [mobileOpen, setMobileOpen] = useState(false);
  const [serverNavExpanded, setServerNavExpanded] = useState(false);
  const [pluginInstallerAvailable, setPluginInstallerAvailable] = useState(false);
  const isServerPage = location.pathname.startsWith('/server/');
  const serverMatch = location.pathname.match(/^\/server\/([^/]+)/);
  const currentServerId = serverMatch ? serverMatch[1] : null;

  // Defaults for quick actions
  const defaultQuickActions: QuickAction[] = [
    {
      title: 'Terms of Service',
      icon: faFileContract,
      url: 'https://example.com/terms-of-services',
      target: '_blank',
      rel: 'noopener noreferrer'
    },
    {
      title: 'Billing Panel',
      icon: faCreditCard,
      url: 'https://billing.example.com/',
      target: '_blank',
      rel: 'noopener noreferrer'
    },
    {
      title: 'Discord',
      icon: faComments,
      url: 'https://discord.gg/rt5xyjdRM4',
      target: '_blank',
      rel: 'noopener noreferrer'
    },
    {
      title: 'Privacy Policy',
      icon: faShieldAlt,
      url: 'https://example.com/privacy-policy',
      target: '_blank',
      rel: 'noopener noreferrer'
    }
  ];

  // Load theme settings from localStorage immediately on component mount
  const savedThemeSettings = loadThemeSettings();
  
  // React state for logos & quick links - initialize with saved settings or defaults
  const [themeSettings, setThemeSettings] = useState<ThemeSettings>(() => {
    if (savedThemeSettings) {
      return savedThemeSettings;
    }
    return {
      collapsedLogoUrl: "https://i.ibb.co/VWPqZtZ6/image-2.png",
      expandedLogoUrl: "https://img.imgdd.com/2c676b89-56af-40f7-9f8c-35f433c2dcb9.png",
      remoteQuickLinksEnabled: true,
      quickActions: defaultQuickActions,
      navigationLinks: []
    };
  });

  const [loadingRemote, setLoadingRemote] = useState<boolean>(true);

  // Save collapsed state to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('sidebar-collapsed', JSON.stringify(collapsed));
    
    // Update CSS variable for core.blade.php margin adjustment
    const marginValue = collapsed ? '80px' : '280px';
    document.documentElement.style.setProperty('--sidebar-width', marginValue);
    
    // Add/remove class for smooth transitions
    if (collapsed) {
      document.body.classList.add('sidebar-collapsed');
    } else {
      document.body.classList.remove('sidebar-collapsed');
    }
  }, [collapsed]);

  // Save theme settings to localStorage whenever they change
  useEffect(() => {
    saveThemeSettings(themeSettings);
  }, [themeSettings]);

  // Check if we're on mobile initially
  useEffect(() => {
    const checkMobile = () => {
      if (window.innerWidth <= 768) {
        setCollapsed(false);
      }
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // Auto-expand server nav when on a server page
  useEffect(() => {
    if (isServerPage) {
      setServerNavExpanded(true);
    }
  }, [isServerPage, location.pathname]);

  // Close mobile menu when window is resized to desktop size
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth > 768) {
        setMobileOpen(false);
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Fetch theme settings from server on mount
  useEffect(() => {
    let mounted = true;
    setLoadingRemote(true);

    const endpoints = [
      '/api/client/theme/api',
      '/api/client/theme/settings'
    ];

    const fetchThemeSettings = async () => {
      for (const endpoint of endpoints) {
        try {
          const resp = await http.get(endpoint);
          if (!mounted) return;
          
          const data = resp.data || {};
          console.log('Theme settings loaded:', data);

          // Update theme settings with new data from server
          setThemeSettings(prev => {
            const newSettings = { ...prev };
            
            if (data.small_logo) {
              newSettings.collapsedLogoUrl = data.small_logo;
            }
            if (data.large_logo) {
              newSettings.expandedLogoUrl = data.large_logo;
            }

            if (typeof data.quick_links_enabled !== 'undefined') {
              newSettings.remoteQuickLinksEnabled = !!data.quick_links_enabled;
            }

            if (Array.isArray(data.quick_links) && data.quick_links.length > 0) {
              const mapped = data.quick_links.map((q: any) => {
                const iconObj = mapIconNameToFa(q.icon);
                return {
                  title: q.title,
                  url: q.url,
                  icon: iconObj,
                  target: q.target || '_self',
                  rel: q.rel || 'noopener noreferrer',
                };
              });
              newSettings.quickActions = mapped;
            }
            
            if (Array.isArray(data.navigation_links) && data.navigation_links.length > 0) {
              newSettings.navigationLinks = data.navigation_links;
            }
            
            return newSettings;
          });
          
          break;
        } catch (error) {
          console.warn(`Failed to fetch from ${endpoint}:`, error);
          continue;
        }
      }
    };

    fetchThemeSettings().finally(() => {
      if (mounted) setLoadingRemote(false);
    });

    return () => { mounted = false; };
  }, []);

  // Check if plugin installer module is available
  useEffect(() => {
    let mounted = true;

    const checkPluginInstaller = async () => {
      try {
        const response = await http.get('/api/client/modules/check/plugin_installer');
        if (mounted && response.data.available) {
          setPluginInstallerAvailable(true);
        }
      } catch (error) {
        console.warn('Plugin installer module not available:', error);
        setPluginInstallerAvailable(false);
      }
    };

    checkPluginInstaller();

    return () => { mounted = false; };
  }, []);

  const onTriggerLogout = () => {
    setIsLoggingOut(true);
    http.post('/auth/logout').finally(() => {
      // @ts-expect-error this is valid
      window.location = '/';
    });
  };

  const toggleSidebar = () => {
    setCollapsed(!collapsed);
  };

  const toggleMobileMenu = () => {
    setMobileOpen(!mobileOpen);
  };

  const closeMobileMenu = () => {
    setMobileOpen(false);
  };

  const handleNavClick = () => {
    if (window.innerWidth <= 768) {
      closeMobileMenu();
    }
  };

  // Filter and sort navigation links by category and order
  const getNavigationLinksByCategory = (category: string) => {
    return themeSettings.navigationLinks
      .filter(link => 
        link.category === category && 
        link.enabled && 
        (!link.requires_root || (link.requires_root && rootAdmin))
      )
      .sort((a, b) => a.order - b.order);
  };

  // Render a navigation link item with tooltip ONLY when collapsed
  const renderNavItem = (link: NavigationLink) => {
    const resolvedLink = link.link.replace('{id}', currentServerId || '');
    const isExternal = link.link.startsWith('http') || link.target === '_blank';
    const icon = mapIconNameToFa(link.icon);

    const navItemContent = (
      <>
        <NavIcon $collapsed={collapsed}>
          <FontAwesomeIcon icon={icon} />
        </NavIcon>
        <NavText $collapsed={collapsed}>{link.name}</NavText>
      </>
    );

    const navItem = isExternal ? (
      <ExternalNavItem 
        href={resolvedLink}
        target={link.target}
        rel={link.target === '_blank' ? 'noopener noreferrer' : ''}
        onClick={handleNavClick}
      >
        {navItemContent}
      </ExternalNavItem>
    ) : (
      <NavItem 
        to={resolvedLink}
        onClick={handleNavClick}
        isActive={(match, location) => {
          if (!match) return false;
          return location.pathname === resolvedLink;
        }}
      >
        {navItemContent}
      </NavItem>
    );

    // Only wrap with Tooltip when sidebar is collapsed
    if (collapsed) {
      return (
        <Tooltip
          key={link.id}
          content={<TooltipContent>{link.name}</TooltipContent>}
          placement="right"
        >
          {navItem}
        </Tooltip>
      );
    }

    return <React.Fragment key={link.id}>{navItem}</React.Fragment>;
  };

  // Get main navigation links
  const mainNavLinks = getNavigationLinksByCategory('main');
  const serverNavLinks = getNavigationLinksByCategory('server');

  // Render Plugins Manager navlink
  const renderPluginsManagerLink = () => {
    if (!pluginInstallerAvailable || !currentServerId) return null;

    const navItemContent = (
      <>
        <NavIcon $collapsed={collapsed}>
          <FontAwesomeIcon icon={faPuzzlePiece} />
        </NavIcon>
        <NavText $collapsed={collapsed}>Plugins Manager</NavText>
      </>
    );

    const navItem = (
      <NavItem 
        to={`/server/${currentServerId}/plugins`}
        onClick={handleNavClick}
        isActive={(match, location) => {
          return location.pathname.startsWith(`/server/${currentServerId}/plugins`);
        }}
      >
        {navItemContent}
      </NavItem>
    );

    // Only wrap with Tooltip when sidebar is collapsed
    if (collapsed) {
      return (
        <Tooltip
          content={<TooltipContent>Plugins Manager</TooltipContent>}
          placement="right"
        >
          {navItem}
        </Tooltip>
      );
    }

    return navItem;
  };

  return (
    <>
      <MobileMenuButton 
        onClick={toggleMobileMenu} 
        $visible={!mobileOpen}
      >
        <FontAwesomeIcon icon={faBars} />
      </MobileMenuButton>

      <Overlay $visible={mobileOpen} onClick={closeMobileMenu} />

      <SidebarContainer 
        $collapsed={collapsed}
        $mobileOpen={mobileOpen}
      >
        <LogoArea>
          <Link to="/" onClick={handleNavClick}>
            <LogoContainer $collapsed={collapsed}>
              <LogoImage 
                src={collapsed ? themeSettings.collapsedLogoUrl : themeSettings.expandedLogoUrl} 
                alt={name}
                $collapsed={collapsed}
                onError={(e: any) => {
                  e.currentTarget.style.display = 'none';
                }}
              />
            </LogoContainer>
          </Link>
          <ToggleButton onClick={toggleSidebar}>
            <FontAwesomeIcon icon={collapsed ? faChevronRight : faChevronDown} />
          </ToggleButton>
          
          <CloseSidebarButton onClick={closeMobileMenu}>
            <FontAwesomeIcon icon={faTimes} />
          </CloseSidebarButton>
        </LogoArea>

        <Navigation>
          <NavSection>
            <SectionLabel $collapsed={collapsed}>Navigation</SectionLabel>
            {mainNavLinks.map(renderNavItem)}
          </NavSection>

          {/* Server Management Section - Show in both collapsed and expanded modes */}
          {isServerPage && (serverNavLinks.length > 0 || pluginInstallerAvailable) && (
            <>
              {/* Expanded Server Section */}
              {!collapsed && (
                <ServerSection $collapsed={collapsed}>
                  <ServerHeader 
                    $collapsed={collapsed} 
                    onClick={() => setServerNavExpanded(!serverNavExpanded)}
                  >
                    <div className="flex items-center">
                      <FontAwesomeIcon icon={faServer} className="mr-3" />
                      <span className="font-medium">Server Management</span>
                    </div>
                    <FontAwesomeIcon 
                      icon={serverNavExpanded ? faChevronDown : faChevronRight} 
                      size="xs" 
                    />
                  </ServerHeader>
                  
                  <ServerQuickBox serverId={currentServerId!} />
                  
                  <ServerNavItems $expanded={serverNavExpanded}>
                    {serverNavLinks.map(link => (
                      <React.Fragment key={link.id}>
                        {renderNavItem(link)}
                      </React.Fragment>
                    ))}
                    {renderPluginsManagerLink()}
                  </ServerNavItems>
                </ServerSection>
              )}

              {/* Collapsed Server Section - Show server navlinks as icons */}
              {collapsed && (
                <CollapsedServerNavSection>
                  {serverNavLinks.map(link => (
                    <React.Fragment key={link.id}>
                      {renderNavItem(link)}
                    </React.Fragment>
                  ))}
                  {renderPluginsManagerLink()}
                </CollapsedServerNavSection>
              )}
            </>
          )}
        </Navigation>

        <UserArea $collapsed={collapsed}>
          <UserInfo $collapsed={collapsed}>
            <Avatar.User />
            <UserDetails $collapsed={collapsed}>
              <UserName>{user.username}</UserName>
              <UserRole>{rootAdmin ? 'Administrator' : 'User'}</UserRole>
            </UserDetails>
          </UserInfo>
          
          {/* Only show tooltip for logout button when collapsed */}
          {collapsed ? (
            <Tooltip
              content={<TooltipContent>Sign Out</TooltipContent>}
              placement="right"
            >
              <LogoutButton $collapsed={collapsed} onClick={onTriggerLogout}>
                <FontAwesomeIcon icon={faSignOutAlt} />
              </LogoutButton>
            </Tooltip>
          ) : (
            <LogoutButton $collapsed={collapsed} onClick={onTriggerLogout}>
              <FontAwesomeIcon icon={faSignOutAlt} />
              <span className="ml-2">Sign Out</span>
            </LogoutButton>
          )}
        </UserArea>
      </SidebarContainer>

      <SpinnerOverlay visible={isLoggingOut || loadingRemote} />
    </>
  );
};