import React, { useEffect, useState } from 'react';
import { Button } from '@/components/elements/button';
import Can from '@/components/elements/Can';
import { ServerContext } from '@/state/server';
import { PowerAction } from '@/components/server/console/ServerConsoleContainer';
import { Dialog } from '@/components/elements/dialog';
import classNames from 'classnames';
import { PlayIcon, RefreshIcon, StopIcon } from '@heroicons/react/solid';

interface PowerButtonProps {
    className?: string;
}

export default ({ className }: PowerButtonProps) => {
    const [open, setOpen] = useState(false);
    const status = ServerContext.useStoreState((state) => state.status.value);
    const instance = ServerContext.useStoreState((state) => state.socket.instance);

    const killable = status === 'stopping';

    const onButtonClick = (
        action: PowerAction | 'kill-confirmed',
        e: React.MouseEvent<HTMLButtonElement, MouseEvent>
    ): void => {
        e.preventDefault();
        if (action === 'kill') return setOpen(true);
        if (instance) {
            setOpen(false);
            instance.send('set state', action === 'kill-confirmed' ? 'kill' : action);
        }
    };

    useEffect(() => {
        if (status === 'offline') setOpen(false);
    }, [status]);

    const baseStyle = 'flex items-center justify-center flex-1 px-4 py-2 rounded-xl font-semibold transition-all duration-250 shadow-md';
    const commonHover = 'hover:shadow-lg hover:brightness-110 active:scale-95';
    const disabledStyle = 'disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:brightness-100 disabled:active:scale-100';

    return (
        <div className={classNames('flex space-x-3', className)}>
            <Dialog.Confirm
                open={open}
                hideCloseIcon
                onClose={() => setOpen(false)}
                title={'Forcibly Stop Process'}
                confirm={'Continue'}
                onConfirmed={onButtonClick.bind(this, 'kill-confirmed')}
            >
                Forcibly stopping a server can lead to data corruption.
            </Dialog.Confirm>

            {/* Start Button */}
            <Can action={'control.start'}>
                <button
                    className={classNames(
                        baseStyle,
                        'bg-blue-600 text-white border border-blue-500/50',
                        'hover:bg-blue-700',
                        commonHover,
                        disabledStyle
                    )}
                    disabled={status !== 'offline'}
                    onClick={onButtonClick.bind(this, 'start')}
                >
                    <PlayIcon className="w-4 h-4 mr-2" />
                    Start
                </button>
            </Can>

            {/* Restart Button */}
            <Can action={'control.restart'}>
                <button
                    className={classNames(
                        baseStyle,
                        'bg-cyan-600 text-white border border-cyan-500/50',
                        'hover:bg-cyan-700',
                        commonHover,
                        disabledStyle
                    )}
                    disabled={!status}
                    onClick={onButtonClick.bind(this, 'restart')}
                >
                    <RefreshIcon className="w-4 h-4 mr-2" />
                    Restart
                </button>
            </Can>

            {/* Stop / Kill Button */}
            <Can action={'control.stop'}>
                <button
                    className={classNames(
                        baseStyle,
                        killable 
                            ? 'bg-pink-600 text-white border border-pink-500/50 hover:bg-pink-700'
                            : 'bg-red-600 text-white border border-red-500/50 hover:bg-red-700',
                        commonHover,
                        disabledStyle
                    )}
                    disabled={status === 'offline'}
                    onClick={onButtonClick.bind(this, killable ? 'kill' : 'stop')}
                >
                    <StopIcon className="w-4 h-4 mr-2" />
                    {killable ? 'Kill' : 'Stop'}
                </button>
            </Can>
        </div>
    );
};