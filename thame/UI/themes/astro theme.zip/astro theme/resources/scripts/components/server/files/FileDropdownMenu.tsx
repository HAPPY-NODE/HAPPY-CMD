import React, { memo, useRef, useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
    faBoxOpen,
    faCopy,
    faEllipsisH,
    faFileArchive,
    faFileCode,
    faFileDownload,
    faLevelUpAlt,
    faPencilAlt,
    faTrashAlt,
    IconDefinition,
} from '@fortawesome/free-solid-svg-icons';
import RenameFileModal from '@/components/server/files/RenameFileModal';
import { ServerContext } from '@/state/server';
import { join } from 'path';
import deleteFiles from '@/api/server/files/deleteFiles';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';
import copyFile from '@/api/server/files/copyFile';
import Can from '@/components/elements/Can';
import getFileDownloadUrl from '@/api/server/files/getFileDownloadUrl';
import useFlash from '@/plugins/useFlash';
import tw from 'twin.macro';
import { FileObject } from '@/api/server/files/loadDirectory';
import useFileManagerSwr from '@/plugins/useFileManagerSwr';
import DropdownMenu from '@/components/elements/DropdownMenu';
import styled, { keyframes, css } from 'styled-components/macro';
import useEventListener from '@/plugins/useEventListener';
import compressFiles from '@/api/server/files/compressFiles';
import decompressFiles from '@/api/server/files/decompressFiles';
import isEqual from 'react-fast-compare';
import ChmodFileModal from '@/components/server/files/ChmodFileModal';
import { Dialog } from '@/components/elements/dialog';
import { FaEllipsisH } from 'react-icons/fa';

type ModalType = 'rename' | 'move' | 'chmod';

const fadeIn = keyframes`
  from {
    opacity: 0;
    transform: translateY(8px) scale(0.95);
  }
  to {
    opacity: 1;
    transform: translateY(0) scale(1);
  }
`;

const StyledRow = styled.div<{ $danger?: boolean }>`
    ${tw`px-4 py-3 flex items-center text-sm transition-all duration-300 cursor-pointer`};
    ${(props) =>
        props.$danger
            ? tw`hover:bg-red-500/10 text-red-400`
            : tw`hover:bg-indigo-500/10 text-gray-300`};
    position: relative;
    overflow: hidden;
    
    &::before {
        content: '';
        position: absolute;
        left: 0;
        top: 0;
        height: 100%;
        width: 3px;
        background: ${props => props.$danger 
            ? 'linear-gradient(180deg, rgba(239,68,68,0.6) 0%, rgba(239,68,68,0.2) 100%)' 
            : 'linear-gradient(180deg, rgba(99,102,241,0.6) 0%, rgba(99,102,241,0.2) 100%)'};
        opacity: 0;
        transition: opacity 0.3s ease;
    }
    
    &:hover::before {
        opacity: 1;
    }
    
    &:active {
        transform: scale(0.98);
    }
`;

const DropdownContainer = styled.div`
    background: rgba(31, 34, 53, 0.95);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 14px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3), 
                0 0 0 1px rgba(255, 255, 255, 0.05),
                inset 0 0 20px rgba(255, 255, 255, 0.03);
    padding: 6px 0;
    min-width: 200px;
    animation: ${fadeIn} 0.2s ease-out forwards;
    overflow: hidden;
    z-index: 100;
`;

const IconWrapper = styled.div<{ $danger?: boolean }>`
    ${tw`w-8 h-8 flex items-center justify-center rounded-full mr-3`};
    background: ${props => props.$danger 
        ? 'rgba(239, 68, 68, 0.1)' 
        : 'rgba(99, 102, 241, 0.1)'};
    transition: all 0.3s ease;
    
    ${StyledRow}:hover & {
        background: ${props => props.$danger 
            ? 'rgba(239, 68, 68, 0.2)' 
            : 'rgba(99, 102, 241, 0.2)'};
        transform: scale(1.1);
    }
`;

const MenuButton = styled.button`
    ${tw`p-2 rounded-lg text-gray-400 transition-all duration-300`};
    background: rgba(31, 34, 53, 0.5);
    border: 1px solid rgba(255, 255, 255, 0.07);
    
    &:hover {
        ${tw`text-indigo-300`};
        background: rgba(99, 102, 241, 0.15);
        border-color: rgba(99, 102, 241, 0.3);
        box-shadow: 0 0 15px rgba(99, 102, 241, 0.2);
        transform: translateY(-1px);
    }
    
    &:active {
        transform: translateY(0);
    }
`;

interface RowProps extends React.HTMLAttributes<HTMLDivElement> {
    icon: IconDefinition;
    title: string;
    $danger?: boolean;
}

const Row = ({ icon, title, $danger, ...props }: RowProps) => (
    <StyledRow $danger={$danger} {...props}>
        <IconWrapper $danger={$danger}>
            <FontAwesomeIcon icon={icon} css={tw`text-xs`} fixedWidth />
        </IconWrapper>
        <span>{title}</span>
    </StyledRow>
);

const FileDropdownMenu = ({ file }: { file: FileObject }) => {
    const onClickRef = useRef<DropdownMenu>(null);
    const [showSpinner, setShowSpinner] = useState(false);
    const [modal, setModal] = useState<ModalType | null>(null);
    const [showConfirmation, setShowConfirmation] = useState(false);

    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const { mutate } = useFileManagerSwr();
    const { clearAndAddHttpError, clearFlashes } = useFlash();
    const directory = ServerContext.useStoreState((state) => state.files.directory);

    useEventListener(`pterodactyl:files:ctx:${file.key}`, (e: CustomEvent) => {
        if (onClickRef.current) {
            onClickRef.current.triggerMenu(e.detail);
        }
    });

    const doDeletion = () => {
        clearFlashes('files');

        // For UI speed, immediately remove the file from the listing before calling the deletion function.
        // If the delete actually fails, we'll fetch the current directory contents again automatically.
        mutate((files) => files.filter((f) => f.key !== file.key), false);

        deleteFiles(uuid, directory, [file.name]).catch((error) => {
            mutate();
            clearAndAddHttpError({ key: 'files', error });
        });
    };

    const doCopy = () => {
        setShowSpinner(true);
        clearFlashes('files');

        copyFile(uuid, join(directory, file.name))
            .then(() => mutate())
            .catch((error) => clearAndAddHttpError({ key: 'files', error }))
            .then(() => setShowSpinner(false));
    };

    const doDownload = () => {
        setShowSpinner(true);
        clearFlashes('files');

        getFileDownloadUrl(uuid, join(directory, file.name))
            .then((url) => {
                // @ts-expect-error this is valid
                window.location = url;
            })
            .catch((error) => clearAndAddHttpError({ key: 'files', error }))
            .then(() => setShowSpinner(false));
    };

    const doArchive = () => {
        setShowSpinner(true);
        clearFlashes('files');

        compressFiles(uuid, directory, [file.name])
            .then(() => mutate())
            .catch((error) => clearAndAddHttpError({ key: 'files', error }))
            .then(() => setShowSpinner(false));
    };

    const doUnarchive = () => {
        setShowSpinner(true);
        clearFlashes('files');

        decompressFiles(uuid, directory, file.name)
            .then(() => mutate())
            .catch((error) => clearAndAddHttpError({ key: 'files', error }))
            .then(() => setShowSpinner(false));
    };

    return (
        <>
            <Dialog.Confirm
                open={showConfirmation}
                onClose={() => setShowConfirmation(false)}
                title={`Delete ${file.isFile ? 'File' : 'Directory'}`}
                confirm={'Delete'}
                onConfirmed={doDeletion}
            >
                You will not be able to recover the contents of&nbsp;
                <span className={'font-semibold text-gray-50'}>{file.name}</span> once deleted.
            </Dialog.Confirm>
            <DropdownMenu
                ref={onClickRef}
                renderToggle={(onClick) => (
                    <MenuButton
                        onClick={onClick}
                    >
                        <FaEllipsisH />
                        {modal ? (
                            modal === 'chmod' ? (
                                <ChmodFileModal
                                    visible
                                    appear
                                    files={[{ file: file.name, mode: file.modeBits }]}
                                    onDismissed={() => setModal(null)}
                                />
                            ) : (
                                <RenameFileModal
                                    visible
                                    appear
                                    files={[file.name]}
                                    useMoveTerminology={modal === 'move'}
                                    onDismissed={() => setModal(null)}
                                />
                            )
                        ) : null}
                        <SpinnerOverlay visible={showSpinner} fixed size={'large'} />
                    </MenuButton>
                )}
            >
                <DropdownContainer>
                    <Can action={'file.update'}>
                        <Row onClick={() => setModal('rename')} icon={faPencilAlt} title={'Rename'} />
                        <Row onClick={() => setModal('move')} icon={faLevelUpAlt} title={'Move'} />
                        <Row onClick={() => setModal('chmod')} icon={faFileCode} title={'Permissions'} />
                    </Can>
                    {file.isFile && (
                        <Can action={'file.create'}>
                            <Row onClick={doCopy} icon={faCopy} title={'Copy'} />
                        </Can>
                    )}
                    {file.isArchiveType() ? (
                        <Can action={'file.create'}>
                            <Row onClick={doUnarchive} icon={faBoxOpen} title={'Unarchive'} />
                        </Can>
                    ) : (
                        <Can action={'file.archive'}>
                            <Row onClick={doArchive} icon={faFileArchive} title={'Archive'} />
                        </Can>
                    )}
                    {file.isFile && <Row onClick={doDownload} icon={faFileDownload} title={'Download'} />}
                    <Can action={'file.delete'}>
                        <Row onClick={() => setShowConfirmation(true)} icon={faTrashAlt} title={'Delete'} $danger />
                    </Can>
                </DropdownContainer>
            </DropdownMenu>
        </>
    );
};

export default memo(FileDropdownMenu, isEqual);