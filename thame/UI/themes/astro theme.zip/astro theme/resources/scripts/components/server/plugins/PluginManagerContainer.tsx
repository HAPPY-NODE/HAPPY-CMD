import React, { useState, useEffect } from 'react';
import { ServerContext } from '@/state/server';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import TitledGreyBox from '@/components/elements/TitledGreyBox';
import FlashMessageRender from '@/components/FlashMessageRender';
import tw, { styled } from 'twin.macro';
import { RiPlugLine, RiDownloadLine, RiBox3Line, RiServerLine, RiUserLine, RiInformationLine, RiCheckboxCircleLine, RiErrorWarningLine } from 'react-icons/ri';
import InstalledPluginsTab from './tabs/InstalledPluginsTab';
import BrowsePluginsTab from './tabs/BrowsePluginsTab';

const TabButton = styled.button<{ active?: boolean }>`
    ${tw`px-6 py-3 font-medium transition-colors duration-200 flex items-center`};
    ${props => props.active 
        ? tw`text-gray-50 border-b-2 border-blue-500` 
        : tw`text-gray-400 hover:text-gray-50`
    };
`;

const TabContainer = styled.div`
    ${tw`flex space-x-1 mb-6 border-b border-gray-700`};
`;

const ContentContainer = styled.div`
    ${tw`mt-6`};
`;

const StatusIndicator = styled.div<{ online: boolean }>`
    ${tw`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium`};
    ${props => props.online 
        ? tw`bg-green-500/20 text-green-300` 
        : tw`bg-red-500/20 text-red-300`
    };
`;

const InfoCard = styled.div`
    ${tw`p-4 rounded-lg transition-all duration-300`};
    background: rgba(31, 34, 53, 0.8);
    border: 1px solid rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(10px);
`;

const LoadingContainer = styled.div`
    ${tw`flex items-center space-x-2`};
`;

export default () => {
    const server = ServerContext.useStoreState(state => state.server.data!);
    const [activeTab, setActiveTab] = useState<'installed' | 'browse'>('installed');
    const [serverInfo, setServerInfo] = useState({
        version: 'Loading...',
        software: 'Loading...',
        online: false,
        players: 0,
        maxPlayers: 0,
        motd: '',
        loading: true,
        error: null as string | null
    });

    const fetchServerInfo = async () => {
        try {
            setServerInfo(prev => ({ ...prev, loading: true, error: null }));
            
            // FIXED: Use the correct endpoint
            const response = await fetch(`/api/client/servers/${server.uuid}/server-info`);
            const data = await response.json();

            if (data.success && data.server_info) {
                setServerInfo({
                    version: data.server_info.version || 'Unknown',
                    software: data.server_info.software || 'Unknown',
                    online: data.server_info.online || false,
                    players: data.server_info.players || 0,
                    maxPlayers: data.server_info.max_players || 0,
                    motd: data.server_info.motd || '',
                    loading: false,
                    error: null
                });
            } else {
                throw new Error(data.error || 'Failed to fetch server info');
            }
        } catch (error) {
            console.error('Error fetching server info:', error);
            setServerInfo(prev => ({
                ...prev,
                loading: false,
                error: error instanceof Error ? error.message : 'Failed to fetch server information',
                online: false
            }));
        }
    };

    useEffect(() => {
        fetchServerInfo();
        
        // Refresh server info every 30 seconds
        const interval = setInterval(fetchServerInfo, 30000);
        return () => clearInterval(interval);
    }, [server.uuid]);

    const getStatusText = () => {
        if (serverInfo.loading) return 'Checking server status...';
        return serverInfo.online ? 'Server Online' : 'Server Offline';
    };

    const getStatusColor = () => {
        if (serverInfo.loading) return 'text-blue-400';
        return serverInfo.online ? 'text-green-400' : 'text-red-400';
    };

    const getStatusIcon = () => {
        if (serverInfo.loading) return RiInformationLine;
        return serverInfo.online ? RiCheckboxCircleLine : RiErrorWarningLine;
    };

    const renderLoadingSpinner = () => (
        <LoadingContainer>
            <div className="animate-spin rounded-full h-4 w-4 border-2 border-blue-500 border-t-transparent"></div>
            <span>Loading...</span>
        </LoadingContainer>
    );

    return (
        <ServerContentBlock title={'Plugins Manager'}>
            <div className="flex items-center justify-between mb-6">
                <div className="flex items-center">
                    <RiPlugLine className="text-blue-400 mr-3 text-2xl" />
                    <h1 className="text-2xl font-bold">Plugins Manager</h1>
                </div>
                <button
                    onClick={fetchServerInfo}
                    disabled={serverInfo.loading}
                    className="flex items-center space-x-2 px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded-lg transition-colors duration-200 text-sm disabled:opacity-50"
                >
                    <RiServerLine className={serverInfo.loading ? 'animate-spin' : ''} />
                    <span>{serverInfo.loading ? 'Refreshing...' : 'Refresh Status'}</span>
                </button>
            </div>

            <FlashMessageRender byKey={'plugins'} css={tw`mb-6`} />

            {/* Server Info Card */}
            <TitledGreyBox title={'Live Server Information'} css={tw`mb-6`}>
                <div className="space-y-4">
                    {/* Status Bar */}
                    <div className="flex items-center justify-between p-4 bg-gray-800/50 rounded-lg border border-gray-700">
                        <div className="flex items-center space-x-3">
                            {React.createElement(getStatusIcon(), {
                                className: `text-xl ${getStatusColor()}`
                            })}
                            <div>
                                <h3 className="font-semibold text-gray-50">{getStatusText()}</h3>
                                <p className="text-gray-400 text-sm">
                                    {serverInfo.online 
                                        ? `${serverInfo.players}/${serverInfo.maxPlayers} players online` 
                                        : 'Server is not responding'
                                    }
                                </p>
                            </div>
                        </div>
                        <StatusIndicator online={serverInfo.online && !serverInfo.loading}>
                            {serverInfo.online ? 'ONLINE' : 'OFFLINE'}
                        </StatusIndicator>
                    </div>

                    {/* Server Details Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <InfoCard>
                            <div className="flex items-center space-x-3 mb-2">
                                <RiServerLine className="text-blue-400 text-lg" />
                                <h4 className="font-semibold text-gray-400 text-sm">Server Version</h4>
                            </div>
                            <div className="text-gray-50 font-bold text-lg truncate">
                                {serverInfo.loading ? renderLoadingSpinner() : serverInfo.version}
                            </div>
                            <p className="text-gray-400 text-xs mt-1">
                                Live version from server ping
                            </p>
                        </InfoCard>

                        <InfoCard>
                            <div className="flex items-center space-x-3 mb-2">
                                <RiPlugLine className="text-green-400 text-lg" />
                                <h4 className="font-semibold text-gray-400 text-sm">Server Type</h4>
                            </div>
                            <div className="text-gray-50 font-bold text-lg">
                                {serverInfo.loading ? renderLoadingSpinner() : serverInfo.software}
                            </div>
                            <p className="text-gray-400 text-xs mt-1">
                                Detected server software
                            </p>
                        </InfoCard>

                        <InfoCard>
                            <div className="flex items-center space-x-3 mb-2">
                                <RiUserLine className="text-purple-400 text-lg" />
                                <h4 className="font-semibold text-gray-400 text-sm">Players</h4>
                            </div>
                            <div className="flex items-baseline space-x-2">
                                <div className="text-gray-50 font-bold text-lg">
                                    {serverInfo.loading ? '...' : serverInfo.players}
                                </div>
                                <span className="text-gray-400 text-sm">/</span>
                                <div className="text-gray-400 text-lg">
                                    {serverInfo.loading ? '...' : serverInfo.maxPlayers}
                                </div>
                            </div>
                            <p className="text-gray-400 text-xs mt-1">
                                Current player count
                            </p>
                        </InfoCard>
                    </div>

                    {/* MOTD Display */}
                    {serverInfo.motd && serverInfo.online && (
                        <InfoCard>
                            <div className="flex items-center space-x-3 mb-2">
                                <RiInformationLine className="text-yellow-400 text-lg" />
                                <h4 className="font-semibold text-gray-400 text-sm">Server MOTD</h4>
                            </div>
                            <div className="text-gray-50 text-sm font-mono bg-gray-900/50 p-3 rounded border border-gray-700">
                                {serverInfo.motd}
                            </div>
                        </InfoCard>
                    )}

                    {/* Error Display */}
                    {serverInfo.error && (
                        <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-lg">
                            <div className="flex items-center space-x-2 text-red-300">
                                <RiErrorWarningLine />
                                <span className="font-medium">Connection Error</span>
                            </div>
                            <p className="text-red-200 text-sm mt-1">{serverInfo.error}</p>
                            <p className="text-red-300 text-xs mt-2">
                                Using fallback server information from panel data.
                            </p>
                        </div>
                    )}
                </div>
            </TitledGreyBox>

            {/* Tabs */}
            <TabContainer>
                <TabButton
                    active={activeTab === 'installed'}
                    onClick={() => setActiveTab('installed')}
                >
                    <RiBox3Line className="mr-2" />
                    Installed Plugins
                </TabButton>
                <TabButton
                    active={activeTab === 'browse'}
                    onClick={() => setActiveTab('browse')}
                >
                    <RiDownloadLine className="mr-2" />
                    Browse Plugins
                </TabButton>
            </TabContainer>

            {/* Tab Content */}
            <ContentContainer>
                {activeTab === 'installed' && <InstalledPluginsTab />}
                {activeTab === 'browse' && <BrowsePluginsTab />}
            </ContentContainer>
        </ServerContentBlock>
    );
};
