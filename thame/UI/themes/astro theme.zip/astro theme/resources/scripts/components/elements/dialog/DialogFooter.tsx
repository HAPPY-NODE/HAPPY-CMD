import React, { useContext } from 'react';
import { DialogContext } from './';
import { useDeepCompareEffect } from '@/plugins/useDeepCompareEffect';
import tw, { styled } from 'twin.macro';

const FooterContainer = styled.div`
  ${tw`flex items-center justify-end space-x-3 p-6 bg-neutral-900/30 border-t border-neutral-700/50`};
`;

export default ({ children }: { children: React.ReactNode }) => {
    const { setFooter } = useContext(DialogContext);

    useDeepCompareEffect(() => {
        setFooter(<FooterContainer>{children}</FooterContainer>);
    }, [children]);

    return null;
};