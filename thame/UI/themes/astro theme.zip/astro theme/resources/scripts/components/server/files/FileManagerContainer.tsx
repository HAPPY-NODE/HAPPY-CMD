import React, { useEffect, useState } from 'react';
import { httpErrorToHuman } from '@/api/http';
import { CSSTransition } from 'react-transition-group';
import Spinner from '@/components/elements/Spinner';
import FileObjectRow from '@/components/server/files/FileObjectRow';
import FileManagerBreadcrumbs from '@/components/server/files/FileManagerBreadcrumbs';
import { FileObject } from '@/api/server/files/loadDirectory';
import NewDirectoryButton from '@/components/server/files/NewDirectoryButton';
import { NavLink, useLocation, useRouteMatch } from 'react-router-dom';
import Can from '@/components/elements/Can';
import { ServerError } from '@/components/elements/ScreenBlock';
import tw from 'twin.macro';
import { Button } from '@/components/elements/button/index';
import { ServerContext } from '@/state/server';
import useFileManagerSwr from '@/plugins/useFileManagerSwr';
import FileManagerStatus from '@/components/server/files/FileManagerStatus';
import MassActionsBar from '@/components/server/files/MassActionsBar';
import UploadButton from '@/components/server/files/UploadButton';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import { useStoreActions } from '@/state/hooks';
import ErrorBoundary from '@/components/elements/ErrorBoundary';
import { FileActionCheckbox } from '@/components/server/files/SelectFileCheckbox';
import { hashToPath, encodePathSegments } from '@/helpers';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  FaFile, 
  FaFolder, 
  FaServer,
  FaSearch,
  FaFilter,
  FaSortAmountDown,
  FaTh,
  FaList,
  FaSync,
  FaInfoCircle,
  FaArchive
} from 'react-icons/fa';
import { bytesToString } from '@/lib/formatters';
import { differenceInHours, format, formatDistanceToNow } from 'date-fns';
import FileDropdownMenu from '@/components/server/files/FileDropdownMenu';
import { usePermissions } from '@/plugins/usePermissions';
import { join } from 'path';
import isEqual from 'react-fast-compare';

// Sort files function
const sortFiles = (files: FileObject[]): FileObject[] => {
    return files
        .sort((a, b) => a.name.localeCompare(b.name))
        .sort((a, b) => (a.isFile === b.isFile ? 0 : a.isFile ? 1 : -1));
};

// Clickable component for file/folder navigation
const Clickable = React.memo(({ file, children }: { file: FileObject; children: React.ReactNode }) => {
    const [canRead] = usePermissions(['file.read']);
    const [canReadContents] = usePermissions(['file.read-content']);
    const directory = ServerContext.useStoreState((state) => state.files.directory);
    const match = useRouteMatch();

    return (file.isFile && (!file.isEditable() || !canReadContents)) || (!file.isFile && !canRead) ? (
        <div css={tw`flex-1 flex items-center min-w-0`}>{children}</div>
    ) : (
        <NavLink
            css={tw`flex-1 flex items-center min-w-0 hover:text-indigo-300 transition-colors duration-200`}
            to={`${match.url}${file.isFile ? '/edit' : ''}#${encodePathSegments(join(directory, file.name))}`}
        >
            {children}
        </NavLink>
    );
}, isEqual);

// Grid view item component
const FileObjectGridItem = ({ file }: { file: FileObject }) => (
    <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        transition={{ duration: 0.2 }}
        className="group relative bg-[#17192b] rounded-2xl border border-white/10 p-4 hover:bg-[#22243b] hover:shadow-lg transition-all duration-200 cursor-pointer"
        onContextMenu={(e) => {
            e.preventDefault();
            window.dispatchEvent(new CustomEvent(`pterodactyl:files:ctx:${file.key}`, { detail: e.clientX }));
        }}
    >
        {/* Checkbox + Context Menu */}
        <div className="absolute top-3 right-3 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
            <FileActionCheckbox type={'checkbox'} name={file.name} />
            <FileDropdownMenu file={file} />
        </div>

        {/* Clickable Area */}
        <Clickable file={file}>
            <div className="flex flex-col items-center text-center gap-2">
                {/* Icon */}
                <div className="text-5xl mb-2">
                    {file.isFile ? (
                        file.isArchiveType() ? (
                            <FaArchive className="text-blue-400" />
                        ) : (
                            <FaFile className={file.isSymlink ? 'text-purple-400' : 'text-indigo-400'} />
                        )
                    ) : (
                        <FaFolder className="text-yellow-400" />
                    )}
                </div>

                {/* Name */}
                <div className="text-sm font-medium text-gray-200 truncate w-full px-1">
                    {file.name}
                </div>

                {/* File Info (Size or Folder) */}
                <div className="text-xs text-gray-400">
                    {file.isFile ? bytesToString(file.size) : 'Folder'}
                </div>

                {/* Modified Date */}
                <div className="text-[11px] text-gray-500" title={file.modifiedAt.toString()}>
                    {Math.abs(differenceInHours(file.modifiedAt, new Date())) > 48
                        ? format(file.modifiedAt, 'MMM d, yyyy')
                        : formatDistanceToNow(file.modifiedAt, { addSuffix: true })}
                </div>
            </div>
        </Clickable>
    </motion.div>
);

export default () => {
    const id = ServerContext.useStoreState((state) => state.server.data!.id);
    const { hash } = useLocation();
    const { data: files, error, mutate } = useFileManagerSwr();
    const directory = ServerContext.useStoreState((state) => state.files.directory);
    const clearFlashes = useStoreActions((actions) => actions.flashes.clearFlashes);
    const setDirectory = ServerContext.useStoreActions((actions) => actions.files.setDirectory);
    const setSelectedFiles = ServerContext.useStoreActions((actions) => actions.files.setSelectedFiles);
    const selectedFilesLength = ServerContext.useStoreState((state) => state.files.selectedFiles.length);

    // State for enhanced features
    const [searchQuery, setSearchQuery] = useState('');
    const [viewMode, setViewMode] = useState<'list' | 'grid'>('list');
    const [sortBy, setSortBy] = useState<'name' | 'size' | 'date'>('name');
    const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
    const [selectedCategory, setSelectedCategory] = useState<'all' | 'files' | 'folders'>('all');
    const [showInfo, setShowInfo] = useState(false);

    // Add drag and drop handlers for the main container
    const handleDragOver = (e: React.DragEvent) => {
        e.preventDefault();
        e.stopPropagation();
    };

    const handleDrop = (e: React.DragEvent) => {
        e.preventDefault();
        e.stopPropagation();
        
        // Don't handle the drop here if files are dropped - let the UploadButton modal handle it
        // This just prevents the browser's default behavior of opening the file
    };

    useEffect(() => {
        clearFlashes('files');
        setSelectedFiles([]);
        setDirectory(hashToPath(hash));
    }, [hash]);

    useEffect(() => {
        mutate();
    }, [directory]);

    const onSelectAllClick = (e: React.ChangeEvent<HTMLInputElement>) => {
        setSelectedFiles(e.currentTarget.checked ? (files || []).map((file) => file.name) : []);
    };

    // Filter and sort files based on user preferences
    const filteredFiles = files
        ? files
              .filter((file) => {
                  // Search filter
                  if (searchQuery && !file.name.toLowerCase().includes(searchQuery.toLowerCase())) {
                      return false;
                  }

                  // Category filter
                  if (selectedCategory === 'files' && !file.isFile) return false;
                  if (selectedCategory === 'folders' && file.isFile) return false;

                  return true;
              })
              .sort((a, b) => {
                  // Always put folders before files
                  if (a.isFile !== b.isFile) return a.isFile ? 1 : -1;

                  // Sorting logic within groups
                  if (sortBy === 'name') {
                      return sortOrder === 'asc'
                          ? a.name.localeCompare(b.name)
                          : b.name.localeCompare(a.name);
                  } else if (sortBy === 'size') {
                      return sortOrder === 'asc'
                          ? (a.size || 0) - (b.size || 0)
                          : (b.size || 0) - (a.size || 0);
                  } else if (sortBy === 'date') {
                      return sortOrder === 'asc'
                          ? new Date(a.modifiedAt).getTime() - new Date(b.modifiedAt).getTime()
                          : new Date(b.modifiedAt).getTime() - new Date(a.modifiedAt).getTime();
                  }
                  return 0;
              })
        : [];

    if (error) {
        return <ServerError message={httpErrorToHuman(error)} onRetry={() => mutate()} />;
    }

    const filesLength = files ? files.length : 0;
    const isAllSelected = filesLength > 0 && selectedFilesLength === filesLength;

    return (
        // Add drag and drop event handlers to the main container
        <div 
            onDragOver={handleDragOver}
            onDrop={handleDrop}
        >
            <ServerContentBlock title={'File Manager'} showFlashKey={'files'}>
                <ErrorBoundary>
                    <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.5 }}
                        className="mb-6"
                    >
                        <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 gap-4">
                            <div className="flex items-center">
                                <div className="p-3 rounded-xl bg-indigo-900/20 mr-3">
                                    <FaServer className="text-indigo-400 text-xl" />
                                </div>
                                <div>
                                    <h1 className="text-2xl font-bold text-white">File Manager</h1>
                                    <p className="text-neutral-400 mt-1">Manage your server files and directories</p>
                                </div>
                            </div>
                            
                            <div className="flex items-center gap-2">
                                <Button 
                                    onClick={() => mutate()} 
                                    className="flex items-center gap-2 bg-gray-700 hover:bg-gray-600 border-gray-600"
                                >
                                    <FaSync className="text-sm" />
                                    Refresh
                                </Button>
                                <Button 
                                    onClick={() => setShowInfo(!showInfo)} 
                                    className="flex items-center gap-2 bg-gray-700 hover:bg-gray-600 border-gray-600"
                                >
                                    <FaInfoCircle className="text-sm" />
                                    Info
                                </Button>
                            </div>
                        </div>
                        
                        <AnimatePresence>
                            {showInfo && (
                                <motion.div 
                                    initial={{ opacity: 0, height: 0 }}
                                    animate={{ opacity: 1, height: 'auto' }}
                                    exit={{ opacity: 0, height: 0 }}
                                    className="bg-[#17192b] rounded-xl p-4 mb-6 border border-gray-700/30"
                                >
                                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                                        <div className="flex flex-col">
                                            <span className="text-gray-400">Directory</span>
                                            <span className="text-gray-200 font-mono truncate">{directory || '/'}</span>
                                        </div>
                                        <div className="flex flex-col">
                                            <span className="text-gray-400">Total Items</span>
                                            <span className="text-gray-200">{filesLength}</span>
                                        </div>
                                        <div className="flex flex-col">
                                            <span className="text-gray-400">Selected</span>
                                            <span className="text-gray-200">{selectedFilesLength}</span>
                                        </div>
                                    </div>
                                </motion.div>
                            )}
                        </AnimatePresence>
                        
                        <div className="bg-[#17192b] rounded-xl p-4 mb-6 border border-gray-700/30">
                            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
                                <div className="flex flex-col sm:flex-row gap-2 w-full md:w-auto">
                                    <div className="relative flex-1">
                                        <FaSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                                        <input
                                            type="text"
                                            placeholder="Search files..."
                                            value={searchQuery}
                                            onChange={(e) => setSearchQuery(e.target.value)}
                                            className="pl-10 pr-4 py-2 w-full bg-[#313449] border border-gray-600/60 rounded-lg text-gray-200 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                                        />
                                    </div>
                                    
                                    <div className="relative">
                                        <select
                                            value={selectedCategory}
                                            onChange={(e) => setSelectedCategory(e.target.value as any)}
                                            className="pl-10 pr-8 py-2 bg-[#313449] border border-gray-600/60 rounded-lg text-gray-200 appearance-none focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                                        >
                                            <option value="all">All Items</option>
                                            <option value="files">Files Only</option>
                                            <option value="folders">Folders Only</option>
                                        </select>
                                        <FaFilter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 pointer-events-none" />
                                    </div>
                                </div>
                                
                                <div className="flex flex-col sm:flex-row gap-2 w-full md:w-auto">
                                    
                                    <div className="flex gap-2">
                                        <div className="relative">
                                            <select
                                                value={sortBy}
                                                onChange={(e) => setSortBy(e.target.value as any)}
                                                className="pl-10 pr-8 py-2 bg-[#313449] border border-gray-600/60 rounded-lg text-gray-200 appearance-none focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                                            >
                                                <option value="name">Sort by Name</option>
                                                <option value="size">Sort by Size</option>
                                                <option value="date">Sort by Date</option>
                                            </select>
                                            <FaSortAmountDown className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 pointer-events-none" />
                                        </div>
                                        
                                        <button
                                            onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
                                            className={`p-2 bg-[#313449] border border-gray-600/60 rounded-lg text-gray-200 hover:bg-gray-600 ${sortOrder === 'desc' ? 'rotate-180' : ''}`}
                                        >
                                            <FaSortAmountDown />
                                        </button>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                                <FileManagerBreadcrumbs
                                    renderLeft={
                                        <FileActionCheckbox
                                            type={'checkbox'}
                                            css={tw`mx-4`}
                                            checked={isAllSelected}
                                            onChange={onSelectAllClick}
                                        />
                                    }
                                />
                                <Can action={'file.create'}>
                                    <div className="flex flex-wrap gap-2">
                                        <FileManagerStatus />
                                        <NewDirectoryButton />
                                        <UploadButton />
                                        <NavLink to={`/server/${id}/files/new${window.location.hash}`}>
                                            <Button className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 border-indigo-700">
                                                <FaFile className="text-sm" />
                                                New File
                                            </Button>
                                        </NavLink>
                                    </div>
                                </Can>
                            </div>
                        </div>
                    </motion.div>
                </ErrorBoundary>
                
                {!files ? (
                    <div className="flex justify-center items-center py-20">
                        <Spinner size={'large'} />
                    </div>
                ) : (
                    <>
                        {filesLength === 0 ? (
                            <motion.div 
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                                transition={{ duration: 0.5 }}
                                className="flex flex-col items-center justify-center py-16 text-center bg-[#1a1b2fb3] rounded-xl border border-dashed border-gray-700/50"
                            >
                                <FaFolder className="text-4xl text-gray-500 mb-4" />
                                <h3 className="text-lg font-medium text-gray-300 mb-2">No files found</h3>
                                <p className="text-gray-500 mb-6">This directory seems to be empty.</p>
                                <Can action={'file.create'}>
                                    <div className="flex gap-3">
                                        <NewDirectoryButton />
                                        <UploadButton />
                                    </div>
                                </Can>
                            </motion.div>
                        ) : (
                            <CSSTransition classNames={'fade'} timeout={150} appear in>
                                <motion.div
                                    initial={{ opacity: 0 }}
                                    animate={{ opacity: 1 }}
                                    transition={{ duration: 0.5, delay: 0.2 }}
                                >
                                    {filesLength > 250 && (
                                        <div className="rounded-xl bg-yellow-500/10 border border-yellow-500/20 mb-4 p-4">
                                            <p className="text-yellow-400 text-sm text-center">
                                                This directory is too large to display in the browser, limiting the output
                                                to the first 250 files.
                                            </p>
                                        </div>
                                    )}
                                    
                                    {viewMode === 'list' ? (
                                        <div className="bg-[#17192b] rounded-xl overflow-hidden border border-white/10">
                                            <div className="grid grid-cols-12 gap-4 p-4 border-b border-gray-700/30 text-sm text-gray-400 font-medium">
                                                <div className="col-span-1 text-center">
                                                    <span className="sr-only">Select</span>
                                                </div>
                                                <div className="col-span-5">Name</div>
                                                <div className="col-span-2 text-center">Type</div>
                                                <div className="col-span-2 text-right">Size</div>
                                                <div className="col-span-2 text-right">Modified</div>
                                            </div>
                                            <div className="divide-y divide-gray-700/30">
                                                <AnimatePresence>
                                                    {filteredFiles.slice(0, 250).map((file, index) => (
                                                        <motion.div
                                                            key={file.key}
                                                            initial={{ opacity: 0, y: 10 }}
                                                            animate={{ opacity: 1, y: 0 }}
                                                            exit={{ opacity: 0, height: 0 }}
                                                            transition={{ duration: 0.2, delay: index * 0.01 }}
                                                        >
                                                            <FileObjectRow file={file} />
                                                        </motion.div>
                                                    ))}
                                                </AnimatePresence>
                                            </div>
                                        </div>
                                    ) : (
                                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                                            <AnimatePresence>
                                                {filteredFiles.slice(0, 250).map((file, index) => (
                                                    <FileObjectGridItem key={file.key} file={file} />
                                                ))}
                                            </AnimatePresence>
                                        </div>
                                    )}
                                    <MassActionsBar />
                                </motion.div>
                            </CSSTransition>
                        )}
                    </>
                )}
            </ServerContentBlock>
        </div>
    );
};