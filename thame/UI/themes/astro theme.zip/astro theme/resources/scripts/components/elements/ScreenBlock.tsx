import React from 'react';
import PageContentBlock from '@/components/elements/PageContentBlock';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowLeft, faSyncAlt, faRocket, faSearch, faExclamationTriangle, faCogs } from '@fortawesome/free-solid-svg-icons';
import styled, { keyframes } from 'styled-components/macro';
import tw from 'twin.macro';
import Button from '@/components/elements/Button';
import NotFoundSvg from '@/assets/images/not_found.svg';
import ServerErrorSvg from '@/assets/images/server_error.svg';

interface BaseProps {
    title: string;
    image: string;
    message: string;
    onRetry?: () => void;
    onBack?: () => void;
    subtitle?: string;
    actionText?: string;
}

interface PropsWithRetry extends BaseProps {
    onRetry?: () => void;
    onBack?: never;
}

interface PropsWithBack extends BaseProps {
    onBack?: () => void;
    onRetry?: never;
}

export type ScreenBlockProps = PropsWithBack | PropsWithRetry;

const float = keyframes`
    0%, 100% { transform: translateY(0px) rotate(0deg); }
    50% { transform: translateY(-20px) rotate(5deg); }
`;

const glow = keyframes`
    0%, 100% { box-shadow: 0 0 20px rgba(139, 92, 246, 0.3); }
    50% { box-shadow: 0 0 40px rgba(139, 92, 246, 0.6); }
`;

const spin = keyframes`
    to { transform: rotate(360deg) }
`;

const pulse = keyframes`
    0%, 100% { opacity: 1; }
    50% { opacity: 0.7; }
`;

const Container = styled.div`
    ${tw`min-h-screen flex items-center justify-center p-4`};
    position: relative;
    overflow: hidden;
`;

const Card = styled.div`
    ${tw`relative w-full max-w-2xl rounded-3xl text-center z-10`};
    background: rgba(30, 41, 59, 0.8);
    backdrop-filter: blur(20px);
    border: 1px solid rgba(255, 255, 255, 0.1);
    box-shadow: 
        0 25px 50px rgba(0, 0, 0, 0.5),
        inset 0 1px 0 rgba(255, 255, 255, 0.1);
    padding: 3rem;

    &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: linear-gradient(135deg, rgb(0 126 255 / 25%) 0%, transparent 50%);
        border-radius: 1.6rem;
        z-index: -1;
    }
`;

const FloatingImage = styled.div`
    animation: ${float} 6s ease-in-out infinite;
    filter: drop-shadow(0 20px 40px rgba(0, 0, 0, 0.3));
`;

const ActionButton = styled(Button)`
    ${tw`rounded-full w-12 h-12 flex items-center justify-center p-0 relative overflow-hidden`};
    background: linear-gradient(135deg, #8b5cf6 0%, #6366f1 100%);
    border: none;
    animation: ${glow} 3s ease-in-out infinite;
    transition: all 0.3s ease;

    &:hover {
        transform: scale(1.1);
        animation: none;
        box-shadow: 0 0 30px rgba(139, 92, 246, 0.8) !important;
    }

    &::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
        transition: left 0.5s;
    }

    &:hover::before {
        left: 100%;
    }
`;

const SecondaryButton = styled(Button)`
    ${tw`rounded-full px-8 py-3 font-semibold transition-all duration-300`};
    background: rgba(255, 255, 255, 0.1);
    border: 1px solid rgba(255, 255, 255, 0.2);
    color: #e2e8f0;
    backdrop-filter: blur(10px);

    &:hover {
        background: rgba(255, 255, 255, 0.2);
        transform: translateY(-2px);
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
    }
`;

const StatusIndicator = styled.div<{ type: 'loading' | 'error' | 'success' }>`
    ${tw`w-4 h-4 rounded-full mx-auto mb-6`};
    ${props => props.type === 'loading' && tw`bg-yellow-400 animate-pulse`};
    ${props => props.type === 'error' && tw`bg-red-400`};
    ${props => props.type === 'success' && tw`bg-green-400`};
    box-shadow: 0 0 20px ${props => 
        props.type === 'loading' ? 'rgba(234, 179, 8, 0.5)' :
        props.type === 'error' ? 'rgba(239, 68, 68, 0.5)' :
        'rgba(34, 197, 94, 0.5)'};
`;

const ScreenBlock = ({ title, image, message, onBack, onRetry, subtitle, actionText }: ScreenBlockProps) => (
    <Container>
        <Card>
            {/* Action Button */}
            {(typeof onBack === 'function' || typeof onRetry === 'function') && (
                <div css={tw`absolute left-6 top-6`}>
                    <ActionButton
                        onClick={() => (onRetry ? onRetry() : onBack ? onBack() : null)}
                        className={onRetry ? 'hover:spin' : undefined}
                    >
                        <FontAwesomeIcon 
                            icon={onRetry ? faSyncAlt : faArrowLeft} 
                            css={tw`text-white text-lg`}
                        />
                    </ActionButton>
                </div>
            )}

            {/* Status Indicator */}
            <StatusIndicator type={onRetry ? 'error' : 'loading'} />

            {/* Image */}
            <FloatingImage>
                <img 
                    src={image} 
                    css={tw`w-48 h-48 select-none mx-auto mb-8`} 
                    alt={title}
                />
            </FloatingImage>

            {/* Subtitle */}
            {subtitle && (
                <p css={tw`text-indigo-300 text-sm font-semibold uppercase tracking-wider mb-2`}>
                    {subtitle}
                </p>
            )}

            {/* Title */}
            <h1 css={tw`text-5xl font-bold bg-gradient-to-r from-[#8bebfa] to-[#005aff] bg-clip-text text-transparent mb-4`}>
                {title}
            </h1>

            {/* Message */}
            <p css={tw`text-neutral-300 text-lg leading-relaxed max-w-md mx-auto mb-8`}>
                {message}
            </p>

            {/* Secondary Action Button */}
            {(onBack || onRetry) && (
                <SecondaryButton
                    onClick={() => (onRetry ? onRetry() : onBack ? onBack() : null)}
                    css={tw`mx-auto`}
                >
                    <FontAwesomeIcon 
                        icon={onRetry ? faSyncAlt : faArrowLeft} 
                        css={tw`mr-2`}
                    />
                    {actionText || (onRetry ? 'Try Again' : 'Go Back')}
                </SecondaryButton>
            )}
        </Card>

        {/* Background Decorations */}
        <div css={tw`absolute top-1/4 left-1/4 w-2 h-2 rounded-full bg-blue-400 opacity-60`}></div>
        <div css={tw`absolute top-1/3 right-1/4 w-1 h-1 rounded-full bg-blue-400 opacity-40`}></div>
        <div css={tw`absolute bottom-1/4 left-1/3 w-3 h-3 rounded-full bg-blue-400 opacity-30`}></div>
        <div css={tw`absolute bottom-1/3 right-1/3 w-1 h-1 rounded-full bg-blue-400 opacity-50`}></div>
    </Container>
);

type ServerErrorProps = (Omit<PropsWithBack, 'image' | 'title'> | Omit<PropsWithRetry, 'image' | 'title'>) & {
    title?: string;
    subtitle?: string;
};

const ServerError = ({ title, subtitle, ...props }: ServerErrorProps) => (
    <ScreenBlock 
        title={title || 'Server Error'} 
        image={ServerErrorSvg}
        subtitle={subtitle || 'Something went wrong'}
        message="We encountered an unexpected error. Please try again or contact support if the problem persists."
        {...props} 
    />
);

const NotFound = ({ title, message, subtitle, onBack, actionText }: Partial<Pick<ScreenBlockProps, 'title' | 'message' | 'onBack' | 'subtitle' | 'actionText'>>) => (
    <ScreenBlock
        title={title || '404'}
        image={NotFoundSvg}
        subtitle={subtitle || 'Page Not Found'}
        message={message || 'The page you are looking for doesn\'t exist or has been moved.'}
        onBack={onBack}
        actionText={actionText}
    />
);

// New specialized components for common scenarios
const InstallingServer = ({ progress, onCancel }: { progress?: number; onCancel?: () => void }) => (
    <ScreenBlock
        title="Installing Server"
        image={ServerErrorSvg} // You might want a dedicated installing image
        subtitle="Setting up your environment"
        message={progress ? `Installation is ${progress}% complete...` : "Your server is being installed. This may take a few minutes."}
        onBack={onCancel}
        actionText="Cancel Installation"
    />
);

const LoadingScreen = ({ message }: { message?: string }) => (
    <ScreenBlock
        title="Loading"
        image={ServerErrorSvg} // You might want a dedicated loading image
        subtitle="Please wait"
        message={message || "We're getting everything ready for you..."}
    />
);

const MaintenanceMode = ({ estimatedTime }: { estimatedTime?: string }) => (
    <ScreenBlock
        title="Maintenance"
        image={ServerErrorSvg} // You might want a dedicated maintenance image
        subtitle="Temporary Maintenance"
        message={estimatedTime 
            ? `We're performing maintenance. Estimated completion: ${estimatedTime}`
            : "We're performing maintenance. Please check back soon."
        }
    />
);

export { ServerError, NotFound, InstallingServer, LoadingScreen, MaintenanceMode };
export default ScreenBlock;