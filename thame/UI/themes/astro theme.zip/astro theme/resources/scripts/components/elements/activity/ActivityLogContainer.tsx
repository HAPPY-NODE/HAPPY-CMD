import React, { useState } from 'react';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import { useActivityLogs } from '@/api/account/activity';
import Spinner from '@/components/elements/Spinner';
import { Pagination } from '@/components/elements/Pagination';
import ActivityLogItem from '@/components/elements/activity/ActivityLogItem';
import { RiHistoryLine, RiFilterLine, RiSearchLine } from 'react-icons/ri';
import tw, { styled } from 'twin.macro';
import Input from '@/components/elements/Input';
import Select from '@/components/elements/Select';

const Header = styled.div`
  ${tw`flex items-center justify-between mb-6`};
`;

const PageTitle = styled.h1`
  ${tw`text-2xl font-bold`};
  background: linear-gradient(90deg, #EEE 0%, #CCC 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
`;

const FilterBar = styled.div`
  ${tw`flex flex-col md:flex-row items-center space-y-4 md:space-y-0 md:space-x-4 mb-6 p-4 rounded-xl`};
  background: rgba(31, 34, 53, 0.5);
  border: 1px solid rgba(255, 255, 255, 0.07);
`;

const FilterGroup = styled.div`
  ${tw`flex-1 flex flex-col md:flex-row md:items-center space-y-4 md:space-y-0 md:space-x-4`};
`;

const ActivityList = styled.div`
  ${tw`space-y-3`};
`;

const EmptyState = styled.div`
  ${tw`text-center py-12 rounded-xl`};
  background: rgba(31, 34, 53, 0.5);
  border: 1px dashed rgba(255, 255, 255, 0.1);
`;

export default () => {
    const [page, setPage] = useState(1);
    const [search, setSearch] = useState('');
    const [filter, setFilter] = useState('all');
    const { data, error, isValidating } = useActivityLogs({ page, search, filter });

    if (!data || error) {
        return <Spinner size={'large'} centered />;
    }

    return (
        <ServerContentBlock title={'Activity Log'}>
            <Header>
                <div className="flex items-center">
                    <RiHistoryLine className="text-indigo-400 mr-3 text-2xl" />
                    <PageTitle>Activity Log</PageTitle>
                </div>
            </Header>

            <FilterBar>
                <FilterGroup>
                    <div className="flex-1">
                        <Input
                            icon={RiSearchLine}
                            placeholder="Search activities..."
                            value={search}
                            onChange={e => setSearch(e.target.value)}
                        />
                    </div>
                    <div className="w-full md:w-48">
                        <Select value={filter} onChange={e => setFilter(e.target.value)}>
                            <option value="all">All Events</option>
                            <option value="api">API Events</option>
                            <option value="sftp">SFTP Events</option>
                            <option value="create">Create Events</option>
                            <option value="delete">Delete Events</option>
                            <option value="update">Update Events</option>
                        </Select>
                    </div>
                </FilterGroup>
                <div className="flex items-center text-sm text-neutral-400">
                    <RiFilterLine className="mr-2" />
                    {data.pagination.total} events total
                </div>
            </FilterBar>

            {data.pagination.total > 0 ? (
                <>
                    <ActivityList>
                        {data.items.map((activity) => (
                            <ActivityLogItem key={activity.id} activity={activity} />
                        ))}
                    </ActivityList>

                    <Pagination
                        data={data.pagination}
                        onPageSelect={setPage}
                        className="mt-6"
                    />
                </>
            ) : (
                <EmptyState>
                    <RiHistoryLine className="text-neutral-500 text-4xl mb-4" />
                    <p className="text-center text-sm text-neutral-400">
                        {search || filter !== 'all' 
                            ? 'No activities found matching your filters.' 
                            : 'No activities have been recorded yet.'
                        }
                    </p>
                    {(search || filter !== 'all') && (
                        <button
                            onClick={() => {
                                setSearch('');
                                setFilter('all');
                            }}
                            className="text-indigo-400 hover:text-indigo-300 text-sm mt-2"
                        >
                            Clear filters
                        </button>
                    )}
                </EmptyState>
            )}
        </ServerContentBlock>
    );
};