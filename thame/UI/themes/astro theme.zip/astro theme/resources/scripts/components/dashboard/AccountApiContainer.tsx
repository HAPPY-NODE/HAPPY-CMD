import React, { useEffect, useState } from 'react';
import ContentBox from '@/components/elements/ContentBox';
import CreateApiKeyForm from '@/components/dashboard/forms/CreateApiKeyForm';
import getApiKeys, { ApiKey } from '@/api/account/getApiKeys';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';
import FlashMessageRender from '@/components/FlashMessageRender';
import { format } from 'date-fns';
import PageContentBlock from '@/components/elements/PageContentBlock';
import tw, { styled } from 'twin.macro';
import { Dialog } from '@/components/elements/dialog';
import { useFlashKey } from '@/plugins/useFlash';
import Code from '@/components/elements/Code';
import { RiKeyLine, RiDeleteBinLine, RiTimeLine, RiFileListLine } from 'react-icons/ri';

const ApiGrid = styled.div`
    ${tw`grid grid-cols-1 lg:grid-cols-2 gap-6 my-10`};
`;

const ApiKeyList = styled.div`
    ${tw`space-y-3`};
`;

const ApiKeyCard = styled.div`
    ${tw`p-4 rounded-xl relative`};
    background: rgba(31, 34, 53, 0.7);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.1);
    box-shadow: 
        0 4px 15px rgba(0, 0, 0, 0.15), 
        0 0 0 1px rgba(255, 255, 255, 0.05),
        inset 0 0 20px rgba(255, 255, 255, 0.03);
    transition: all 0.3s ease;
    
    &:hover {
        transform: translateY(-2px);
        box-shadow: 
            0 8px 25px rgba(0, 0, 0, 0.25),
            0 0 0 1px rgba(99, 102, 241, 0.1),
            inset 0 0 20px rgba(255, 255, 255, 0.05);
    }
`;

const ApiKeyHeader = styled.div`
    ${tw`flex items-center justify-between mb-3`};
`;

const ApiKeyInfo = styled.div`
    ${tw`flex-1`};
`;

const ApiKeyDescription = styled.p`
    ${tw`text-sm font-medium text-neutral-200 mb-1`};
`;

const ApiKeyMeta = styled.div`
    ${tw`flex items-center text-xs text-neutral-400 space-x-4`};
`;

const ApiKeyIdentifier = styled.code`
    ${tw`font-mono text-xs bg-neutral-800/50 px-2 py-1 rounded`};
`;

const DeleteButton = styled.button`
    ${tw`p-2 text-neutral-400 hover:text-red-400 transition-colors duration-200`};
`;

const Header = styled.div`
    ${tw`flex items-center mb-8`};
    
    h1 {
        ${tw`text-2xl font-bold`};
        background: linear-gradient(90deg, #EEE 0%, #CCC 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
    }
`;

const EmptyState = styled.div`
    ${tw`text-center py-8 rounded-xl`};
    background: rgba(31, 34, 53, 0.5);
    border: 1px dashed rgba(255, 255, 255, 0.1);
`;

export default () => {
    const [deleteIdentifier, setDeleteIdentifier] = useState('');
    const [keys, setKeys] = useState<ApiKey[]>([]);
    const [loading, setLoading] = useState(true);
    const { clearAndAddHttpError } = useFlashKey('account');

    useEffect(() => {
        getApiKeys()
            .then((keys) => setKeys(keys))
            .then(() => setLoading(false))
            .catch((error) => clearAndAddHttpError(error));
    }, []);

    const doDeletion = (identifier: string) => {
        setLoading(true);

        clearAndAddHttpError();
        deleteApiKey(identifier)
            .then(() => setKeys((s) => [...(s || []).filter((key) => key.identifier !== identifier)]))
            .catch((error) => clearAndAddHttpError(error))
            .then(() => {
                setLoading(false);
                setDeleteIdentifier('');
            });
    };

    return (
        <PageContentBlock title={'Account API'}>
            <Header>
                <RiKeyLine className="text-indigo-400 mr-3 text-2xl" />
                <h1>API Management</h1>
            </Header>

            <FlashMessageRender byKey={'account'} className="mb-6" />
            
            <ApiGrid>
                <ContentBox title={'Create New API Key'} icon={RiKeyLine}>
                    <CreateApiKeyForm onKeyCreated={(key) => setKeys((s) => [...s!, key])} />
                </ContentBox>
                
                <ContentBox title={'API Keys'} icon={RiFileListLine}>
                    <SpinnerOverlay visible={loading} />
                    <Dialog.Confirm
                        title={'Delete API Key'}
                        confirm={'Delete Key'}
                        open={!!deleteIdentifier}
                        onClose={() => setDeleteIdentifier('')}
                        onConfirmed={() => doDeletion(deleteIdentifier)}
                    >
                        All requests using the <Code>{deleteIdentifier}</Code> key will be invalidated.
                    </Dialog.Confirm>
                    
                    {keys.length === 0 ? (
                        <EmptyState>
                            <RiKeyLine className="text-neutral-500 text-3xl mb-3 mx-auto" />
                            <p className="text-sm text-neutral-400">
                                {loading ? 'Loading API keys...' : 'No API keys exist for this account.'}
                            </p>
                            {!loading && (
                                <p className="text-xs text-neutral-500 mt-1">
                                    Create your first API key to get started.
                                </p>
                            )}
                        </EmptyState>
                    ) : (
                        <ApiKeyList>
                            {keys.map((key) => (
                                <ApiKeyCard key={key.identifier}>
                                    <ApiKeyHeader>
                                        <ApiKeyInfo>
                                            <ApiKeyDescription>{key.description}</ApiKeyDescription>
                                            <ApiKeyMeta>
                                                <span className="flex items-center">
                                                    <RiTimeLine className="mr-1" />
                                                    Last used: {key.lastUsedAt ? format(key.lastUsedAt, 'MMM do, yyyy HH:mm') : 'Never'}
                                                </span>
                                                <ApiKeyIdentifier>{key.identifier}</ApiKeyIdentifier>
                                            </ApiKeyMeta>
                                        </ApiKeyInfo>
                                        <DeleteButton onClick={() => setDeleteIdentifier(key.identifier)}>
                                            <RiDeleteBinLine />
                                        </DeleteButton>
                                    </ApiKeyHeader>
                                </ApiKeyCard>
                            ))}
                        </ApiKeyList>
                    )}
                </ContentBox>
            </ApiGrid>
        </PageContentBlock>
    );
};