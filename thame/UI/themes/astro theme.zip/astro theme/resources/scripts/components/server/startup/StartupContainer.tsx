import React, { useCallback, useEffect, useState } from 'react';
import TitledGreyBox from '@/components/elements/TitledGreyBox';
import tw, { styled, css } from 'twin.macro';
import VariableBox from '@/components/server/startup/VariableBox';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import getServerStartup from '@/api/swr/getServerStartup';
import Spinner from '@/components/elements/Spinner';
import { ServerError } from '@/components/elements/ScreenBlock';
import { httpErrorToHuman } from '@/api/http';
import { ServerContext } from '@/state/server';
import { useDeepCompareEffect } from '@/plugins/useDeepCompareEffect';
import Select from '@/components/elements/Select';
import isEqual from 'react-fast-compare';
import Input from '@/components/elements/Input';
import setSelectedDockerImage from '@/api/server/setSelectedDockerImage';
import InputSpinner from '@/components/elements/InputSpinner';
import useFlash from '@/plugins/useFlash';
import { RiTerminalLine, RiDossierLine, RiSettings4Line } from 'react-icons/ri';

const StartupGrid = styled.div`
    ${tw`grid grid-cols-1 lg:grid-cols-3 gap-6`};
`;

const MainContent = styled.div`
    ${tw`lg:col-span-2 space-y-6`};
`;

const Sidebar = styled.div`
    ${tw`space-y-6`};
`;

const CommandBox = styled.div`
    ${tw`p-4 rounded-xl`};
    background: rgba(31, 34, 53, 0.7);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.1);
    box-shadow: 
        0 10px 30px rgba(0, 0, 0, 0.2),
        0 0 0 1px rgba(255, 255, 255, 0.05),
        inset 0 0 20px rgba(255, 255, 255, 0.03);
`;

const CommandText = styled.code`
    ${tw`block p-4 rounded-lg font-mono text-sm`};
    background: rgba(0, 0, 0, 0.3);
    border: 1px solid rgba(255, 255, 255, 0.07);
    word-break: break-all;
`;

const VariablesGrid = styled.div`
    ${tw`grid grid-cols-1 md:grid-cols-2 gap-6 mt-8`};
`;

const InfoCard = styled.div`
    ${tw`p-5 rounded-xl`};
    background: rgba(31, 34, 53, 0.7);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.1);
    box-shadow: 
        0 10px 30px rgba(0, 0, 0, 0.2),
        0 0 0 1px rgba(255, 255, 255, 0.05),
        inset 0 0 20px rgba(255, 255, 255, 0.03);
`;

const InfoItem = styled.div`
    ${tw`flex items-center justify-between py-3 border-b border-neutral-700 last:border-b-0`};
`;

const InfoLabel = styled.span`
    ${tw`text-sm font-medium text-neutral-300`};
`;

const InfoValue = styled.span`
    ${tw`text-sm text-neutral-200 font-mono`};
`;

const StartupContainer = () => {
    const [loading, setLoading] = useState(false);
    const { clearFlashes, clearAndAddHttpError } = useFlash();

    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const server = ServerContext.useStoreState((state) => state.server.data!);
    const variables = ServerContext.useStoreState(
        ({ server }) => ({
            variables: server.data!.variables,
            invocation: server.data!.invocation,
            dockerImage: server.data!.dockerImage,
        }),
        isEqual
    );

    const { data, error, isValidating, mutate } = getServerStartup(uuid, {
        ...variables,
        dockerImages: { [variables.dockerImage]: variables.dockerImage },
    });

    const setServerFromState = ServerContext.useStoreActions((actions) => actions.server.setServerFromState);
    const isCustomImage =
        data &&
        !Object.values(data.dockerImages)
            .map((v) => v.toLowerCase())
            .includes(variables.dockerImage.toLowerCase());

    useEffect(() => {
        // Since we're passing in initial data this will not trigger on mount automatically. We
        // want to always fetch fresh information from the API however when we're loading the startup
        // information.
        mutate();
    }, []);

    useDeepCompareEffect(() => {
        if (!data) return;

        setServerFromState((s) => ({
            ...s,
            invocation: data.invocation,
            variables: data.variables,
        }));
    }, [data]);

    const updateSelectedDockerImage = useCallback(
        (v: React.ChangeEvent<HTMLSelectElement>) => {
            setLoading(true);
            clearFlashes('startup:image');

            const image = v.currentTarget.value;
            setSelectedDockerImage(uuid, image)
                .then(() => setServerFromState((s) => ({ ...s, dockerImage: image })))
                .catch((error) => {
                    console.error(error);
                    clearAndAddHttpError({ key: 'startup:image', error });
                })
                .then(() => setLoading(false));
        },
        [uuid]
    );

    return !data ? (
        !error || (error && isValidating) ? (
            <Spinner centered size={Spinner.Size.LARGE} />
        ) : (
            <ServerError title={'Oops!'} message={httpErrorToHuman(error)} onRetry={() => mutate()} />
        )
    ) : (
        <ServerContentBlock title={'Startup Settings'} showFlashKey={'startup:image'}>
            <div className="flex items-center mb-6">
                <RiSettings4Line className="text-indigo-400 mr-3 text-2xl" />
                <h1 className="text-2xl font-bold">Startup Configuration</h1>
            </div>
            
            <StartupGrid>
                <MainContent>
                    <CommandBox>
                        <div className="flex items-center mb-4">
                            <RiTerminalLine className="text-indigo-400 mr-2" />
                            <h3 className="font-medium text-neutral-200">Startup Command</h3>
                        </div>
                        <CommandText>{data.invocation}</CommandText>
                        <p className="text-xs text-neutral-400 mt-3">
                            This command is executed when your server starts up. Variables are replaced with their configured values.
                        </p>
                    </CommandBox>
                    
                    <div className="grid grid-cols-1 gap-6">
                        <TitledGreyBox title={'Docker Image'} icon={RiDossierLine}>
                            {Object.keys(data.dockerImages).length > 1 && !isCustomImage ? (
                                <>
                                    <InputSpinner visible={loading}>
                                        <Select
                                            disabled={Object.keys(data.dockerImages).length < 2}
                                            onChange={updateSelectedDockerImage}
                                            defaultValue={variables.dockerImage}
                                            className="bg-neutral-800/50"
                                        >
                                            {Object.keys(data.dockerImages).map((key) => (
                                                <option key={data.dockerImages[key]} value={data.dockerImages[key]}>
                                                    {key}
                                                </option>
                                            ))}
                                        </Select>
                                    </InputSpinner>
                                    <p className="text-xs text-neutral-300 mt-3">
                                        This is an advanced feature allowing you to select a Docker image to use when running
                                        this server instance.
                                    </p>
                                </>
                            ) : (
                                <>
                                    <Input disabled readOnly value={variables.dockerImage} className="bg-neutral-800/50" />
                                    {isCustomImage && (
                                        <p className="text-xs text-neutral-300 mt-3">
                                            This {"server's"} Docker image has been manually set by an administrator and cannot
                                            be changed through this UI.
                                        </p>
                                    )}
                                </>
                            )}
                        </TitledGreyBox>
                    </div>
                    
                    <div className="mt-6">
                        <div className="flex items-center mb-4">
                            <RiSettings4Line className="text-indigo-400 mr-2" />
                            <h3 className="text-xl font-medium text-neutral-200">Startup Variables</h3>
                        </div>
                        <VariablesGrid>
                            {data.variables.map((variable) => (
                                <VariableBox key={variable.envVariable} variable={variable} />
                            ))}
                        </VariablesGrid>
                    </div>
                </MainContent>
                
                <Sidebar>
                    <InfoCard>
                        <h3 className="font-medium text-neutral-200 mb-4">Startup Information</h3>
                        <div className="space-y-3">
                            <InfoItem>
                                <InfoLabel>Server ID</InfoLabel>
                                <InfoValue>{server.id}</InfoValue>
                            </InfoItem>
                            <InfoItem>
                                <InfoLabel>UUID</InfoLabel>
                                <InfoValue className="truncate" title={server.uuid}>{server.uuid}</InfoValue>
                            </InfoItem>
                            <InfoItem>
                                <InfoLabel>Node</InfoLabel>
                                <InfoValue>{server.node}</InfoValue>
                            </InfoItem>
                            <InfoItem>
                                <InfoLabel>Server Name</InfoLabel>
                                <InfoValue className="truncate" title={server.name}>{server.name}</InfoValue>
                            </InfoItem>
                            <InfoItem>
                                <InfoLabel>Total Variables</InfoLabel>
                                <InfoValue>{data.variables.length}</InfoValue>
                            </InfoItem>
                            <InfoItem>
                                <InfoLabel>Docker Images</InfoLabel>
                                <InfoValue>{Object.keys(data.dockerImages).length}</InfoValue>
                            </InfoItem>
                        </div>
                    </InfoCard>
                    
                    <InfoCard>
                        <h3 className="font-medium text-neutral-200 mb-4">Need Help?</h3>
                        <p className="text-sm text-neutral-300 mb-3">
                            If you're having trouble with your server startup configuration, check the following:
                        </p>
                        <ul className="text-sm text-neutral-400 space-y-2">
                            <li className="flex items-start">
                                <span className="text-indigo-400 mr-2">•</span>
                                Ensure all required variables are set correctly
                            </li>
                            <li className="flex items-start">
                                <span className="text-indigo-400 mr-2">•</span>
                                Verify the Docker image is compatible with your server
                            </li>
                            <li className="flex items-start">
                                <span className="text-indigo-400 mr-2">•</span>
                                Check the server logs for specific errors
                            </li>
                            <li className="flex items-start">
                                <span className="text-indigo-400 mr-2">•</span>
                                Consult the game/application documentation
                            </li>
                        </ul>
                    </InfoCard>
                </Sidebar>
            </StartupGrid>
        </ServerContentBlock>
    );
};

export default StartupContainer;