import React, { forwardRef, useState, useEffect, useRef, useCallback } from 'react';
import { Form } from 'formik';
import styled, { keyframes, createGlobalStyle, css } from 'styled-components/macro';
import { breakpoint } from '@/theme';
import FlashMessageRender from '@/components/FlashMessageRender';
import tw from 'twin.macro';

// Global styles for the auth page
const GlobalAuthStyle = createGlobalStyle`
  body.auth-login-page {
    background: linear-gradient(135deg, #1a1b2f 0%, #1e2039 100%);
    min-height: 100vh;
    margin: 0 !important;
    padding: 0 !important;
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    overflow: hidden;
  }

  /* Kill the blurred Unsplash background from base.blade on login */
  body.auth-login-page::before {
    display: none !important;
  }

  /* Remove sidebar layout spacing on login */
  body.auth-login-page #app,
  body.auth-login-page .wrapper,
  body.auth-login-page .main-container,
  body.auth-login-page .content {
    margin-left: 0 !important;
    padding-left: 0 !important;
  }

  body.auth-login-page * {
    box-sizing: border-box;
  }
`;

// Optimized animations with will-change and transform
const floatingAnimation = keyframes`
  0%, 100% { 
    transform: translateY(0px) rotate(0deg);
  }
  50% { 
    transform: translateY(-8px) rotate(1deg);
  }
`;

const glowAnimation = keyframes`
  0%, 100% { 
    box-shadow: 
      0 8px 32px rgba(0, 0, 0, 0.1),
      0 0 0 1px rgba(255, 255, 255, 0.05);
  }
  50% { 
    box-shadow: 
      0 12px 40px rgba(0, 0, 0, 0.15),
      0 0 0 1px rgba(96, 165, 250, 0.08);
  }
`;

const Container = styled.div`
  ${tw`min-h-screen flex items-center justify-center p-4 relative`};
  transform: translateZ(0);
  backface-visibility: hidden;
  
  ${breakpoint('sm')`
    ${tw`w-full mx-auto`}
  `};

  ${breakpoint('md')`
    ${tw`p-10`}
  `};

  ${breakpoint('lg')`
    ${tw`w-full`}
  `};

  ${breakpoint('xl')`
    ${tw`w-full`}
    max-width: 600px;
  `};
`;

const AnimatedLogo = styled.img<{ $isHovered: boolean }>`
  ${tw`block w-24 mx-auto transition-all duration-500`}
  filter: invert(98%) sepia(1%) saturate(7500%) hue-rotate(46deg) brightness(113%) contrast(101%);
  transform: translateZ(0);
  
  ${props => props.$isHovered && css`
    animation: ${floatingAnimation} 3s ease-in-out infinite;
    filter: 
      invert(98%) sepia(1%) saturate(7500%) hue-rotate(46deg) brightness(113%) contrast(101%)
      drop-shadow(0 0 12px rgba(96, 165, 250, 0.4));
  `}
`;

const GlassForm = styled.div`
  ${tw`w-full rounded-2xl p-8 backdrop-blur-xl z-10 relative`};
  background: rgba(26, 27, 47, 0.7);
  border: 1px solid rgba(255, 255, 255, 0.1);
  animation: ${glowAnimation} 8s ease-in-out infinite;
  transform: translateZ(0);
  will-change: box-shadow;
  backface-visibility: hidden;
`;

// Background wrapper
const MouseBackground = styled.div`
  ${tw`fixed inset-0 overflow-hidden pointer-events-none`};
  transform: translateZ(0);
`;

// Soft background grid
const GridBackground = styled.div.attrs<{ $x: number; $y: number }>(props => ({
  style: {
    backgroundPosition: `${-props.$x % 20}px ${-props.$y % 20}px, ${-props.$x % 20}px ${-props.$y % 20}px`
  }
}))<{ $x: number; $y: number }>`
  ${tw`fixed inset-0 pointer-events-none`};
  background-image: 
    radial-gradient(circle at 50% 50%, 
      rgba(96, 165, 250, 0.08) 0%, 
      transparent 60%),
    linear-gradient(rgba(255, 255, 255, 0.015) 1px, transparent 1px),
    linear-gradient(90deg, rgba(255, 255, 255, 0.015) 1px, transparent 1px);
  background-size: 
    100% 100%,
    25px 25px,
    25px 25px;
  transition: background-position 1.2s cubic-bezier(0.22, 1, 0.36, 1);
  transform: translateZ(0);
  will-change: background-position;
`;

// Glow orbs that follow the mouse
const MovingOrb = styled.div.attrs<{
  $x: number;
  $y: number;
  $size: number;
  $delay: number;
  $color: string;
}>(props => ({
  style: {
    left: `${props.$x}px`,
    top: `${props.$y}px`,
  }
}))<{
  $x: number;
  $y: number;
  $size: number;
  $delay: number;
  $color: string;
}>`
  ${tw`absolute rounded-full`};
  width: ${props => props.$size}px;
  height: ${props => props.$size}px;
  background: ${props => props.$color};
  filter: blur(${props => props.$size / 2}px);
  opacity: ${props => 0.1 + (props.$size / 100) * 0.1};
  transform: translate(-50%, -50%) translateZ(0);
  transition: transform 0.6s cubic-bezier(0.22, 1, 0.36, 1), 
              opacity 0.6s ease;
  will-change: transform, opacity;
  backface-visibility: hidden;
`;

/* Canvas that renders the fluid trail */
const TrailCanvas = styled.canvas`
  ${tw`absolute inset-0 pointer-events-none`};
`;

/**
 * Canvas-based "water" trail:
 * - Uses a chain of segments that follow each other (spring-like)
 * - Drawn as glowing radial gradients with additive blending
 * - Very smooth and continuous even at fast mouse speeds
 */
const CanvasTrail: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animationRef = useRef<number>();
  const mouseRef = useRef<{ x: number; y: number }>({
    x: typeof window !== 'undefined' ? window.innerWidth / 2 : 0,
    y: typeof window !== 'undefined' ? window.innerHeight / 2 : 0,
  });
  const tailRef = useRef<{ x: number; y: number }[]>([]);

  useEffect(() => {
    const NUM_SEGMENTS = 24;

    const initTail = () => {
      const { x, y } = mouseRef.current;
      tailRef.current = Array.from({ length: NUM_SEGMENTS }, () => ({ x, y }));
    };

    const handleResize = () => {
      const canvas = canvasRef.current;
      if (!canvas) return;

      const dpr = window.devicePixelRatio || 1;
      const width = window.innerWidth;
      const height = window.innerHeight;

      canvas.width = width * dpr;
      canvas.height = height * dpr;
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;

      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      }
    };

    const handleMouseMove = (e: MouseEvent) => {
      mouseRef.current = { x: e.clientX, y: e.clientY };
    };

    initTail();
    handleResize();
    window.addEventListener('resize', handleResize);
    window.addEventListener('mousemove', handleMouseMove, { passive: true });

    const draw = () => {
      const canvas = canvasRef.current;
      if (!canvas) {
        animationRef.current = requestAnimationFrame(draw);
        return;
      }
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        animationRef.current = requestAnimationFrame(draw);
        return;
      }

      const tail = tailRef.current;
      if (!tail.length) {
        initTail();
      }

      // Physics: head follows mouse, segments follow each other
      const head = tail[0];
      const target = mouseRef.current;
      const headFollow = 0.22;
      head.x += (target.x - head.x) * headFollow;
      head.y += (target.y - head.y) * headFollow;

      const follow = 0.45;
      for (let i = 1; i < tail.length; i++) {
        const prev = tail[i - 1];
        const p = tail[i];
        p.x += (prev.x - p.x) * follow;
        p.y += (prev.y - p.y) * follow;
      }

      const width = canvas.width;
      const height = canvas.height;
      ctx.clearRect(0, 0, width, height);

      ctx.save();
      ctx.globalCompositeOperation = 'lighter';

      const len = tail.length;
      for (let i = 0; i < len; i++) {
        const p = tail[i];
        const t = i / (len - 1); // 0 = tail, 1 = head
        const radius = 4 + (1 - t) * 14;
        const alpha = 0.06 + (1 - t) * 0.38;

        const gradient = ctx.createRadialGradient(
          p.x, p.y, 0,
          p.x, p.y, radius
        );
        gradient.addColorStop(0, `rgba(125, 211, 252, ${alpha})`);
        gradient.addColorStop(0.4, `rgba(59, 130, 246, ${alpha * 0.85})`);
        gradient.addColorStop(1, `rgba(15, 23, 42, 0)`);

        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.arc(p.x, p.y, radius, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.restore();
      animationRef.current = requestAnimationFrame(draw);
    };

    animationRef.current = requestAnimationFrame(draw);

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, []);

  return <TrailCanvas ref={canvasRef} />;
};

const LoginFormContainer = forwardRef<HTMLFormElement, any>(({ title, ...props }, ref) => {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const rafRef = useRef<number>();
  const mousePosRef = useRef({ x: 0, y: 0 });

  // 🔹 Mark body as "login page" while this component is mounted
  useEffect(() => {
    document.body.classList.add('auth-login-page');
    return () => {
      document.body.classList.remove('auth-login-page');
    };
  }, []);

  // Throttled mouse position just for background grid & orbs
  const updateMousePosition = useCallback((e: MouseEvent) => {
    mousePosRef.current = { x: e.clientX, y: e.clientY };

    if (!rafRef.current) {
      rafRef.current = requestAnimationFrame(() => {
        setMousePosition(mousePosRef.current);
        rafRef.current = undefined;
      });
    }
  }, []);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      updateMousePosition(e);
    };

    window.addEventListener('mousemove', handleMouseMove, { passive: true });

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [updateMousePosition]);

  // Glow orbs
  const orbs = [
    { size: 120, color: 'rgba(96, 165, 250, 0.25)', delay: 0 },
    { size: 180, color: 'rgba(99, 102, 241, 0.15)', delay: 0.3 },
  ];

  return (
    <>
      <GlobalAuthStyle />

      {/* Background + water trail */}
      <MouseBackground>
        <GridBackground $x={mousePosition.x} $y={mousePosition.y} />

        {orbs.map((orb, index) => (
          <MovingOrb
            key={index}
            $x={mousePosition.x + (index * 40 - 20)}
            $y={mousePosition.y + (index * 25 - 12)}
            $size={orb.size}
            $delay={orb.delay}
            $color={orb.color}
          />
        ))}

        <CanvasTrail />
      </MouseBackground>
      
      <Container>
        <div css={tw`relative w-full z-10`}>
          <div css={tw`text-center mb-8`}>
            {title && (
              <h2 css={tw`text-3xl font-bold text-white mb-3 tracking-wide`}>
                {title}
              </h2>
            )}
            <p css={tw`text-neutral-300 text-sm`}>
              Game Control Panel
            </p>
          </div>

          <FlashMessageRender 
            css={tw`mb-6 px-4 py-3 rounded-xl backdrop-blur-md bg-white/5 border border-white/10 z-10 relative`} 
          />
          
          <Form {...props} ref={ref}>
            <GlassForm>
              <div css={tw`flex flex-col items-center`}>
                <div css={tw`w-full max-w-xl`}>
                  {props.children}
                </div>
              </div>
            </GlassForm>
          </Form>
          
          <p css={tw`text-center text-neutral-400 text-xs mt-6 z-10 relative`}>
            &copy; 2015 - {new Date().getFullYear()}&nbsp;
            <a
              rel={'noopener nofollow noreferrer'}
              href={'https://pterodactyl.io'}
              target={'_blank'}
              css={tw`no-underline text-blue-400 hover:text-blue-300 transition-colors duration-300`}
            >
              Pterodactyl Software
            </a>
          </p>
        </div>
      </Container>
    </>
  );
});

export default LoginFormContainer;
