import React, { useRef, useState } from 'react';
import { Dialog as HDialog } from '@headlessui/react';
import { Button } from '@/components/elements/button/index';
import { AnimatePresence, motion } from 'framer-motion';
import { DialogContext, IconPosition, RenderDialogProps, styles } from './';
import { RiCloseLine } from 'react-icons/ri';
import tw, { styled } from 'twin.macro';

const DialogContainer = styled.div`
  ${tw`fixed inset-0 z-50 flex items-center justify-center p-4`};
`;

const Backdrop = styled(motion.div)`
  ${tw`fixed inset-0 bg-black/60 backdrop-blur-sm`};
`;

const DialogPanel = styled(motion.div)`
  ${tw`relative w-full max-w-md max-h-[85vh] overflow-hidden rounded-xl`};
  background: rgba(31, 34, 53, 0.95);
  backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.1);
  box-shadow: 
    0 25px 50px rgba(0, 0, 0, 0.3),
    0 0 0 1px rgba(255, 255, 255, 0.05),
    inset 0 0 30px rgba(255, 255, 255, 0.03);
`;

const DialogContent = styled.div`
  ${tw`p-6 overflow-y-auto`};
  max-height: calc(85vh - 120px);
`;

const DialogHeader = styled.div`
  ${tw`mb-4`};
`;

const DialogTitle = styled(HDialog.Title)`
  ${tw`text-xl font-bold text-neutral-200 mb-2`};
  background: linear-gradient(90deg, #EEE 0%, #CCC 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
`;

const DialogDescription = styled(HDialog.Description)`
  ${tw`text-sm text-neutral-400`};
`;

const DialogFooter = styled.div`
  ${tw`flex items-center justify-end space-x-3 p-6 bg-neutral-900/30 border-t border-neutral-700/50`};
`;

const CloseButton = styled.button`
  ${tw`absolute top-4 right-4 flex items-center justify-center w-8 h-8 rounded-full transition-all duration-200`};
  background: rgba(239, 68, 68, 0.15);
  color: rgba(239, 68, 68, 0.8);
  
  &:hover {
    background: rgba(239, 68, 68, 0.25);
    color: rgba(239, 68, 68, 1);
    transform: scale(1.1);
  }
`;

const IconContainer = styled.div<{ position: IconPosition }>`
  ${({ position }) => position === 'title' && tw`flex items-center mb-4`};
  ${({ position }) => position === 'container' && tw`flex justify-center mb-4`};
`;

const variants = {
    open: {
        scale: 1,
        opacity: 1,
        transition: {
            type: 'spring',
            damping: 20,
            stiffness: 300,
            duration: 0.2,
        },
    },
    closed: {
        scale: 0.8,
        opacity: 0,
        transition: {
            type: 'easeIn',
            duration: 0.15,
        },
    },
    bounce: {
        scale: 0.95,
        opacity: 1,
        transition: { type: 'linear', duration: 0.1 },
    },
};

export default ({
    open,
    title,
    description,
    onClose,
    hideCloseIcon,
    preventExternalClose,
    children,
}: RenderDialogProps) => {
    const container = useRef<HTMLDivElement>(null);
    const [icon, setIcon] = useState<React.ReactNode>();
    const [footer, setFooter] = useState<React.ReactNode>();
    const [iconPosition, setIconPosition] = useState<IconPosition>('title');
    const [down, setDown] = useState(false);

    const onContainerClick = (down: boolean, e: React.MouseEvent<HTMLDivElement>): void => {
        if (e.target instanceof HTMLElement && container.current?.isSameNode(e.target)) {
            setDown(down);
        }
    };

    const onDialogClose = (): void => {
        if (!preventExternalClose) {
            return onClose();
        }
    };

    return (
        <AnimatePresence>
            {open && (
                <DialogContext.Provider value={{ setIcon, setFooter, setIconPosition }}>
                    <HDialog
                        static
                        as={motion.div}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.15 }}
                        open={open}
                        onClose={onDialogClose}
                    >
                        <Backdrop />
                        <DialogContainer>
                            <div
                                ref={container}
                                className="flex items-center justify-center min-h-full"
                                onMouseDown={onContainerClick.bind(this, true)}
                                onMouseUp={onContainerClick.bind(this, false)}
                            >
                                <HDialog.Panel
                                    as={DialogPanel}
                                    initial={'closed'}
                                    animate={down ? 'bounce' : 'open'}
                                    exit={'closed'}
                                    variants={variants}
                                >
                                    <DialogContent>
                                        {icon && (
                                            <IconContainer position={iconPosition}>
                                                {icon}
                                            </IconContainer>
                                        )}
                                        
                                        <DialogHeader>
                                            {title && (
                                                <DialogTitle>{title}</DialogTitle>
                                            )}
                                            {description && (
                                                <DialogDescription>{description}</DialogDescription>
                                            )}
                                        </DialogHeader>
                                        
                                        {children}
                                    </DialogContent>
                                    
                                    {footer}
                                    
                                    {!hideCloseIcon && (
                                        <CloseButton onClick={onClose}>
                                            <RiCloseLine className="w-5 h-5" />
                                        </CloseButton>
                                    )}
                                </HDialog.Panel>
                            </div>
                        </DialogContainer>
                    </HDialog>
                </DialogContext.Provider>
            )}
        </AnimatePresence>
    );
};