import React, { useState, useEffect } from 'react';
import tw from 'twin.macro';
import styled from 'styled-components/macro';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTimes, faInfoCircle, faExclamationTriangle, faCheckCircle, faExclamationCircle, faBullhorn } from '@fortawesome/free-solid-svg-icons';
import http from '@/api/http';

const AnnouncementsContainer = styled.div`
    ${tw`w-full space-y-4 mb-6`};
`;

const AnnouncementItem = styled.div<{ $type: string }>`
    ${tw`rounded-xl p-4 border transition-all duration-300 transform backdrop-blur-3xl`};
    background: ${props => {
        switch (props.$type) {
            case 'warning': return 'linear-gradient(135deg, rgba(245, 158, 11, 0.15) 0%, rgba(245, 158, 11, 0.08) 100%)';
            case 'success': return 'linear-gradient(135deg, rgba(16, 185, 129, 0.15) 0%, rgba(16, 185, 129, 0.08) 100%)';
            case 'error': return 'linear-gradient(135deg, rgba(239, 68, 68, 0.15) 0%, rgba(239, 68, 68, 0.08) 100%)';
            case 'primary': return 'linear-gradient(135deg, rgba(59, 130, 246, 0.15) 0%, rgba(59, 130, 246, 0.08) 100%)';
            default: return 'linear-gradient(135deg, rgba(100, 116, 139, 0.15) 0%, rgba(100, 116, 139, 0.08) 100%)';
        }
    }};
    -webkit-backdrop-filter: blur(64px);
    backdrop-filter: blur(64px);
    border-color: ${props => {
        switch (props.$type) {
            case 'warning': return 'rgba(245, 158, 11, 0.3)';
            case 'success': return 'rgba(16, 185, 129, 0.3)';
            case 'error': return 'rgba(239, 68, 68, 0.3)';
            case 'primary': return 'rgba(59, 130, 246, 0.3)';
            default: return 'rgba(100, 116, 139, 0.3)';
        }
    }};
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
    
    &:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 30px rgba(0, 0, 0, 0.15);
        border-color: ${props => {
            switch (props.$type) {
                case 'warning': return 'rgba(245, 158, 11, 0.5)';
                case 'success': return 'rgba(16, 185, 129, 0.5)';
                case 'error': return 'rgba(239, 68, 68, 0.5)';
                case 'primary': return 'rgba(59, 130, 246, 0.5)';
                default: return 'rgba(100, 116, 139, 0.5)';
            }
        }};
    }
`;

const AnnouncementHeader = styled.div`
    ${tw`flex items-start justify-between`};
`;

const AnnouncementTitle = styled.h3<{ $type: string }>`
    ${tw`font-semibold text-lg flex items-center gap-3`};
    color: ${props => {
        switch (props.$type) {
            case 'warning': return '#f59e0b';
            case 'success': return '#10b981';
            case 'error': return '#ef4444';
            case 'primary': return '#3b82f6';
            default: return '#64748b';
        }
    }};
`;

const AnnouncementContent = styled.div`
    ${tw`text-gray-300 leading-relaxed`};
    
    p {
        ${tw`mb-3 last:mb-0`};
    }
    
    a {
        ${tw`text-blue-400 hover:text-blue-300 underline transition-colors`};
    }
    
    strong {
        ${tw`font-semibold text-gray-200`};
    }
    
    em {
        ${tw`italic text-gray-400`};
    }
    
    ul, ol {
        ${tw`ml-4 mb-3`};
    }
    
    li {
        ${tw`mb-1`};
    }
`;

const CloseButton = styled.button`
    ${tw`text-gray-400 mt-1.5 hover:text-gray-300 transition-colors px-3 py-2 rounded-lg hover:bg-gray-700/50 flex-shrink-0`};
`;

const DismissButton = styled.button`
    ${tw`text-sm px-4 py-2 rounded-lg border transition-all duration-300 mt-4 font-medium`};
    border-color: rgba(255, 255, 255, 0.2);
    color: rgba(255, 255, 255, 0.8);
    background: rgba(255, 255, 255, 0.05);
    
    &:hover {
        background: rgba(255, 255, 255, 0.1);
        color: rgba(255, 255, 255, 0.9);
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }
`;

const IconWrapper = styled.div<{ $type: string }>`
    ${tw`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0`};
    background: ${props => {
        switch (props.$type) {
            case 'warning': return 'rgba(245, 158, 11, 0.2)';
            case 'success': return 'rgba(16, 185, 129, 0.2)';
            case 'error': return 'rgba(239, 68, 68, 0.2)';
            case 'primary': return 'rgba(59, 130, 246, 0.2)';
            default: return 'rgba(100, 116, 139, 0.2)';
        }
    }};
    color: ${props => {
        switch (props.$type) {
            case 'warning': return '#f59e0b';
            case 'success': return '#10b981';
            case 'error': return '#ef4444';
            case 'primary': return '#3b82f6';
            default: return '#64748b';
        }
    }};
`;

const getTypeIcon = (type: string) => {
    switch (type) {
        case 'warning': return faExclamationTriangle;
        case 'success': return faCheckCircle;
        case 'error': return faExclamationCircle;
        case 'primary': return faBullhorn;
        default: return faInfoCircle;
    }
};

const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
};

interface Announcement {
    id: number;
    title: string;
    content: string;
    type: string;
    is_dismissible: boolean;
    created_at: string;
    starts_at?: string;
    ends_at?: string;
    target_scope?: string;
}

const Announcements: React.FC = () => {
    const [announcements, setAnnouncements] = useState<Announcement[]>([]);
    const [dismissed, setDismissed] = useState<number[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchAnnouncements();
        
        // Load dismissed announcements from localStorage
        const savedDismissed = localStorage.getItem('dismissed_announcements');
        if (savedDismissed) {
            setDismissed(JSON.parse(savedDismissed));
        }
    }, []);

    const fetchAnnouncements = async () => {
        try {
            setLoading(true);
            const response = await http.get('/api/client/announcements');
            setAnnouncements(response.data || []);
        } catch (error) {
            console.error('Failed to fetch announcements:', error);
        } finally {
            setLoading(false);
        }
    };

    const dismissAnnouncement = (id: number) => {
        const newDismissed = [...dismissed, id];
        setDismissed(newDismissed);
        localStorage.setItem('dismissed_announcements', JSON.stringify(newDismissed));
    };

    const visibleAnnouncements = announcements.filter(
        announcement => !dismissed.includes(announcement.id)
    );

    if (loading || visibleAnnouncements.length === 0) {
        return null;
    }

    return (
        <AnnouncementsContainer>
            {visibleAnnouncements.map((announcement) => (
                <AnnouncementItem key={announcement.id} $type={announcement.type}>
                    <AnnouncementHeader>
                        <div className="flex items-start gap-4 flex-1">
                            <IconWrapper $type={announcement.type}>
                                <FontAwesomeIcon icon={getTypeIcon(announcement.type)} />
                            </IconWrapper>
                            <div className="flex-1 min-w-0">
                                <AnnouncementTitle $type={announcement.type}>
                                    {announcement.title}
                                </AnnouncementTitle>
                                <AnnouncementContent 
                                    dangerouslySetInnerHTML={{ __html: announcement.content }}
                                />
                            </div>
                        </div>
						{announcement.is_dismissible && (
							<CloseButton onClick={() => dismissAnnouncement(announcement.id)}>
								<FontAwesomeIcon icon={faTimes} />
							</CloseButton>
						)}
                    </AnnouncementHeader>
                </AnnouncementItem>
            ))}
        </AnnouncementsContainer>
    );
};

export default Announcements;