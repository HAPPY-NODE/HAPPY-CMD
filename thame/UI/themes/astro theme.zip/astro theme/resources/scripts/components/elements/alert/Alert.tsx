import React from 'react';
import { 
    ExclamationIcon, 
    ShieldExclamationIcon, 
    CheckCircleIcon, 
    InformationCircleIcon,
    XIcon 
} from '@heroicons/react/outline';
import classNames from 'classnames';

export interface AlertProps {
    type: 'success' | 'info' | 'warning' | 'danger';
    className?: string;
    children: React.ReactNode;
    dismissable?: boolean;
    onDismiss?: () => void;
    title?: string;
}

export default ({ type, className, children, dismissable, onDismiss, title }: AlertProps) => {
    const getStyles = () => {
        const baseStyles = 'relative rounded-xl shadow-lg p-4 pr-6 border-l-4 backdrop-blur-sm';
        
        switch (type) {
            case 'success':
                return classNames(
                    baseStyles,
                    'border-emerald-500 bg-emerald-500/10 text-emerald-100',
                    'shadow-emerald-500/5'
                );
            case 'info':
                return classNames(
                    baseStyles,
                    'border-blue-500 bg-blue-500/10 text-blue-100', 
                    'shadow-blue-500/5'
                );
            case 'warning':
                return classNames(
                    baseStyles,
                    'border-amber-500 bg-amber-500/10 text-amber-100',
                    'shadow-amber-500/5'
                );
            case 'danger':
                return classNames(
                    baseStyles,
                    'border-red-500 bg-red-500/10 text-red-100',
                    'shadow-red-500/5'
                );
            default:
                return classNames(
                    baseStyles,
                    'border-gray-500 bg-gray-500/10 text-gray-100'
                );
        }
    };

    const getIcon = () => {
        const iconClass = 'w-5 h-5 flex-shrink-0';
        
        switch (type) {
            case 'success':
                return <CheckCircleIcon className={classNames(iconClass, 'text-emerald-400')} />;
            case 'info':
                return <InformationCircleIcon className={classNames(iconClass, 'text-blue-400')} />;
            case 'warning':
                return <ExclamationIcon className={classNames(iconClass, 'text-amber-400')} />;
            case 'danger':
                return <ShieldExclamationIcon className={classNames(iconClass, 'text-red-400')} />;
            default:
                return <InformationCircleIcon className={classNames(iconClass, 'text-gray-400')} />;
        }
    };

    const getBackgroundGlow = () => {
        switch (type) {
            case 'success':
                return 'before:absolute before:inset-0 before:rounded-xl before:bg-emerald-500 before:opacity-5 before:content-[""]';
            case 'info':
                return 'before:absolute before:inset-0 before:rounded-xl before:bg-blue-500 before:opacity-5 before:content-[""]';
            case 'warning':
                return 'before:absolute before:inset-0 before:rounded-xl before:bg-amber-500 before:opacity-5 before:content-[""]';
            case 'danger':
                return 'before:absolute before:inset-0 before:rounded-xl before:bg-red-500 before:opacity-5 before:content-[""]';
            default:
                return '';
        }
    };

    return (
        <div className={classNames(getStyles(), getBackgroundGlow(), className)}>
            <div className="flex items-start gap-3">
                <div className="mt-0.5">
                    {getIcon()}
                </div>
                
                <div className="flex-1 min-w-0">
                    {title && (
                        <h4 className={classNames(
                            'font-semibold mb-1 text-sm',
                            {
                                'text-emerald-300': type === 'success',
                                'text-blue-300': type === 'info',
                                'text-amber-300': type === 'warning',
                                'text-red-300': type === 'danger'
                            }
                        )}>
                            {title}
                        </h4>
                    )}
                    
                    <div className={classNames(
                        'text-sm leading-relaxed',
                        title ? 'text-gray-300' : 'text-gray-200'
                    )}>
                        {children}
                    </div>
                </div>

                {dismissable && (
                    <button
                        onClick={onDismiss}
                        className={classNames(
                            'flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center',
                            'transition-all duration-200 hover:scale-110 hover:bg-white/10',
                            'focus:outline-none focus:ring-2 focus:ring-white/20'
                        )}
                    >
                        <XIcon className="w-3 h-3" />
                    </button>
                )}
            </div>
        </div>
    );
};