import React, { useState, useEffect } from 'react';
import { ServerContext } from '@/state/server';
import TitledGreyBox from '@/components/elements/TitledGreyBox';
import { Button } from '@/components/elements/button/index';
import Spinner from '@/components/elements/Spinner';
import { RiRefreshLine, RiBox3Line, RiInformationLine, RiCheckLine, RiCloseLine, RiDeleteBinLine } from 'react-icons/ri';
import tw from 'twin.macro';
import styled from 'styled-components/macro';

const PluginGrid = styled.div`
    ${tw`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-4`};
`;

const PluginCard = styled.div`
    ${tw`p-4 rounded-lg transition-all duration-300`};
    background: rgba(31, 34, 53, 0.8);
    border: 1px solid rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(10px);
    
    &:hover {
        border-color: rgba(99, 102, 241, 0.3);
        transform: translateY(-2px);
        box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.3);
    }
`;

const PluginIcon = styled.div`
    ${tw`w-10 h-10 rounded-lg flex items-center justify-center mb-3`};
    background: rgba(99, 102, 241, 0.15);
    color: rgba(99, 102, 241, 0.8);
`;

const EmptyState = styled.div`
    ${tw`text-center py-12`};
`;

const UninstallButton = styled.button<{ uninstalling?: boolean }>`
    ${tw`text-red-400 hover:text-red-300 transition-all duration-300 p-2 rounded-lg`};
    ${props => props.uninstalling && tw`text-red-300 cursor-not-allowed opacity-75`};
    
    &:hover:not(:disabled) {
        ${tw`bg-red-500/10 transform scale-110`};
    }
`;

const StatusBadge = styled.div<{ type: 'managed' | 'manual' }>`
    ${tw`px-2 py-1 text-xs rounded border font-medium flex items-center space-x-1`};
    ${props => props.type === 'managed' 
        ? tw`bg-green-500/20 text-green-300 border-green-500/30` 
        : tw`bg-yellow-500/20 text-yellow-300 border-yellow-500/30`
    };
`;

// Function to get CSRF token from meta tag
const getCsrfToken = (): string => {
    const metaTag = document.querySelector('meta[name="csrf-token"]') as HTMLMetaElement;
    return metaTag ? metaTag.content : '';
};

export default () => {
    const server = ServerContext.useStoreState(state => state.server.data!);
    const [plugins, setPlugins] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [uninstalling, setUninstalling] = useState<{ [key: string]: boolean }>({});
    const [uninstallResult, setUninstallResult] = useState<{ [key: string]: 'success' | 'error' | null }>({});

    const loadInstalledPlugins = async () => {
        setLoading(true);
        setError(null);

        try {
            const response = await fetch(`/api/client/servers/${server.uuid}/plugins/installed`);
            const data = await response.json();

            if (data.success) {
                setPlugins(data.plugins || []);
            } else {
                throw new Error(data.error || 'Failed to load installed plugins');
            }
        } catch (err) {
            console.error('Error loading installed plugins:', err);
            setError(err instanceof Error ? err.message : 'An error occurred');
        } finally {
            setLoading(false);
        }
    };

    const uninstallPlugin = async (pluginName: string) => {
        if (!confirm(`Are you sure you want to uninstall "${pluginName}"?\n\nThis will remove the plugin file from your server.`)) {
            return;
        }

        setUninstalling(prev => ({ ...prev, [pluginName]: true }));
        setUninstallResult(prev => ({ ...prev, [pluginName]: null }));

        try {
            const csrfToken = getCsrfToken();
            const response = await fetch(`/api/client/servers/${server.uuid}/plugins/uninstall/${encodeURIComponent(pluginName)}`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRF-TOKEN': csrfToken,
                },
            });

            const data = await response.json();

            if (data.success) {
                setUninstallResult(prev => ({ ...prev, [pluginName]: 'success' }));
                
                // Wait a moment to show success state, then refresh the list
                setTimeout(async () => {
                    await loadInstalledPlugins();
                    setUninstallResult(prev => ({ ...prev, [pluginName]: null }));
                }, 1000);
            } else {
                throw new Error(data.error || 'Uninstall failed');
            }
        } catch (err) {
            console.error('Error uninstalling plugin:', err);
            setUninstallResult(prev => ({ ...prev, [pluginName]: 'error' }));
            setError(err instanceof Error ? err.message : 'Uninstall failed');
            
            // Reset error state after delay
            setTimeout(() => {
                setUninstallResult(prev => ({ ...prev, [pluginName]: null }));
            }, 3000);
        } finally {
            setUninstalling(prev => ({ ...prev, [pluginName]: false }));
        }
    };

    useEffect(() => {
        loadInstalledPlugins();
    }, []); // only on mount

    const formatDate = (dateString: string): string => {
        if (!dateString) return '';
        return new Date(dateString).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    };

    const formatFileSize = (bytes: number): string => {
        if (!bytes && bytes !== 0) return '0 Bytes';
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    };

    const getUninstallButtonIcon = (pluginName: string) => {
        if (uninstallResult[pluginName] === 'success') {
            return RiCheckLine;
        }
        if (uninstallResult[pluginName] === 'error') {
            return RiCloseLine;
        }
        if (uninstalling[pluginName]) {
            return Spinner;
        }
        return RiDeleteBinLine;
    };

    const getUninstallButtonColor = (pluginName: string) => {
        if (uninstallResult[pluginName] === 'success') {
            return 'text-green-400';
        }
        if (uninstallResult[pluginName] === 'error') {
            return 'text-red-400';
        }
        return 'text-red-400 hover:text-red-300';
    };

    if (loading) {
        return (
            <TitledGreyBox title={'Installed Plugins'}>
                <div className={'text-center py-12'}>
                    <Spinner size={'large'} />
                    <p className={'text-gray-400 mt-4 text-lg'}>Loading installed plugins...</p>
                </div>
            </TitledGreyBox>
        );
    }

    if (plugins.length === 0) {
        return (
            <TitledGreyBox 
                title={'Installed Plugins'}
                actions={
                    <Button onClick={loadInstalledPlugins} variant={'outline'}>
                        <RiRefreshLine className="mr-2" />
                        Refresh
                    </Button>
                }
            >
                <EmptyState>
                    <RiBox3Line className="text-gray-400 text-5xl mx-auto mb-4" />
                    <h3 className="text-xl font-bold text-gray-200 mb-2">No Plugins Installed</h3>
                    <p className="text-gray-400 mb-6 max-w-md mx-auto">
                        Get started by browsing and installing plugins from the marketplace. 
                        Your installed plugins will appear here.
                    </p>
                </EmptyState>
            </TitledGreyBox>
        );
    }

    return (
        <TitledGreyBox 
            title={'Installed Plugins'}
            actions={
                <Button onClick={loadInstalledPlugins} variant={'outline'}>
                    <RiRefreshLine className="mr-2" />
                    Refresh
                </Button>
            }
        >
            {error && (
                <div className={'mb-6 p-4 bg-red-500/10 border border-red-500/20 rounded-lg text-red-200'}>
                    <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                            <RiCloseLine className="text-red-400" />
                            <span className="font-medium">Error</span>
                        </div>
                        <button 
                            onClick={() => setError(null)}
                            className="text-red-300 hover:text-red-100"
                        >
                            <RiCloseLine size={16} />
                        </button>
                    </div>
                    <p className="mt-2 text-sm">{error}</p>
                </div>
            )}

            <div className="flex items-center justify-between mb-6">
                <div>
                    <h3 className="text-2xl font-bold text-gray-50 mb-2">Installed Plugins</h3>
                    <p className="text-gray-400">
                        {plugins.length} {plugins.length === 1 ? 'plugin' : 'plugins'} installed on your server
                    </p>
                </div>
            </div>

            <PluginGrid>
                {plugins.map((plugin) => (
                    <PluginCard key={plugin.name}>
                        <div className="flex items-start justify-between mb-4">
                            <div className="flex items-center space-x-3">
                                <PluginIcon>
                                    <RiBox3Line />
                                </PluginIcon>
                                <div className="flex-1 min-w-0">
                                    <h4 className="font-bold text-gray-50 truncate text-sm">{plugin.name}</h4>
                                    <p className="text-gray-400 text-xs truncate">v{plugin.version}</p>
                                </div>
                            </div>
                            <UninstallButton
                                onClick={() => uninstallPlugin(plugin.name)}
                                disabled={uninstalling[plugin.name]}
                                uninstalling={uninstalling[plugin.name]}
                                className={getUninstallButtonColor(plugin.name)}
                                title={uninstalling[plugin.name] ? "Uninstalling..." : "Uninstall Plugin"}
                            >
                                {React.createElement(getUninstallButtonIcon(plugin.name), {
                                    size: 18,
                                    className: uninstalling[plugin.name] ? 'animate-spin' : ''
                                })}
                            </UninstallButton>
                        </div>

                        <div className="space-y-3 text-sm mb-4">
                            <div className="flex justify-between items-center">
                                <span className="text-gray-500 text-xs">File:</span>
                                <span className="text-gray-300 text-xs font-mono truncate ml-2 max-w-[120px]">
                                    {plugin.file_name}
                                </span>
                            </div>
                            <div className="flex justify-between items-center">
                                <span className="text-gray-500 text-xs">Installed:</span>
                                <span className="text-gray-300 text-xs">
                                    {formatDate(plugin.installed_at)}
                                </span>
                            </div>
                        </div>

                        <div className="pt-3 border-t border-gray-600">
                            {plugin.plugin_id ? (
                                <StatusBadge type="managed">
                                    <RiInformationLine size={12} />
                                    <span>Managed</span>
                                </StatusBadge>
                            ) : (
                                <StatusBadge type="manual">
                                    <RiInformationLine size={12} />
                                    <span>Manual</span>
                                </StatusBadge>
                            )}
                        </div>

                        {/* Success/Error Messages */}
                        {uninstallResult[plugin.name] === 'success' && (
                            <div className="mt-3 p-2 bg-green-500/10 border border-green-500/20 rounded text-green-300 text-xs">
                                Plugin uninstalled successfully
                            </div>
                        )}
                        {uninstallResult[plugin.name] === 'error' && (
                            <div className="mt-3 p-2 bg-red-500/10 border border-red-500/20 rounded text-red-300 text-xs">
                                Failed to uninstall plugin
                            </div>
                        )}
                    </PluginCard>
                ))}
            </PluginGrid>
        </TitledGreyBox>
    );
};
