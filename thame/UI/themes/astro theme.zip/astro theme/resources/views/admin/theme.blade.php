@extends('layouts.base')

@push('head')
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-dyZfB0k2sVw2Qh1s4xvG6hPzZy+z0/5Jm8J6zF1n5hQk6dS1I2oKq1Q9dVYkY2R8z6+2nDqf2h2n0G2s3bQbYQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
@endpush

@section('title', 'Theme Settings')

@section('content')
<style>
.line-clamp-3 {
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.announcement-card {
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.announcement-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
}

.glass-effect {
    background: rgba(23, 26, 45, 0.7);
    backdrop-filter: blur(16px);
    -webkit-backdrop-filter: blur(16px);
}
</style>
<div class="min-h-screen backdrop-blur-xl text-gray-100 relative overflow-hidden">
    <!-- Animated background elements -->
    <div class="absolute inset-0 overflow-hidden">
        <div class="absolute -top-40 -right-40 w-80 h-80 bg-primary-500/5 rounded-full blur-3xl"></div>
        <div class="absolute -bottom-40 -left-40 w-80 h-80 bg-purple-500/5 rounded-full blur-3xl"></div>
        <div class="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-cyan-500/3 rounded-full blur-3xl"></div>
    </div>

    {{-- Header --}}
    <header class="relative glass-effect border-b border-gray-700/30 backdrop-blur-xl">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-6">
                <div class="flex items-center space-x-4">
                    <a href="{{ route('admin.index') }}" class="group relative p-2 rounded-lg bg-gray-800/50 hover:bg-gray-700/50 transition-all duration-300">
                        <i class="fas fa-arrow-left text-gray-400 group-hover:text-white transition-colors"></i>
                        <div class="absolute inset-0 rounded-lg bg-gradient-to-r from-primary-500/10 to-purple-500/10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                    </a>
                    <div class="relative">
                        <h1 class="text-3xl font-bold text-blue-500">
                            <i class="fas fa-palette mr-3"></i>Theme Studio
                        </h1>
                        <p class="text-sm text-gray-400 mt-1 flex items-center">
                            <span class="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse"></span>
                            Live customization dashboard
                        </p>
                    </div>
                </div>
                <div class="flex items-center space-x-4">
                    <div class="relative group">
                        <div class="px-4 py-2 bg-primary-900/30 rounded-full border border-primary-500/20">
                            <span class="text-primary-300 font-medium flex items-center">
                                <i class="fas fa-shield-alt mr-2 text-sm"></i>
                                Admin Mode
                            </span>
                        </div>
                        <div class="absolute -bottom-2 left-1/2 transform -translate-x-1/2 w-0 h-0.5 bg-gradient-to-r from-primary-500 to-primary-600 group-hover:w-full transition-all duration-300"></div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    {{-- Flash Messages --}}
    <div class="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
        @if(session('success'))
            <div class="flex items-center p-4 mb-4 rounded-2xl bg-gradient-to-r from-green-900/40 to-green-800/30 border border-green-700/30 backdrop-blur-sm animate-slide-down">
                <div class="flex-shrink-0 w-8 h-8 bg-green-500/20 rounded-full flex items-center justify-center mr-3">
                    <i class="fas fa-check text-green-400"></i>
                </div>
                <span class="text-green-300 font-medium">{{ session('success') }}</span>
                <button class="ml-auto text-green-400 hover:text-green-300 transition-colors">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        @endif
        @if(session('warning'))
            <div class="flex items-center p-4 mb-4 rounded-2xl bg-gradient-to-r from-yellow-900/40 to-yellow-800/30 border border-yellow-700/30 backdrop-blur-sm animate-slide-down">
                <div class="flex-shrink-0 w-8 h-8 bg-yellow-500/20 rounded-full flex items-center justify-center mr-3">
                    <i class="fas fa-exclamation-triangle text-yellow-400"></i>
                </div>
                <span class="text-yellow-300 font-medium">{{ session('warning') }}</span>
                <button class="ml-auto text-yellow-400 hover:text-yellow-300 transition-colors">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        @endif
    </div>

    {{-- Main Content --}}
    <main class="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {{-- Tabs Navigation --}}
        <div class="glass-effect rounded-2xl p-1 mb-8 backdrop-blur-xl border border-gray-700/30">
            <div class="flex space-x-1">
                <button class="tab-button active group relative flex-1 py-4 px-6 rounded-xl font-semibold transition-all duration-300" data-tab="background">
                    <div class="flex items-center justify-center space-x-3">
                        <i class="fas fa-image text-lg group-[.active]:text-white text-gray-400 transition-colors"></i>
                        <span class="group-[.active]:text-white text-gray-400 transition-colors">Background</span>
                    </div>
                    <div class="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-0 h-0.5 bg-blue-300 group-[.active]:w-3/4 transition-all duration-300"></div>
                </button>
                
                <button class="tab-button group relative flex-1 py-4 px-6 rounded-xl font-semibold transition-all duration-300" data-tab="appearance">
                    <div class="flex items-center justify-center space-x-3">
                        <i class="fas fa-paint-brush text-lg group-[.active]:text-white text-gray-400 transition-colors"></i>
                        <span class="group-[.active]:text-white text-gray-400 transition-colors">Appearance</span>
                    </div>
                    <div class="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-0 h-0.5 bg-blue-300 group-[.active]:w-3/4 transition-all duration-300"></div>
                </button>
                
                <button class="tab-button group relative flex-1 py-4 px-6 rounded-xl font-semibold transition-all duration-300" data-tab="navigation-links">
                    <div class="flex items-center justify-center space-x-3">
                        <i class="fas fa-bars text-lg group-[.active]:text-white text-gray-400 transition-colors"></i>
                        <span class="group-[.active]:text-white text-gray-400 transition-colors">Navigation</span>
                    </div>
                    <div class="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-0 h-0.5 bg-blue-300 group-[.active]:w-3/4 transition-all duration-300"></div>
                </button>
                
                <button class="tab-button group relative flex-1 py-4 px-6 rounded-xl font-semibold transition-all duration-300" data-tab="nest-backgrounds">
                    <div class="flex items-center justify-center space-x-3">
                        <i class="fas fa-server text-lg group-[.active]:text-white text-gray-400 transition-colors"></i>
                        <span class="group-[.active]:text-white text-gray-400 transition-colors">Nests</span>
                    </div>
                    <div class="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-0 h-0.5 bg-blue-300 group-[.active]:w-3/4 transition-all duration-300"></div>
                </button>
				
				<button class="tab-button group relative flex-1 py-4 px-6 rounded-xl font-semibold transition-all duration-300" data-tab="announcements">
					<div class="flex items-center justify-center space-x-3">
						<i class="fas fa-bullhorn text-lg group-[.active]:text-white text-gray-400 transition-colors"></i>
						<span class="group-[.active]:text-white text-gray-400 transition-colors">Announcements</span>
					</div>
					<div class="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-0 h-0.5 bg-blue-300 group-[.active]:w-3/4 transition-all duration-300"></div>
				</button>
                
                <button class="tab-button group relative flex-1 py-4 px-6 rounded-xl font-semibold transition-all duration-300" data-tab="panel-preview">
                    <div class="flex items-center justify-center space-x-3">
                        <i class="fas fa-desktop text-lg group-[.active]:text-white text-gray-400 transition-colors"></i>
                        <span class="group-[.active]:text-white text-gray-400 transition-colors">Preview</span>
                    </div>
                    <div class="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-0 h-0.5 bg-blue-300 group-[.active]:w-3/4 transition-all duration-300"></div>
                </button>
				
				<button class="tab-button group relative flex-1 py-4 px-6 rounded-xl font-semibold transition-all duration-300" data-tab="modules">
					<div class="flex items-center justify-center space-x-3">
						<i class="fas fa-cube text-lg group-[.active]:text-white text-gray-400 transition-colors"></i>
						<span class="group-[.active]:text-white text-gray-400 transition-colors">Modules</span>
					</div>
					<div class="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-0 h-0.5 bg-blue-300 group-[.active]:w-3/4 transition-all duration-300"></div>
				</button>
            </div>
        </div>

        {{-- Background Tab --}}
        <div id="background-tab" class="tab-content space-y-6">
		<form id="themeForm" action="{{ route('admin.theme.update') }}" method="POST" enctype="multipart/form-data" class="space-y-6">
		@csrf
		<input type="hidden" name="active_tab" value="background">
        <!-- Fix: Include quick_links_enabled in background form -->
        <input type="hidden" name="quick_links_enabled" value="{{ $quick_links_enabled ?? true ? '1' : '0' }}">
            {{-- Preview Card --}}
            <div class="glass-effect rounded-2xl p-6 settings-card group relative overflow-hidden backdrop-blur-xl border border-gray-700/30">
                <div class="absolute inset-0 bg-gradient-to-br from-primary-500/5 to-purple-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                <div class="relative">
                    <h3 class="font-semibold text-xl mb-6 flex items-center">
                        <div class="w-10 h-10 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl flex items-center justify-center mr-3">
                            <i class="fas fa-eye text-white"></i>
                        </div>
                        Live Background Preview
                    </h3>
                    
                    <div class="gradient-border hover:gradient-border-hover transition-all duration-300">
                        <div class="bg-gray-800/50 rounded-2xl p-1">
                            <div id="livePreview" class="h-80 w-full rounded-xl bg-cover bg-center relative overflow-hidden transform transition-transform duration-500 group-hover:scale-[1.02]"
                                 style="background-image: url('{{ $background ?? 'https://images.unsplash.com/photo-1687392946859-cebb261f01f5?fm=jpg&q=60&w=3000' }}')">
                                <div class="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent"></div>
                                <div class="absolute bottom-0 left-0 right-0 p-6">
                                    <div class="flex justify-between items-center">
                                        <div>
                                            <h4 class="font-bold text-white text-lg">Server Dashboard</h4>
                                            <p class="text-gray-300 text-sm mt-1" id="previewUrl">
                                                @if(!empty($background))
                                                    {{ Str::limit($background, 50) }}
                                                @else
                                                    Using default background
                                                @endif
                                            </p>
                                        </div>
                                        <div class="flex space-x-2">
                                            <div class="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                                            <div class="w-3 h-3 bg-yellow-500 rounded-full animate-pulse" style="animation-delay: 0.2s"></div>
                                            <div class="w-3 h-3 bg-green-500 rounded-full animate-pulse" style="animation-delay: 0.4s"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {{-- Upload Background --}}
                <div class="glass-effect rounded-2xl p-6 settings-card group relative overflow-hidden backdrop-blur-xl border border-gray-700/30">
                    <div class="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-cyan-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                    <div class="relative">
                        <h3 class="font-semibold text-lg mb-4 flex items-center">
                            <div class="w-8 h-8 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-lg flex items-center justify-center mr-3">
                                <i class="fas fa-upload text-white text-sm"></i>
                            </div>
                            Upload Background
                        </h3>
                        
                        <div class="border-2 border-dashed border-gray-600 rounded-xl p-6 text-center transition-all duration-300 hover:border-blue-400 hover:bg-blue-500/5 group/upload">
                            <i class="fas fa-cloud-upload-alt text-4xl text-gray-400 mb-4 group-hover/upload:text-blue-400 transition-colors"></i>
                            <p class="text-gray-300 mb-4">Drag & drop your image or click to browse</p>
                            <input type="file" name="background_file" id="backgroundFile" accept="image/*" class="hidden" onchange="previewImage(this)">
                            <button type="button" id="btnChooseBackground" class="px-6 py-3 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 rounded-xl font-medium transition-all duration-300 transform hover:scale-105 shadow-lg shadow-blue-500/25">
                                Choose File
                            </button>
                            <p class="text-xs text-gray-400 mt-3">PNG, JPG, GIF up to 5MB</p>
                        </div>
                    </div>
                </div>

                {{-- External URL --}}
                <div class="glass-effect rounded-2xl p-6 settings-card group relative overflow-hidden backdrop-blur-xl border border-gray-700/30">
                    <div class="absolute inset-0 bg-gradient-to-br from-green-500/5 to-emerald-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                    <div class="relative">
                        <h3 class="font-semibold text-lg mb-4 flex items-center">
                            <div class="w-8 h-8 bg-gradient-to-br from-green-500 to-emerald-600 rounded-lg flex items-center justify-center mr-3">
                                <i class="fas fa-link text-white text-sm"></i>
                            </div>
                            External URL
                        </h3>
                        
                        <div class="space-y-4">
                            <div class="relative">
                                <input type="url" name="background_url" id="backgroundUrl" 
                                       value="{{ old('background_url', $background ?? '') }}" 
                                       placeholder="https://example.com/background.jpg"
                                       class="w-full px-4 py-3 rounded-xl bg-gray-800/50 border border-gray-600 focus:border-green-500 focus:ring-2 focus:ring-green-500/20 transition-all duration-300 pl-12">
                                <i class="fas fa-globe absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                            </div>
                            @error('background_url')
                                <p class="text-red-400 text-sm flex items-center">
                                    <i class="fas fa-exclamation-circle mr-2"></i>{{ $message }}
                                </p>
                            @enderror
                        </div>
                    </div>
                </div>
            </div>

            {{-- Reset Section --}}
            <div class="glass-effect rounded-2xl p-6 settings-card group relative overflow-hidden backdrop-blur-xl border border-gray-700/30">
                <div class="absolute inset-0 bg-gradient-to-br from-orange-500/5 to-red-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                <div class="relative">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center space-x-4">
                            <div class="w-12 h-12 bg-gradient-to-br from-orange-500 to-red-600 rounded-xl flex items-center justify-center">
                                <i class="fas fa-refresh text-white"></i>
                            </div>
                            <div>
                                <h3 class="font-semibold text-lg">Reset to Default</h3>
                                <p class="text-gray-400 text-sm">Revert to the original panel background</p>
                            </div>
                        </div>
                        <label class="relative inline-flex items-center cursor-pointer scale-125">
                            <input type="checkbox" name="use_default" value="1" class="sr-only peer">
                            <div class="w-14 h-7 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-0.5 after:left-0.5 after:bg-white after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-gradient-to-r peer-checked:from-orange-600 peer-checked:to-red-600"></div>
                        </label>
                    </div>
                </div>
            </div>

            {{-- Action Buttons --}}
            <div class="flex justify-end space-x-4 pt-6">
                <button type="button" id="btnPreviewChanges" class="px-8 py-3 bg-gray-700 hover:bg-gray-600 rounded-xl font-medium transition-all duration-300 transform hover:scale-105 flex items-center space-x-2 border border-gray-600">
                    <i class="fas fa-eye"></i>
                    <span>Preview Changes</span>
                </button>
                <button type="submit" class="px-8 py-3 bg-primary-600 hover:bg-primary-500 rounded-xl font-medium transition-all duration-300 transform hover:scale-105 shadow-lg flex items-center space-x-2">
                    <i class="fas fa-save"></i>
                    <span>Save Changes</span>
                </button>
            </div>
			</form>
        </div>

        {{-- Appearance Tab --}}
        <div id="appearance-tab" class="tab-content hidden space-y-6">
            <form id="appearanceForm" action="{{ route('admin.theme.update') }}" method="POST" enctype="multipart/form-data" class="space-y-6">
                @csrf
                <input type="hidden" name="active_tab" value="appearance">
                <!-- Add hidden input for quick links data -->
                <input type="hidden" name="quick_links" id="quick_links_input" value="{{ json_encode($quick_links ?? []) }}">

                {{-- Logos Section --}}
                <div class="glass-effect rounded-2xl p-6 settings-card group relative overflow-hidden backdrop-blur-xl border border-gray-700/30">
                    <div class="absolute inset-0 bg-gradient-to-br from-indigo-500/5 to-purple-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                    <div class="relative">
                        <h3 class="font-semibold text-xl mb-6 flex items-center">
                            <div class="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center mr-3">
                                <i class="fas fa-image text-white"></i>
                            </div>
                            Panel Logos
                        </h3>
                        
                        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            {{-- Small Logo --}}
                            <div class="space-y-4">
                                <h4 class="font-medium text-lg flex items-center">
                                    <i class="fas fa-compress text-indigo-400 mr-2"></i>
                                    Small Logo (Collapsed)
                                </h4>
                                <div class="gradient-border rounded-xl p-4">
                                    <div class="bg-gray-900/50 rounded-lg p-4 h-32 flex items-center justify-center">
                                        <img id="smallLogoPreview" src="{{ $small_logo ?? '' }}" alt="Small logo" 
                                             class="max-h-16 object-contain" 
                                             onerror="this.style.display='none'"/>
                                        @if(empty($small_logo))
                                            <div class="text-center text-gray-500">
                                                <i class="fas fa-image text-2xl mb-2 opacity-50"></i>
                                                <p class="text-sm">No logo set</p>
                                            </div>
                                        @endif
                                    </div>
                                </div>
                                
                                <div class="space-y-3">
                                    <div class="flex space-x-2">
                                        <input type="file" name="small_logo_file" id="smallLogoFile" accept="image/*" class="hidden" onchange="previewLogo(this, 'small')">
                                        <button type="button" id="btnUploadSmallLogo" class="px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 rounded-lg font-medium transition-all duration-300 flex items-center">
                                            <i class="fas fa-upload mr-2"></i> Upload
                                        </button>
                                        <button type="button" onclick="clearLogo('small')" class="px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded-lg font-medium transition-colors">
                                            <i class="fas fa-trash mr-2"></i> Clear
                                        </button>
                                    </div>
                                    
                                    <div class="relative">
                                        <input type="url" name="small_logo_url" id="small_logo_url" 
                                               value="{{ old('small_logo_url', $small_logo ?? '') }}" 
                                               placeholder="https://example.com/small-logo.png"
                                               class="w-full px-4 py-3 rounded-xl bg-gray-800/50 border border-gray-600 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all duration-300 pl-12"
                                               oninput="updateLogoPreview('small', this.value)">
                                        <i class="fas fa-link absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                                    </div>
                                    <p class="text-xs text-gray-400">Recommended: 40×40px transparent PNG</p>
                                </div>
                            </div>
                            
                            {{-- Large Logo --}}
                            <div class="space-y-4">
                                <h4 class="font-medium text-lg flex items-center">
                                    <i class="fas fa-expand text-purple-400 mr-2"></i>
                                    Large Logo (Extended)
                                </h4>
                                <div class="gradient-border rounded-xl p-4">
                                    <div class="bg-gray-900/50 rounded-lg p-4 h-32 flex items-center justify-center">
                                        <img id="largeLogoPreview" src="{{ $large_logo ?? '' }}" alt="Large logo" 
                                             class="max-h-20 object-contain" 
                                             onerror="this.style.display='none'"/>
                                        @if(empty($large_logo))
                                            <div class="text-center text-gray-500">
                                                <i class="fas fa-image text-2xl mb-2 opacity-50"></i>
                                                <p class="text-sm">No logo set</p>
                                            </div>
                                        @endif
                                    </div>
                                </div>
                                
                                <div class="space-y-3">
                                    <div class="flex space-x-2">
                                        <input type="file" name="large_logo_file" id="largeLogoFile" accept="image/*" class="hidden" onchange="previewLogo(this, 'large')">
                                        <button type="button" id="btnUploadLargeLogo" class="px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 rounded-lg font-medium transition-all duration-300 flex items-center">
                                            <i class="fas fa-upload mr-2"></i> Upload
                                        </button>
                                        <button type="button" onclick="clearLogo('large')" class="px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded-lg font-medium transition-colors">
                                            <i class="fas fa-trash mr-2"></i> Clear
                                        </button>
                                    </div>
                                    
                                    <div class="relative">
                                        <input type="url" name="large_logo_url" id="large_logo_url" 
                                               value="{{ old('large_logo_url', $large_logo ?? '') }}" 
                                               placeholder="https://example.com/large-logo.png"
                                               class="w-full px-4 py-3 rounded-xl bg-gray-800/50 border border-gray-600 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 transition-all duration-300 pl-12"
                                               oninput="updateLogoPreview('large', this.value)">
                                        <i class="fas fa-link absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                                    </div>
                                    <p class="text-xs text-gray-400">Recommended: Full-width PNG or SVG for header</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- Quick Links Section --}}
                <div class="glass-effect rounded-2xl p-6 settings-card group relative overflow-hidden backdrop-blur-xl border border-gray-700/30">
                    <div class="absolute inset-0 bg-gradient-to-br from-yellow-500/5 to-amber-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                    <div class="relative">
                        <div class="flex items-center justify-between mb-6">
                            <div>
                                <h3 class="font-semibold text-xl flex items-center">
                                    <div class="w-10 h-10 bg-gradient-to-br from-yellow-500 to-amber-600 rounded-xl flex items-center justify-center mr-3">
                                        <i class="fas fa-link text-white"></i>
                                    </div>
                                    Quick Links
                                </h3>
                                <p class="text-gray-400 mt-1">Manage the quick links that appear in your panel dashboard page</p>
                            </div>
                            
                            <div class="flex items-center space-x-4">
                                <label class="relative inline-flex items-center cursor-pointer">
                                    <input id="quickLinksToggle" type="checkbox" name="quick_links_enabled" value="1" class="sr-only peer" {{ ($quick_links_enabled ?? true) ? 'checked' : '' }}>
                                    <div class="w-14 h-7 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-0.5 after:left-0.5 after:bg-white after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-gradient-to-r peer-checked:from-yellow-600 peer-checked:to-amber-600"></div>
                                    <span class="ml-3 text-sm font-medium text-gray-300">Enable Quick Links</span>
                                </label>
                                
                                <button type="button" id="btnAddQuickLink" class="px-4 py-3 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 rounded-xl font-medium transition-all duration-300 transform hover:scale-105 flex items-center">
                                    <i class="fas fa-plus mr-2"></i> Add Link
                                </button>
                            </div>
                        </div>
                        
                        {{-- Quick Links List --}}
                        <div id="quickLinksList" class="space-y-4">
                            <!-- Quick links will be rendered here by JavaScript -->
                        </div>
                        
                        {{-- Empty State --}}
                        <div id="quickLinksEmpty" class="text-center py-8 text-gray-400 hidden">
                            <i class="fas fa-link text-4xl mb-4 opacity-50"></i>
                            <p class="text-lg font-medium">No quick links yet</p>
                            <p class="text-sm mt-1">Click "Add Link" to create your first quick link</p>
                        </div>
                        
                        {{-- Help Text --}}
                        <div class="mt-6 p-4 bg-gray-800/50 rounded-xl border border-gray-700/30">
                            <p class="text-sm text-gray-400 flex items-center">
                                <i class="fas fa-info-circle text-blue-400 mr-2"></i>
                                <strong>Tips:</strong>&nbsp;Icons are FontAwesome names (e.g., "discord", "github", "credit-card"). URLs should start with https:// for external links.
                            </p>
                        </div>
                    </div>
                </div>
                
                {{-- Action Buttons --}}
                <div class="flex justify-end space-x-4 pt-6">
                    <button type="button" class="px-8 py-3 bg-gray-700 hover:bg-gray-600 rounded-xl font-medium transition-all duration-300 transform hover:scale-105 flex items-center space-x-2 border border-gray-600">
                        <i class="fas fa-eye"></i>
                        <span>Preview Changes</span>
                    </button>
                <button type="submit" class="px-8 py-3 bg-primary-600 hover:bg-primary-500 rounded-xl font-medium transition-all duration-300 transform hover:scale-105 shadow-lg flex items-center space-x-2">
                        <i class="fas fa-save"></i>
                        <span>Save Appearance</span>
                    </button>
                </div>
            </form>
        </div>

        {{-- Navigation Links Tab --}}
        <div id="navigation-links-tab" class="tab-content hidden space-y-6">
            <form id="navigationLinksForm" action="{{ route('admin.theme.update') }}" method="POST" enctype="multipart/form-data" class="space-y-6">
                @csrf
                <input type="hidden" name="active_tab" value="navigation-links">
                <input type="hidden" name="navigation_links" id="navigation_links_input" value="{{ $navigation_links ? json_encode($navigation_links) : '[]' }}">
                <!-- Fix: Include quick_links_enabled in navigation form -->
                <input type="hidden" name="quick_links_enabled" value="{{ $quick_links_enabled ?? true ? '1' : '0' }}">

                {{-- Navigation Links Section --}}
                <div class="glass-effect rounded-2xl p-6 settings-card group relative overflow-hidden backdrop-blur-xl border border-gray-700/30">
                    <div class="absolute inset-0 bg-gradient-to-br from-purple-500/5 to-pink-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                    <div class="relative">
                        <div class="flex items-center justify-between mb-6">
                            <div>
                                <h3 class="font-semibold text-xl flex items-center">
                                    <div class="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl flex items-center justify-center mr-3">
                                        <i class="fas fa-bars text-white"></i>
                                    </div>
                                    Navigation Links
                                </h3>
                                <p class="text-gray-400 mt-1">Manage your panel's navigation menu structure</p>
                            </div>
                            
                            <div class="flex items-center space-x-3">
                                <button type="button" id="btnResetNavLinks" class="px-4 py-3 bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-500 hover:to-red-500 rounded-xl font-medium transition-all duration-300 flex items-center">
                                    <i class="fas fa-undo mr-2"></i> Reset to Default
                                </button>
                                <button type="button" id="btnAddNavLink" class="px-4 py-3 bg-gradient-to-r from-primary-600 to-blue-600 hover:from-primary-500 hover:to-blue-500 rounded-xl font-medium transition-all duration-300 flex items-center">
                                    <i class="fas fa-plus mr-2"></i> Add Link
                                </button>
                                <button type="button" id="btnAddNavCategory" class="px-4 py-3 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 rounded-xl font-medium transition-all duration-300 flex items-center">
                                    <i class="fas fa-folder-plus mr-2"></i> Add Category
                                </button>
                            </div>
                        </div>
                        
                        {{-- Legend --}}
                        <div class="mb-6 p-4 bg-gray-800/50 rounded-xl border border-gray-700/30">
                            <div class="flex flex-wrap gap-6 items-center">
                                <div class="flex items-center space-x-2">
                                    <div class="w-3 h-3 bg-blue-500 rounded-full"></div>
                                    <span class="text-sm text-gray-300">Main Navigation</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <div class="w-3 h-3 bg-green-500 rounded-full"></div>
                                    <span class="text-sm text-gray-300">Server Navigation</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <div class="w-3 h-3 bg-red-500 rounded-full"></div>
                                    <span class="text-sm text-gray-300">Admin Only</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <div class="w-3 h-3 bg-purple-500 rounded-full"></div>
                                    <span class="text-sm text-gray-300">Category</span>
                                </div>
                            </div>
                            <p class="text-xs text-gray-400 mt-2">
                                <strong>Pro Tips:</strong>&nbsp;Drag links to reorder • Use categories to group links • Server links can use <code>{id}</code> for dynamic server IDs
                            </p>
                        </div>
                        
                        {{-- Navigation Links List --}}
                        <div id="navigationLinksList" class="space-y-4">
                            <!-- Navigation links will be rendered here by JavaScript -->
                        </div>
                        
                        {{-- Empty State --}}
                        <div id="navLinksEmpty" class="text-center py-12 text-gray-400 hidden">
                            <i class="fas fa-bars text-5xl mb-4 opacity-50"></i>
                            <h4 class="text-lg font-medium mb-2">No navigation links configured</h4>
                            <p class="text-sm">Start by adding a link or category to build your navigation menu</p>
                        </div>
                    </div>
                </div>
                
                {{-- Action Buttons --}}
                <div class="flex justify-end space-x-4 pt-6">
                    <button type="button" id="btnPreviewNavChanges" class="px-8 py-3 bg-gray-700 hover:bg-gray-600 rounded-xl font-medium transition-all duration-300 transform hover:scale-105 flex items-center space-x-2 border border-gray-600">
                        <i class="fas fa-eye"></i>
                        <span>Preview Changes</span>
                    </button>
                <button type="submit" class="px-8 py-3 bg-primary-600 hover:bg-primary-500 rounded-xl font-medium transition-all duration-300 transform hover:scale-105 shadow-lg flex items-center space-x-2">
                        <i class="fas fa-save"></i>
                        <span>Save Navigation</span>
                    </button>
                </div>
            </form>
        </div>

        {{-- Nest Backgrounds Tab --}}
        <div id="nest-backgrounds-tab" class="tab-content hidden space-y-6">
            <form id="nestBackgroundsForm" action="{{ route('admin.theme.update') }}" method="POST" enctype="multipart/form-data" class="space-y-6">
                @csrf
                <input type="hidden" name="active_tab" value="nest-backgrounds">
                <!-- Fix: Include quick_links_enabled in nest backgrounds form -->
                <input type="hidden" name="quick_links_enabled" value="{{ $quick_links_enabled ?? true ? '1' : '0' }}">

                {{-- Gradient Opacity Control --}}
                <div class="glass-effect rounded-2xl p-6 settings-card group relative overflow-hidden backdrop-blur-xl border border-gray-700/30">
                    <div class="absolute inset-0 bg-gradient-to-br from-cyan-500/5 to-blue-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                    <div class="relative">
                        <h3 class="font-semibold text-xl mb-6 flex items-center">
                            <div class="w-10 h-10 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl flex items-center justify-center mr-3">
                                <i class="fas fa-sliders-h text-white"></i>
                            </div>
                            Background Opacity
                        </h3>
                        
                        <div class="space-y-4">
                            <div>
                                <div class="flex justify-between items-center mb-2">
                                    <label class="block text-sm font-medium text-gray-300">
                                        Background Gradient Opacity
                                    </label>
                                    <span id="gradientOpacityValue" class="text-primary-400 font-medium">{{ ($nest_gradient_opacity ?? 0.15) * 100 }}%</span>
                                </div>
                                <input type="range" name="nest_gradient_opacity" id="gradientOpacity" 
                                       min="0" max="1" step="0.05" 
                                       value="{{ $nest_gradient_opacity ?? 0.15 }}"
                                       class="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
                                       oninput="updateGradientOpacityValue(this.value)">
                                <div class="flex justify-between text-xs text-gray-400 mt-1">
                                    <span>0% (Only Gradient)</span>
                                    <span>100% (No Gradient)</span>
                                </div>
                                <p class="text-sm text-gray-400 mt-3">
                                    Adjust how dark the gradient overlay appears on server cards. Higher values make backgrounds more visible.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- Nest Backgrounds Section --}}
                <div class="glass-effect rounded-2xl p-6 settings-card group relative overflow-hidden backdrop-blur-xl border border-gray-700/30">
                    <div class="absolute inset-0 bg-gradient-to-br from-green-500/5 to-emerald-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                    <div class="relative">
                        <h3 class="font-semibold text-xl mb-6 flex items-center">
                            <div class="w-10 h-10 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center mr-3">
                                <i class="fas fa-server text-white"></i>
                            </div>
                            Nest Backgrounds
                        </h3>
                        <p class="text-gray-400 text-sm mb-6">
                            Set custom background images for each nest. These will appear behind servers in that nest on the servers list.
                        </p>

                        <div class="space-y-6">
                            @foreach($nests as $nest)
                                @php
                                    $nestBackground = $nest_backgrounds[$nest->id] ?? null;
                                @endphp
                                <div class="gradient-border rounded-xl p-4 bg-gray-800/30">
                                    <div class="flex items-center justify-between mb-4">
                                        <h4 class="font-semibold text-white flex items-center">
                                            <i class="fas fa-egg mr-2 text-yellow-400"></i>
                                            {{ $nest->name }} <span class="text-gray-400 ml-2">(ID: {{ $nest->id }})</span>
                                        </h4>
                                        <span class="px-3 py-1 bg-gradient-to-r from-gray-700 to-gray-800 rounded-full text-xs text-gray-300 border border-gray-600">
                                            {{ $nestBackground ? 'Custom Set' : 'Using Default' }}
                                        </span>
                                    </div>

                                    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                                        {{-- Current Preview --}}
                                        <div>
                                            <label class="block text-sm font-medium mb-2 text-gray-300">Current Preview</label>
                                            <div class="gradient-border rounded-lg overflow-hidden">
                                                <div class="h-40 rounded-lg bg-cover bg-center" 
                                                     style="background-image: url('{{ $nestBackground ?? 'https://img.freepik.com/free-vector/black-background-geometric-gradient-design_677411-2886.jpg' }}')">
                                                    <div class="h-full w-full bg-gradient-to-t from-black/70 to-transparent flex items-end p-4">
                                                        <span class="text-white text-sm font-medium bg-black/50 px-3 py-1 rounded-full">
                                                            {{ $nestBackground ? 'Custom Background' : 'Default Background' }}
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        {{-- Settings --}}
                                        <div class="space-y-4">
                                            <div>
                                                <label class="block text-sm font-medium mb-2 text-gray-300">Background URL</label>
                                                <div class="relative">
                                                    <input type="url" 
                                                           name="nest_backgrounds[{{ $nest->id }}]" 
                                                           value="{{ old('nest_backgrounds.' . $nest->id, $nestBackground) }}"
                                                           placeholder="https://example.com/background.jpg"
                                                           class="w-full px-4 py-3 rounded-xl bg-gray-800/50 border border-gray-600 focus:border-green-500 focus:ring-2 focus:ring-green-500/20 transition-all duration-300 pl-12">
                                                    <i class="fas fa-link absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                                                </div>
                                            </div>

                                            <div>
                                                <label class="block text-sm font-medium mb-2 text-gray-300">Upload File</label>
                                                <div class="flex items-center space-x-3">
                                                    <input type="file" 
                                                           name="nest_background_file[{{ $nest->id }}]" 
                                                           accept="image/*"
                                                           class="hidden"
                                                           id="nestBackgroundFile{{ $nest->id }}">
                                                    <button type="button" 
                                                            onclick="document.getElementById('nestBackgroundFile{{ $nest->id }}').click()"
                                                            class="px-4 py-2 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 rounded-xl font-medium transition-all duration-300 flex items-center">
                                                        <i class="fas fa-upload mr-2"></i> Choose File
                                                    </button>
                                                    <span class="text-xs text-gray-400">PNG, JPG, GIF up to 5MB</span>
                                                </div>
                                            </div>

                                            @if($nestBackground)
                                            <div class="flex justify-end">
                                                <button type="button" 
                                                        onclick="clearNestBackground({{ $nest->id }})"
                                                        class="px-4 py-2 bg-gradient-to-r from-red-600 to-pink-600 hover:from-red-500 hover:to-pink-500 rounded-xl font-medium transition-all duration-300 flex items-center">
                                                    <i class="fas fa-trash mr-2"></i> Clear Background
                                                </button>
                                            </div>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>
                
                {{-- Action Buttons --}}
                <div class="flex justify-end space-x-4 pt-6">
                    <button type="button" id="btnPreviewNestChanges" class="px-8 py-3 bg-gray-700 hover:bg-gray-600 rounded-xl font-medium transition-all duration-300 transform hover:scale-105 flex items-center space-x-2 border border-gray-600">
                        <i class="fas fa-eye"></i>
                        <span>Preview All</span>
                    </button>
                <button type="submit" class="px-8 py-3 bg-primary-600 hover:bg-primary-500 rounded-xl font-medium transition-all duration-300 transform hover:scale-105 shadow-lg flex items-center space-x-2">
                        <i class="fas fa-save"></i>
                        <span>Save Nest Settings</span>
                    </button>
                </div>
            </form>
        </div>
		
		{{-- Announcements Tab --}}
		<div id="announcements-tab" class="tab-content hidden space-y-6">
			<form id="announcementForm" action="{{ route('admin.announcements.store') }}" method="POST" class="space-y-6">
				@csrf
				<input type="hidden" id="announcementId" name="id">
				
				{{-- System Controls --}}
				<div class="glass-effect rounded-2xl p-6 group relative overflow-hidden backdrop-blur-xl border border-gray-700/30">
					<div class="absolute inset-0 bg-gradient-to-br from-purple-500/5 to-pink-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
					<div class="relative">
						<div class="flex items-center justify-between">
							<div class="flex items-center space-x-4">
								<div class="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl flex items-center justify-center shadow-lg shadow-purple-500/20">
									<i class="fas fa-bullhorn text-white text-lg"></i>
								</div>
								<div>
									<h3 class="font-bold text-xl text-white">Announcements System</h3>
									<p class="text-gray-300">Broadcast important messages to your users</p>
								</div>
							</div>
							
							<div class="flex items-center space-x-4">
								<div class="flex items-center space-x-3 bg-gray-800/50 rounded-xl px-4 py-2 border border-gray-600/30">
									<span class="text-sm font-medium text-gray-300">Status</span>
									<label class="relative inline-flex items-center cursor-pointer">
										<input type="checkbox" id="announcementsSystemToggle" class="sr-only peer" {{ $announcements_enabled ? 'checked' : '' }}>
										<div class="w-12 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-0.5 after:left-0.5 after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-gradient-to-r peer-checked:from-purple-600 peer-checked:to-pink-600"></div>
									</label>
								</div>
								
								<button type="button" id="btnCreateAnnouncement" class="px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 rounded-xl font-semibold transition-all duration-300 transform hover:scale-105 flex items-center space-x-3 shadow-lg shadow-purple-500/25">
									<i class="fas fa-plus-circle text-white"></i>
									<span class="text-white">New Announcement</span>
								</button>
							</div>
						</div>
					</div>
				</div>

				{{-- Announcements Grid --}}
				<div class="grid grid-cols-1 xl:grid-cols-2 gap-6">
					@foreach($announcements as $announcement)
						<div class="announcement-card glass-effect rounded-2xl p-6 group relative overflow-hidden backdrop-blur-xl border transition-all duration-300 hover:scale-[1.02] hover:border-purple-500/30"
							 data-id="{{ $announcement->id }}"
							 style="background: linear-gradient(135deg, 
								 @switch($announcement->type)
									 @case('warning') rgba(245, 158, 11, 0.08) @break
									 @case('success') rgba(16, 185, 129, 0.08) @break
									 @case('error') rgba(239, 68, 68, 0.08) @break
									 @case('primary') rgba(59, 130, 246, 0.08) @break
									 @default rgba(100, 116, 139, 0.08)
								 @endswitch, 
								 rgba(23, 26, 45, 0.6)); 
								 border-color: 
								 @switch($announcement->type)
									 @case('warning') rgba(245, 158, 11, 0.3) @break
									 @case('success') rgba(16, 185, 129, 0.3) @break
									 @case('error') rgba(239, 68, 68, 0.3) @break
									 @case('primary') rgba(59, 130, 246, 0.3) @break
									 @default rgba(100, 116, 139, 0.3)
								 @endswitch;">
							
							{{-- Header --}}
							<div class="flex items-start justify-between mb-4">
								<div class="flex items-center space-x-3 flex-1 min-w-0">
									<div class="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
										 style="background: 
										 @switch($announcement->type)
											 @case('warning') rgba(245, 158, 11, 0.2) @break
											 @case('success') rgba(16, 185, 129, 0.2) @break
											 @case('error') rgba(239, 68, 68, 0.2) @break
											 @case('primary') rgba(59, 130, 246, 0.2) @break
											 @default rgba(100, 116, 139, 0.2)
										 @endswitch;
										 color: 
										 @switch($announcement->type)
											 @case('warning') #f59e0b @break
											 @case('success') #10b981 @break
											 @case('error') #ef4444 @break
											 @case('primary') #3b82f6 @break
											 @default #64748b
										 @endswitch;">
										<i class="fas 
											@switch($announcement->type)
												@case('warning') fa-exclamation-triangle @break
												@case('success') fa-check-circle @break
												@case('error') fa-exclamation-circle @break
												@case('primary') fa-bullhorn @break
												@default fa-info-circle
											@endswitch text-sm"></i>
									</div>
									<div class="flex-1 min-w-0">
										<h4 class="font-bold text-white truncate" title="{{ $announcement->title }}">{{ $announcement->title }}</h4>
										<div class="flex items-center space-x-2 mt-1">
											<span class="px-2 py-1 text-xs rounded-full font-medium capitalize
												@switch($announcement->type)
													@case('warning') bg-yellow-500/20 text-yellow-300 border border-yellow-500/30 @break
													@case('success') bg-green-500/20 text-green-300 border border-green-500/30 @break
													@case('error') bg-red-500/20 text-red-300 border border-red-500/30 @break
													@case('primary') bg-blue-500/20 text-blue-300 border border-blue-500/30 @break
													@default bg-gray-500/20 text-gray-300 border border-gray-500/30
												@endswitch">
												{{ $announcement->type }}
											</span>
											<span class="px-2 py-1 text-xs rounded-full font-medium {{ $announcement->is_active ? 'bg-green-500/20 text-green-300 border border-green-500/30' : 'bg-gray-500/20 text-gray-400 border border-gray-500/30' }}">
												{{ $announcement->is_active ? 'Active' : 'Inactive' }}
											</span>
										</div>
									</div>
								</div>
								<div class="flex items-center space-x-2 ml-3">
									<button type="button" class="edit-announcement px-2.5 py-1.5 bg-blue-600/20 hover:bg-blue-600/30 rounded-lg text-blue-300 hover:text-blue-200 transition-all duration-300 border border-blue-500/30 hover:border-blue-400/50" data-id="{{ $announcement->id }}" title="Edit">
										<i class="fas fa-edit text-sm"></i>
									</button>
									<button type="button" class="delete-announcement px-2.5 py-1.5 bg-red-600/20 hover:bg-red-600/30 rounded-lg text-red-300 hover:text-red-200 transition-all duration-300 border border-red-500/30 hover:border-red-400/50" data-id="{{ $announcement->id }}" title="Delete">
										<i class="fas fa-trash text-sm"></i>
									</button>
								</div>
							</div>

							{{-- Content --}}
							<div class="text-gray-300 text-sm mb-4 line-clamp-3 leading-relaxed">
								{!! strip_tags($announcement->content, '<strong><em><a><code>') !!}
							</div>

							{{-- Metadata --}}
							<div class="flex items-center justify-between text-xs text-gray-400 pt-3 border-t border-gray-600/30">
								<div class="flex items-center space-x-4">
									<span class="flex items-center space-x-1">
										<i class="fas fa-users text-xs"></i>
										<span class="font-medium">{{ ucfirst($announcement->target_scope) }}</span>
									</span>
									@if($announcement->starts_at)
										<span class="flex items-center space-x-1" title="Starts: {{ \Carbon\Carbon::parse($announcement->starts_at)->format('M j, Y g:i A') }}">
											<i class="fas fa-play text-xs"></i>
											<span>{{ \Carbon\Carbon::parse($announcement->starts_at)->format('M j') }}</span>
										</span>
									@endif
									@if($announcement->ends_at)
										<span class="flex items-center space-x-1" title="Ends: {{ \Carbon\Carbon::parse($announcement->ends_at)->format('M j, Y g:i A') }}">
											<i class="fas fa-stop text-xs"></i>
											<span>{{ \Carbon\Carbon::parse($announcement->ends_at)->format('M j') }}</span>
										</span>
									@endif
								</div>
								<span class="text-gray-500" title="Created: {{ \Carbon\Carbon::parse($announcement->created_at)->format('M j, Y g:i A') }}">
									{{ \Carbon\Carbon::parse($announcement->created_at)->diffForHumans() }}
								</span>
							</div>
						</div>
					@endforeach
				</div>

				{{-- Empty State --}}
				@if($announcements->isEmpty())
					<div class="glass-effect rounded-2xl p-12 text-center border border-gray-700/30">
						<div class="w-20 h-20 bg-gradient-to-br from-gray-600 to-gray-700 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
							<i class="fas fa-bullhorn text-gray-400 text-2xl"></i>
						</div>
						<h4 class="text-xl font-bold text-gray-300 mb-2">No announcements yet</h4>
						<p class="text-gray-400 mb-6">Create your first announcement to notify your users</p>
						<button type="button" id="btnCreateAnnouncementEmpty" class="px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 rounded-xl font-semibold transition-all duration-300 transform hover:scale-105 flex items-center space-x-3 mx-auto shadow-lg shadow-purple-500/25">
							<i class="fas fa-plus-circle text-white"></i>
							<span class="text-white">Create First Announcement</span>
						</button>
					</div>
				@endif

				<div id="announcementModal" class="fixed inset-0 z-50 hidden items-center justify-center p-4 w-full h-full">
					<div class="relative max-w-4xl w-full max-h-[100vh] overflow-hidden">
						
						<!-- Main modal container -->
						<div class="glass-effect backdrop-blur-2xl rounded-3xl p-1 w-full h-full relative overflow-hidden border border-gray-700/50 shadow-2xl">
							<!-- Animated border effect -->
							<div class="absolute inset-0 rounded-3xl bg-gradient-to-r from-purple-600/30 to-pink-600/30 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
							
							<!-- Header with gradient background -->
							<div class="relative bg-gradient-to-r from-purple-600/20 to-pink-600/20 rounded-t-3xl p-8 border-b border-gray-700/30">
								<div class="flex items-center justify-between">
									<div class="flex items-center space-x-4">
										<div class="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl flex items-center justify-center shadow-lg shadow-purple-500/20">
											<i class="fas fa-bullhorn text-white text-lg"></i>
										</div>
										<div>
											<h3 class="font-bold text-2xl text-white" id="modalTitle">Create New Announcement</h3>
											<p class="text-gray-300 mt-1">Broadcast a message to your users</p>
										</div>
									</div>
									<button type="button" id="btnCloseModal" class="w-10 h-10 flex items-center justify-center text-gray-400 hover:text-gray-300 transition-all duration-300 rounded-xl hover:bg-gray-700/50 border border-gray-600/50 hover:border-gray-500/50">
										<i class="fas fa-times text-lg"></i>
									</button>
								</div>
							</div>

							<!-- Modal body with improved spacing -->
							<div class="p-8 max-h-[calc(90vh-120px)] overflow-y-auto">
								<div class="space-y-8">
									{{-- Basic Info --}}
									<div class="glass-effect rounded-2xl p-6 border border-gray-700/30">
										<div class="flex items-center space-x-3 mb-6">
											<div class="w-8 h-8 bg-gradient-to-br from-purple-500/20 to-pink-600/20 rounded-lg flex items-center justify-center">
												<i class="fas fa-info-circle text-purple-400 text-sm"></i>
											</div>
											<h4 class="font-bold text-lg text-white">Basic Information</h4>
										</div>
										
										<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
											<div>
												<label for="title" class="block text-sm font-semibold text-gray-300 mb-3 flex items-center space-x-2">
													<span>Title</span>
													<span class="text-red-400">*</span>
												</label>
												<div class="relative">
													<div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
														<i class="fas fa-heading text-gray-500"></i>
													</div>
													<input type="text" id="title" name="title" required 
														   class="w-full pl-10 pr-4 py-4 rounded-xl bg-gray-800/50 border border-gray-600 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 transition-all duration-300 text-white placeholder-gray-400"
														   placeholder="Enter announcement title">
												</div>
											</div>
											
											<div>
												<label for="type" class="block text-sm font-semibold text-gray-300 mb-3 flex items-center space-x-2">
													<span>Type</span>
													<span class="text-red-400">*</span>
												</label>
												<div class="relative">
													<div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
														<i class="fas fa-tag text-gray-500"></i>
													</div>
													<select id="type" name="type" required 
															class="w-full pl-10 pr-4 py-4 rounded-xl bg-gray-800/50 border border-gray-600 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 transition-all duration-300 text-white appearance-none">
														<option value="info" class="bg-gray-800">Info</option>
														<option value="warning" class="bg-gray-800">Warning</option>
														<option value="success" class="bg-gray-800">Success</option>
														<option value="error" class="bg-gray-800">Error</option>
														<option value="primary" class="bg-gray-800">Primary</option>
													</select>
													<div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
														<i class="fas fa-chevron-down text-gray-500"></i>
													</div>
												</div>
											</div>
										</div>
									</div>

									{{-- Content --}}
									<div class="glass-effect rounded-2xl p-6 border border-gray-700/30">
										<div class="flex items-center space-x-3 mb-6">
											<div class="w-8 h-8 bg-gradient-to-br from-purple-500/20 to-pink-600/20 rounded-lg flex items-center justify-center">
												<i class="fas fa-align-left text-purple-400 text-sm"></i>
											</div>
											<h4 class="font-bold text-lg text-white">Content</h4>
										</div>
										
										<div>
											<label for="content" class="block text-sm font-semibold text-gray-300 mb-3 flex items-center space-x-2">
												<span>Content</span>
												<span class="text-red-400">*</span>
											</label>
											<div class="relative">
												<textarea id="content" name="content" rows="5" required 
														  class="w-full px-4 py-4 rounded-xl bg-gray-800/50 border border-gray-600 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 transition-all duration-300 text-white placeholder-gray-400 resize-none"
														  placeholder="Enter your announcement content... (HTML supported)"></textarea>
											</div>
											<p class="text-xs text-gray-400 mt-2 flex items-center space-x-1">
												<i class="fas fa-info-circle text-purple-400"></i>
												<span>You can use basic HTML tags for formatting</span>
											</p>
										</div>
									</div>

									{{-- Targeting --}}
									<div class="glass-effect rounded-2xl p-6 border border-gray-700/30">
										<div class="flex items-center space-x-3 mb-6">
											<div class="w-8 h-8 bg-gradient-to-br from-purple-500/20 to-pink-600/20 rounded-lg flex items-center justify-center">
												<i class="fas fa-crosshairs text-purple-400 text-sm"></i>
											</div>
											<h4 class="font-bold text-lg text-white">Targeting</h4>
										</div>
										
										<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
											<div>
												<label for="target_scope" class="block text-sm font-semibold text-gray-300 mb-3">Target Scope *</label>
												<div class="relative">
													<div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
														<i class="fas fa-bullseye text-gray-500"></i>
													</div>
													<select id="target_scope" name="target_scope" required 
															class="w-full pl-10 pr-4 py-4 rounded-xl bg-gray-800/50 border border-gray-600 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 transition-all duration-300 text-white appearance-none">
														<option value="all" class="bg-gray-800">All Users</option>
														<option value="nodes" class="bg-gray-800">Specific Nodes</option>
														<option value="users" class="bg-gray-800">Specific Users</option>
													</select>
													<div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
														<i class="fas fa-chevron-down text-gray-500"></i>
													</div>
												</div>
											</div>
											
											<div id="target_nodes_container" class="hidden lg:col-span-2">
												<label for="target_nodes" class="block text-sm font-semibold text-gray-300 mb-3">Target Nodes</label>
												<div class="relative">
													<div class="absolute inset-y-0 left-0 pl-3 pt-4 pointer-events-none">
														<i class="fas fa-server text-gray-500"></i>
													</div>
													<select id="target_nodes" name="target_nodes[]" multiple 
															class="w-full pl-10 pr-4 py-4 rounded-xl bg-gray-800/50 border border-gray-600 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 transition-all duration-300 text-white h-32">
														@foreach($nodes as $node)
															<option value="{{ $node->id }}" class="bg-gray-800">{{ $node->name }} (ID: {{ $node->id }})</option>
														@endforeach
													</select>
												</div>
											</div>
											
											<div id="target_users_container" class="hidden lg:col-span-2">
												<label for="target_users" class="block text-sm font-semibold text-gray-300 mb-3">Target Users</label>
												<div class="relative">
													<div class="absolute inset-y-0 left-0 pl-3 pt-4 pointer-events-none">
														<i class="fas fa-users text-gray-500"></i>
													</div>
													<select id="target_users" name="target_users[]" multiple 
															class="w-full pl-10 pr-4 py-4 rounded-xl bg-gray-800/50 border border-gray-600 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 transition-all duration-300 text-white h-32">
														@foreach($users as $user)
															<option value="{{ $user->id }}" class="bg-gray-800">{{ $user->username }} ({{ $user->email }})</option>
														@endforeach
													</select>
												</div>
											</div>
										</div>
									</div>

									{{-- Scheduling --}}
									<div class="glass-effect rounded-2xl p-6 border border-gray-700/30">
										<div class="flex items-center space-x-3 mb-6">
											<div class="w-8 h-8 bg-gradient-to-br from-purple-500/20 to-pink-600/20 rounded-lg flex items-center justify-center">
												<i class="fas fa-clock text-purple-400 text-sm"></i>
											</div>
											<h4 class="font-bold text-lg text-white">Scheduling</h4>
										</div>
										
										<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
											<div>
												<label for="starts_at" class="block text-sm font-semibold text-gray-300 mb-3">Starts At (Optional)</label>
												<div class="relative">
													<div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
														<i class="fas fa-play text-gray-500"></i>
													</div>
													<input type="datetime-local" id="starts_at" name="starts_at" 
														   class="w-full pl-10 pr-4 py-4 rounded-xl bg-gray-800/50 border border-gray-600 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 transition-all duration-300 text-white">
												</div>
											</div>
											
											<div>
												<label for="ends_at" class="block text-sm font-semibold text-gray-300 mb-3">Ends At (Optional)</label>
												<div class="relative">
													<div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
														<i class="fas fa-stop text-gray-500"></i>
													</div>
													<input type="datetime-local" id="ends_at" name="ends_at" 
														   class="w-full pl-10 pr-4 py-4 rounded-xl bg-gray-800/50 border border-gray-600 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 transition-all duration-300 text-white">
												</div>
											</div>
										</div>
									</div>

									{{-- Settings --}}
									<div class="glass-effect rounded-2xl p-6 border border-gray-700/30">
										<div class="flex items-center space-x-3 mb-6">
											<div class="w-8 h-8 bg-gradient-to-br from-purple-500/20 to-pink-600/20 rounded-lg flex items-center justify-center">
												<i class="fas fa-cog text-purple-400 text-sm"></i>
											</div>
											<h4 class="font-bold text-lg text-white">Settings</h4>
										</div>
										
										<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
											<div>
												<label for="display_order" class="block text-sm font-semibold text-gray-300 mb-3">Display Order</label>
												<div class="relative">
													<div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
														<i class="fas fa-sort-numeric-down text-gray-500"></i>
													</div>
													<input type="number" id="display_order" name="display_order" value="0" min="0" 
														   class="w-full pl-10 pr-4 py-4 rounded-xl bg-gray-800/50 border border-gray-600 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 transition-all duration-300 text-white">
												</div>
											</div>
											
											<div class="flex flex-col space-y-4 lg:col-span-2">
												<label class="inline-flex items-center space-x-3 cursor-pointer p-3 rounded-lg hover:bg-gray-700/30 transition-colors duration-200">
													<div class="relative">
														<input type="checkbox" id="is_active" name="is_active" value="1" 
															   class="sr-only peer">
														<div class="w-10 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-0.5 after:left-0.5 after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-gradient-to-r peer-checked:from-purple-600 peer-checked:to-pink-600"></div>
													</div>
													<span class="text-sm font-medium text-gray-300">Active</span>
												</label>
												
												<label class="inline-flex items-center space-x-3 cursor-pointer p-3 rounded-lg hover:bg-gray-700/30 transition-colors duration-200">
													<div class="relative">
														<input type="checkbox" id="is_dismissible" name="is_dismissible" value="1" 
															   class="sr-only peer" checked>
														<div class="w-10 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-0.5 after:left-0.5 after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-gradient-to-r peer-checked:from-purple-600 peer-checked:to-pink-600"></div>
													</div>
													<span class="text-sm font-medium text-gray-300">Dismissible</span>
												</label>
											</div>
										</div>
									</div>

									{{-- Actions --}}
									<div class="flex justify-end space-x-4 pt-6 border-t border-gray-700/30">
										<button type="button" id="btnCancelAnnouncement" 
												class="px-8 py-4 bg-gray-700/50 hover:bg-gray-600/70 rounded-xl font-semibold transition-all duration-300 transform hover:scale-105 border border-gray-600 text-gray-300 flex items-center space-x-2">
											<i class="fas fa-times"></i>
											<span>Cancel</span>
										</button>
										<button type="submit" 
												class="px-8 py-4 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 rounded-xl font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg shadow-purple-500/25 text-white flex items-center space-x-3">
											<i class="fas fa-paper-plane"></i>
											<span>Publish Announcement</span>
										</button>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</form>
		</div>

        {{-- Panel Preview Tab --}}
        <div id="panel-preview-tab" class="tab-content hidden">
            <div class="glass-effect rounded-2xl p-6 settings-card group relative overflow-hidden backdrop-blur-xl border border-gray-700/30 h-full">
                <div class="absolute inset-0 bg-gradient-to-br from-cyan-500/5 to-blue-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                <div class="relative h-full flex flex-col">
                    <div class="flex items-center justify-between mb-6">
                        <div>
                            <h3 class="font-semibold text-xl flex items-center">
                                <div class="w-10 h-10 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl flex items-center justify-center mr-3">
                                    <i class="fas fa-desktop text-white"></i>
                                </div>
                                Live Panel Preview
                            </h3>
                            <p class="text-gray-400 mt-1">See your changes in real-time</p>
                        </div>
                        
                        <div class="flex items-center space-x-3">
                            <span class="px-3 py-1 bg-gradient-to-r from-green-900/30 to-green-800/30 rounded-full text-green-300 border border-green-500/20 flex items-center">
                                <i class="fas fa-circle text-xs mr-2 animate-pulse"></i> Live
                            </span>
                            <button type="button" id="btnRefreshPreview" class="px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded-xl font-medium transition-colors flex items-center">
                                <i class="fas fa-sync-alt mr-2"></i> Refresh
                            </button>
                            <button type="button" id="btnOpenNewTab" class="px-4 py-2 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 rounded-xl font-medium transition-all duration-300 flex items-center">
                                <i class="fas fa-external-link-alt mr-2"></i> Open in New Tab
                            </button>
                        </div>
                    </div>
                    
                    <div class="gradient-border flex-grow">
                        <div class="bg-gray-900 rounded-xl p-4 h-full">
                            <div class="relative overflow-hidden rounded-lg border border-gray-700 bg-black h-full flex flex-col">
                                {{-- Browser Controls --}}
                                <div class="flex items-center justify-between px-4 py-3 bg-gray-900 border-b border-gray-700 flex-shrink-0">
                                    <div class="flex items-center space-x-3">
                                        <div class="flex space-x-2">
                                            <div class="w-3 h-3 bg-red-500 rounded-full"></div>
                                            <div class="w-3 h-3 bg-yellow-500 rounded-full"></div>
                                            <div class="w-3 h-3 bg-green-500 rounded-full"></div>
                                        </div>
                                        <div class="flex items-center bg-gray-800 rounded-lg px-3 py-1.5 text-sm border border-gray-600">
                                            <i class="fas fa-lock text-green-400 mr-2"></i>
                                            <span id="currentUrl" class="text-gray-300">{{ url('/') }}</span>
                                        </div>
                                    </div>
                                    <div class="flex items-center space-x-3">
                                        <button type="button" id="btnZoomOut" class="text-gray-400 hover:text-white transition-colors p-1 rounded">
                                            <i class="fas fa-search-minus"></i>
                                        </button>
                                        <span id="frameScale" class="text-sm text-gray-300">100%</span>
                                        <button type="button" id="btnZoomIn" class="text-gray-400 hover:text-white transition-colors p-1 rounded">
                                            <i class="fas fa-search-plus"></i>
                                        </button>
                                        <button type="button" id="btnRefreshPreview2" class="text-gray-400 hover:text-white transition-colors p-1 rounded">
                                            <i class="fas fa-sync-alt"></i>
                                        </button>
                                        <button type="button" id="btnOpenNewTab2" class="text-gray-400 hover:text-white transition-colors p-1 rounded">
                                            <i class="fas fa-expand"></i>
                                        </button>
                                    </div>
                                </div>
                                
                                {{-- Preview Frame --}}
                                <div class="overflow-auto bg-gray-900 flex-grow p-4" style="max-height: calc(100vh - 250px);">
                                    <iframe 
                                        id="panelPreviewFrame" 
                                        src="{{ url('/') }}" 
                                        class="w-full h-full transition-all duration-300 rounded-lg shadow-lg"
                                        style="transform-origin: top left; transform: scale(1); min-height: 600px;"
                                        onload="frameLoaded()"
                                        frameborder="0"
                                        allow="fullscreen"
                                    ></iframe>
                                </div>
                                
                                {{-- Loading Indicator --}}
                                <div id="frameLoading" class="absolute inset-0 bg-gray-900 flex items-center justify-center flex-col">
                                    <div class="text-center">
                                        <div class="w-16 h-16 border-4 border-primary-500 border-t-transparent rounded-full animate-spin mb-4"></div>
                                        <p class="text-gray-300 text-lg font-medium">Loading panel preview...</p>
                                        <p class="text-gray-500 text-sm mt-1">This may take a moment</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mt-4 text-sm text-gray-400 flex justify-between items-center">
                        <span>Preview updates automatically when you save changes</span>
                        <span id="frameDimensions" class="text-gray-300">Dimensions: <span id="frameWidth">1280</span>×<span id="frameHeight">720</span>px</span>
                    </div>
                </div>
            </div>
        </div>
		
		{{-- Modules Tab --}}
		<div id="modules-tab" class="tab-content hidden space-y-6">
			<div class="glass-effect rounded-2xl p-8 settings-card group relative overflow-hidden backdrop-blur-xl border border-gray-700/30">
				<div class="absolute inset-0 bg-gradient-to-br from-blue-500/8 to-cyan-500/8 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
				
				{{-- Animated Background Elements --}}
				<div class="absolute inset-0 overflow-hidden pointer-events-none">
					<div class="absolute -top-20 -right-20 w-40 h-40 bg-blue-500/10 rounded-full blur-3xl animate-pulse"></div>
					<div class="absolute -bottom-20 -left-20 w-40 h-40 bg-cyan-500/10 rounded-full blur-3xl animate-pulse" style="animation-delay: 1s"></div>
				</div>

				<div class="relative">
					{{-- Header --}}
					<div class="text-center mb-8">
						<div class="relative inline-block mb-6">
							<div class="w-24 h-24 bg-gradient-to-br from-blue-500 via-blue-600 to-cyan-500 rounded-3xl flex items-center justify-center mx-auto shadow-2xl shadow-blue-500/30 animate-float">
								<i class="fas fa-cube text-white text-3xl"></i>
							</div>
							<div class="absolute -top-2 -right-2 w-8 h-8 bg-gradient-to-br from-cyan-400 to-blue-400 rounded-full flex items-center justify-center shadow-lg">
								<i class="fas fa-bolt text-white text-xs"></i>
							</div>
						</div>
						<h2 class="text-4xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent mb-4 tracking-tight">
							Modules System
						</h2>
						<p class="text-gray-300 text-lg max-w-2xl mx-auto leading-relaxed mb-6">
							Enhance your panel with powerful modules. Add your module files to your pterodactyl directory to get started.
						</p>

						{{-- Controls --}}
						<div class="flex items-center justify-center space-x-4 mb-6">
							<div id="modules-count" class="px-4 py-2 bg-blue-900/40 rounded-full border border-blue-500/30 text-blue-200 text-sm font-semibold">
								Loading modules...
							</div>
						</div>
					</div>

					{{-- Loading State --}}
					<div id="modules-loading" class="text-center py-12">
						<div class="inline-flex items-center justify-center space-x-3 text-blue-300">
							<i class="fas fa-circle-notch fa-spin text-xl"></i>
							<span class="text-lg font-semibold">Loading modules...</span>
						</div>
					</div>

					{{-- Error State --}}
					<div id="modules-error" class="hidden text-center py-12">
						<div class="inline-block max-w-md">
							<div class="w-20 h-20 bg-gradient-to-br from-red-500 to-pink-600 rounded-3xl flex items-center justify-center mx-auto mb-4 shadow-2xl shadow-red-500/30">
								<i class="fas fa-exclamation-triangle text-white text-2xl"></i>
							</div>
							<h3 class="text-xl font-bold text-red-200 mb-2">Failed to load modules</h3>
							<p class="text-red-300/80 mb-6" id="error-message"></p>
							<button id="retry-loading" class="px-6 py-3 bg-gradient-to-r from-red-600 to-pink-600 hover:from-red-500 hover:to-pink-500 rounded-2xl font-semibold transition-all duration-300 transform hover:scale-105 flex items-center space-x-3 shadow-lg shadow-red-500/30 mx-auto">
								<i class="fas fa-redo text-white"></i>
								<span class="text-white tracking-wide">Try Again</span>
							</button>
						</div>
					</div>

					{{-- Empty State --}}
					<div id="modules-empty" class="hidden text-center py-16">
						<div class="inline-block max-w-md">
							<div class="w-24 h-24 bg-gradient-to-br from-gray-500 to-gray-600 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-2xl shadow-gray-500/30">
								<i class="fas fa-box-open text-white text-3xl"></i>
							</div>
							<h3 class="text-2xl font-bold text-gray-200 mb-3">No Modules Found</h3>
							<p class="text-gray-400 mb-6 leading-relaxed">
								No .module files found in your modules directory. Add module files to get started.
							</p>
							<div class="bg-gray-800/50 rounded-2xl p-6 border border-gray-700/50 text-left">
								<h4 class="font-semibold text-gray-200 mb-3 flex items-center">
									<i class="fas fa-info-circle text-blue-400 mr-2"></i>
									How to add modules:
								</h4>
								<ol class="text-gray-400 text-sm space-y-2 list-decimal list-inside">
									<li>Create a folder named <code class="bg-gray-900 px-2 py-1 rounded">modules</code> in your panel root</li>
									<li>Add <code class="bg-gray-900 px-2 py-1 rounded">.module</code> files with JSON content</li>
									<li>Click refresh to load your modules</li>
								</ol>
							</div>
						</div>
					</div>

					{{-- Dynamic Modules Grid --}}
					<div id="modules-grid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
						<!-- Modules will be dynamically inserted here -->
					</div>
				</div>
			</div>
		</div>
    </main>
</div>

<script>
// Announcements Management
document.addEventListener('DOMContentLoaded', function() {
    console.log('Announcements JavaScript loaded');
    
    const announcementsSystemToggle = document.getElementById('announcementsSystemToggle');
    const btnCreateAnnouncement = document.getElementById('btnCreateAnnouncement');
    const announcementModal = document.getElementById('announcementModal');
    const btnCloseModal = document.getElementById('btnCloseModal');
    const btnCancelAnnouncement = document.getElementById('btnCancelAnnouncement');
    const announcementForm = document.getElementById('announcementForm');
    const targetScope = document.getElementById('target_scope');
    const targetNodesContainer = document.getElementById('target_nodes_container');
    const targetUsersContainer = document.getElementById('target_users_container');

    console.log('Elements found:', {
        announcementsSystemToggle: !!announcementsSystemToggle,
        btnCreateAnnouncement: !!btnCreateAnnouncement,
        announcementModal: !!announcementModal,
        announcementForm: !!announcementForm
    });

    // Toggle announcements system
    if (announcementsSystemToggle) {
        announcementsSystemToggle.addEventListener('change', function() {
            const enabled = this.checked;
            console.log('Toggling announcements system to:', enabled);
            
            fetch('{{ route("admin.announcements.toggle") }}', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    announcements_enabled: enabled
                })
            })
            .then(response => {
                console.log('Toggle response status:', response.status);
                return response.json();
            })
            .then(data => {
                console.log('Toggle response data:', data);
                if (data.success) {
                    showNotification(`Announcements system ${enabled ? 'enabled' : 'disabled'}`, 'success');
                } else {
                    showNotification('Failed to update announcements system: ' + (data.message || 'Unknown error'), 'error');
                }
            })
            .catch(error => {
                console.error('Toggle error:', error);
                showNotification('Failed to update announcements system', 'error');
            });
        });
    }

    // Show announcement modal
    if (btnCreateAnnouncement) {
        btnCreateAnnouncement.addEventListener('click', function() {
            console.log('Create announcement button clicked');
            document.getElementById('modalTitle').textContent = 'Create New Announcement';
            announcementForm.reset();
            document.getElementById('announcementId').value = '';
            announcementModal.classList.remove('hidden');
            announcementModal.classList.add('flex');
        });
    }

    // Close modal
    function closeModal() {
        console.log('Closing modal');
        announcementModal.classList.add('hidden');
        announcementModal.classList.remove('flex');
    }

    if (btnCloseModal) btnCloseModal.addEventListener('click', closeModal);
    if (btnCancelAnnouncement) btnCancelAnnouncement.addEventListener('click', closeModal);

    // Handle target scope change
    if (targetScope) {
        targetScope.addEventListener('change', function() {
            const scope = this.value;
            console.log('Target scope changed to:', scope);
            
            targetNodesContainer.classList.add('hidden');
            targetUsersContainer.classList.add('hidden');
            
            if (scope === 'nodes') {
                targetNodesContainer.classList.remove('hidden');
            } else if (scope === 'users') {
                targetUsersContainer.classList.remove('hidden');
            }
        });
    }

    // Edit announcement
    document.querySelectorAll('.edit-announcement').forEach(button => {
        button.addEventListener('click', function() {
            const announcementId = this.dataset.id;
            console.log('Edit announcement clicked:', announcementId);
            
            fetch(`/admin/announcements/${announcementId}/edit`)
                .then(response => {
                    console.log('Edit fetch response status:', response.status);
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(announcement => {
                    console.log('Edit announcement data:', announcement);
                    document.getElementById('modalTitle').textContent = 'Edit Announcement';
                    document.getElementById('announcementId').value = announcement.id;
                    document.getElementById('title').value = announcement.title;
                    document.getElementById('type').value = announcement.type;
                    document.getElementById('content').value = announcement.content;
                    document.getElementById('target_scope').value = announcement.target_scope;
                    document.getElementById('display_order').value = announcement.display_order;
                    document.getElementById('starts_at').value = announcement.starts_at ? announcement.starts_at.replace(' ', 'T') : '';
                    document.getElementById('ends_at').value = announcement.ends_at ? announcement.ends_at.replace(' ', 'T') : '';
                    document.getElementById('is_active').checked = announcement.is_active;
                    document.getElementById('is_dismissible').checked = announcement.is_dismissible;

                    // Handle target scope display
                    targetScope.dispatchEvent(new Event('change'));

                    // Set target nodes/users if applicable
                    if (announcement.target_scope === 'nodes' && announcement.target_nodes) {
                        const targetNodes = JSON.parse(announcement.target_nodes);
                        console.log('Setting target nodes:', targetNodes);
                        const nodesSelect = document.getElementById('target_nodes');
                        Array.from(nodesSelect.options).forEach(option => {
                            option.selected = targetNodes.includes(parseInt(option.value));
                        });
                    }

                    if (announcement.target_scope === 'users' && announcement.target_users) {
                        const targetUsers = JSON.parse(announcement.target_users);
                        console.log('Setting target users:', targetUsers);
                        const usersSelect = document.getElementById('target_users');
                        Array.from(usersSelect.options).forEach(option => {
                            option.selected = targetUsers.includes(parseInt(option.value));
                        });
                    }

                    announcementModal.classList.remove('hidden');
                    announcementModal.classList.add('flex');
                })
                .catch(error => {
                    console.error('Error fetching announcement:', error);
                    showNotification('Failed to load announcement data', 'error');
                });
        });
    });

    // Delete announcement
    document.querySelectorAll('.delete-announcement').forEach(button => {
        button.addEventListener('click', function() {
            const announcementId = this.dataset.id;
            console.log('Delete announcement clicked:', announcementId);
            
            if (confirm('Are you sure you want to delete this announcement? This action cannot be undone.')) {
                fetch(`/admin/announcements/${announcementId}`, {
                    method: 'DELETE',
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}',
                        'Accept': 'application/json'
                    }
                })
                .then(response => {
                    console.log('Delete response status:', response.status);
                    if (response.ok) {
                        showNotification('Announcement deleted successfully', 'success');
                        location.reload();
                    } else {
                        showNotification('Failed to delete announcement, maybe refresh and it will update', 'error');
                    }
                })
                .catch(error => {
                    console.error('Delete error:', error);
                    showNotification('Failed to delete announcement, maybe refresh and it will update', 'error');
                });
            }
        });
    });

    // Handle form submission
    if (announcementForm) {
        announcementForm.addEventListener('submit', function(e) {
            e.preventDefault();
            console.log('Form submission intercepted');
            
            const formData = new FormData(this);
            const data = Object.fromEntries(formData.entries());
            
            console.log('Form data before processing:', data);
            
            // Convert arrays for nodes and users
            if (data.target_scope === 'nodes') {
                data.target_nodes = Array.from(document.getElementById('target_nodes').selectedOptions).map(opt => parseInt(opt.value));
            }
            if (data.target_scope === 'users') {
                data.target_users = Array.from(document.getElementById('target_users').selectedOptions).map(opt => parseInt(opt.value));
            }
            
            // Convert checkbox values to booleans
            data.is_active = data.is_active === '1';
            data.is_dismissible = data.is_dismissible === '1';
            
            console.log('Processed data for API:', data);
            
            fetch(this.action, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Accept': 'application/json'
                },
                body: JSON.stringify(data)
            })
            .then(response => {
                console.log('API Response status:', response.status);
                console.log('API Response headers:', Object.fromEntries(response.headers.entries()));
                return response.json().then(jsonData => {
                    console.log('API Response JSON:', jsonData);
                    return {
                        status: response.status,
                        ok: response.ok,
                        data: jsonData
                    };
                });
            })
            .then(result => {
                console.log('Processed response:', result);
                if (result.ok) {
                    showNotification(result.data.message || 'Announcement saved successfully', 'success');
                    closeModal();
                    setTimeout(() => {
                        console.log('Reloading page...');
                        location.reload();
                    }, 1000);
                } else {
                    showNotification(result.data.message || 'Failed to save announcement', 'error');
                }
            })
            .catch(error => {
                console.error('Form submission error:', error);
                showNotification('Failed to save announcement: ' + error.message, 'error');
            });
        });
    }

    // Utility function for notifications
    function showNotification(message, type = 'info') {
        console.log('Showing notification:', { message, type });
        const notification = document.createElement('div');
        notification.className = `fixed top-4 right-4 px-6 py-3 rounded-xl backdrop-blur-xl border z-50 transform animate-slide-in-right ${
            type === 'success' ? 'bg-green-500/10 border-green-500/30 text-green-300' :
            type === 'error' ? 'bg-red-500/10 border-red-500/30 text-red-300' :
            'bg-blue-500/10 border-blue-500/30 text-blue-300'
        }`;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 5000);
    }
	
});

document.addEventListener('DOMContentLoaded', function() {
    // Handle empty state create button
    const btnCreateAnnouncementEmpty = document.getElementById('btnCreateAnnouncementEmpty');
    if (btnCreateAnnouncementEmpty) {
        btnCreateAnnouncementEmpty.addEventListener('click', function() {
            document.getElementById('modalTitle').textContent = 'Create New Announcement';
            document.getElementById('announcementForm').reset();
            document.getElementById('announcementId').value = '';
            document.getElementById('announcementModal').classList.remove('hidden');
            document.getElementById('announcementModal').classList.add('flex');
        });
    }
});
</script>

<script>
class ModuleManager {
    constructor() {
        this.modules = [];
        this.init();
    }

    init() {
        this.bindEvents();
        this.loadModules();
    }

    bindEvents() {

        // Retry loading button
        document.getElementById('retry-loading').addEventListener('click', () => {
            this.loadModules();
        });

        // Tab visibility change
        document.addEventListener('visibilitychange', () => {
            if (!document.hidden && document.getElementById('modules-tab').classList.contains('active')) {
                this.refreshModules();
            }
        });
    }

    async loadModules() {
        this.showLoading();
        this.hideError();
        this.hideEmpty();

        try {
            const response = await fetch('/admin/modules/data');
            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || 'Failed to load modules');
            }

            if (data.success) {
                this.modules = data.modules || [];
                this.renderModules();
                this.updateModulesCount();
            } else {
                throw new Error(data.message || 'Failed to load modules');
            }
        } catch (error) {
            console.error('Error loading modules:', error);
            this.showError(error.message);
        }
    }

    renderModules() {
        const grid = document.getElementById('modules-grid');
        
        if (this.modules.length === 0) {
            this.showEmpty();
            return;
        }

        grid.innerHTML = this.modules.map(module => this.createModuleCard(module)).join('');
        this.hideLoading();
        this.hideEmpty();
    }

    createModuleCard(module) {
        const iconUrl = module.icon || '/assets/default-module-icon.png';
        const version = module.version || '1.0.0';
        const author = module.author || 'Unknown';
        const website = module.website || '#';
        
        return `
            <div class="relative group transform hover:scale-105 transition-all duration-500" data-module="${module.name}">
                <div class="glass-effect rounded-2xl p-6 border border-gray-700/30 backdrop-blur-xl transition-all duration-500 h-full flex flex-col hover:border-blue-500/50">
                    <div class="flex items-center justify-between mb-4">
                        <div class="w-14 h-14 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-2xl flex items-center justify-center shadow-lg shadow-blue-500/25 overflow-hidden">
                            ${this.getModuleIcon(iconUrl, module.name)}
                        </div>
                        <span class="px-3 py-1.5 bg-gradient-to-r from-green-900/40 to-emerald-900/40 rounded-full text-green-200 border border-green-500/30 text-xs font-semibold tracking-wide">
                            INSTALLED
                        </span>
                    </div>
                    
                    <h3 class="font-bold text-xl mb-2 text-white">${this.escapeHtml(module.name)}</h3>
                    <p class="text-gray-400 text-sm mb-4 leading-relaxed flex-grow">
                        ${this.escapeHtml(module.description)}
                    </p>
                    
                    <div class="space-y-3 mb-4">
                        <div class="flex items-center justify-between text-xs">
                            <span class="text-gray-500">Version:</span>
                            <span class="text-blue-300 font-semibold">v${version}</span>
                        </div>
                        <div class="flex items-center justify-between text-xs">
                            <span class="text-gray-500">Author:</span>
                            <a href="${website}" target="_blank" class="text-cyan-300 hover:text-cyan-200 transition-colors font-semibold">
                                ${this.escapeHtml(author)}
                            </a>
                        </div>
                    </div>

                    <div class="flex items-center justify-between pt-4 border-t border-gray-700/30">
                        <div class="flex items-center space-x-2">
                            <span class="text-green-300 font-bold text-sm">ACTIVE</span>
                        </div>
                        <div class="flex space-x-2">
                            <button class="module-settings w-8 h-8 bg-blue-600 hover:bg-blue-500 rounded-lg flex items-center justify-center transition-all duration-300 group/settings" title="Settings">
                                <i class="fas fa-cog text-white text-xs group-hover/settings:rotate-90 transition-transform"></i>
                            </button>
                            <button class="module-deactivate w-8 h-8 bg-red-600 hover:bg-red-500 rounded-lg flex items-center justify-center transition-all duration-300" title="Deactivate">
                                <i class="fas fa-power-off text-white text-xs"></i>
                            </button>
                        </div>
                    </div>
                </div>
                
                {{-- Active indicator glow --}}
                <div class="absolute inset-0 rounded-2xl bg-gradient-to-r from-green-500/10 to-emerald-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"></div>
            </div>
        `;
    }

    getModuleIcon(iconUrl, moduleName) {
        if (iconUrl.startsWith('http') || iconUrl.startsWith('/')) {
            return `<img src="${iconUrl}" alt="${moduleName}" class="w-8 h-8 object-cover rounded-lg" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';" />
                    <i class="fas fa-cube text-white text-xl" style="display: none;"></i>`;
        } else if (iconUrl.includes('fa-')) {
            return `<i class="${iconUrl} text-white text-xl"></i>`;
        } else {
            return `<i class="fas fa-cube text-white text-xl"></i>`;
        }
    }

    updateModulesCount() {
        const countElement = document.getElementById('modules-count');
        if (countElement) {
            countElement.textContent = `${this.modules.length} module${this.modules.length !== 1 ? 's' : ''} loaded`;
        }
    }

    showLoading() {
        document.getElementById('modules-loading').classList.remove('hidden');
        document.getElementById('modules-grid').classList.add('hidden');
    }

    hideLoading() {
        document.getElementById('modules-loading').classList.add('hidden');
        document.getElementById('modules-grid').classList.remove('hidden');
    }

    showError(message) {
        document.getElementById('modules-error').classList.remove('hidden');
        document.getElementById('error-message').textContent = message;
        document.getElementById('modules-loading').classList.add('hidden');
        document.getElementById('modules-grid').classList.add('hidden');
    }

    hideError() {
        document.getElementById('modules-error').classList.add('hidden');
    }

    showEmpty() {
        document.getElementById('modules-empty').classList.remove('hidden');
        document.getElementById('modules-loading').classList.add('hidden');
        document.getElementById('modules-grid').classList.add('hidden');
    }

    hideEmpty() {
        document.getElementById('modules-empty').classList.add('hidden');
    }

    showToast(message, type = 'info') {
        // You can integrate with your existing toast system or create a simple one
        const toast = document.createElement('div');
        toast.className = `fixed top-4 right-4 px-6 py-3 rounded-2xl font-semibold text-white backdrop-blur-xl border ${
            type === 'success' ? 'bg-green-900/30 border-green-500/30' : 
            type === 'error' ? 'bg-red-900/30 border-red-500/30' : 
            'bg-blue-900/30 border-blue-500/30'
        } z-50 transform translate-x-full transition-transform duration-300`;
        toast.textContent = message;
        
        document.body.appendChild(toast);
        
        // Animate in
        setTimeout(() => toast.classList.remove('translate-x-full'), 100);
        
        // Remove after 3 seconds
        setTimeout(() => {
            toast.classList.add('translate-x-full');
            setTimeout(() => document.body.removeChild(toast), 300);
        }, 3000);
    }

    escapeHtml(unsafe) {
        return unsafe
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }
}

// Initialize module manager when the page loads
document.addEventListener('DOMContentLoaded', function() {
    window.moduleManager = new ModuleManager();
    
    // Also initialize when modules tab becomes active
    const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
                const target = mutation.target;
                if (target.id === 'modules-tab' && target.classList.contains('active')) {
                    // Refresh modules when tab becomes active
                    window.moduleManager.loadModules();
                }
            }
        });
    });
    
    const modulesTab = document.getElementById('modules-tab');
    if (modulesTab) {
        observer.observe(modulesTab, { attributes: true });
    }
});
</script>

<script>
// Get active tab from URL
const urlParams = new URLSearchParams(window.location.search);
const activeTabParam = urlParams.get('tab') || 'background';

// Initialize JS data from server-rendered variables
const initialBackground = @json($background ?? null);
const initialNavigationLinks = @json($navigation_links ?? []);

// ---- Navigation Links Functions ----
let navigationLinks = @json($navigation_links ?? []);
let dragSourceIndex = null;
let isDragging = false;

function renderNavigationLinks() {
    const list = document.getElementById('navigationLinksList');
    const emptyState = document.getElementById('navLinksEmpty');
    
    if (!list) return;
    
    list.innerHTML = '';
    
    if (!navigationLinks || navigationLinks.length === 0) {
        if (emptyState) emptyState.classList.remove('hidden');
        list.classList.add('hidden');
        updateNavigationLinksHiddenField();
        return;
    }
    
    if (emptyState) emptyState.classList.add('hidden');
    list.classList.remove('hidden');
    
    // Group links by category
    const categories = {};
    navigationLinks.forEach(link => {
        if (!categories[link.category]) {
            categories[link.category] = [];
        }
        categories[link.category].push(link);
    });
    
    // Render each category
    Object.keys(categories).forEach(category => {
        const categoryLinks = categories[category].sort((a, b) => a.order - b.order);
        
        // Category header
        const categoryHeader = document.createElement('div');
        categoryHeader.className = 'category-group';
        categoryHeader.innerHTML = `
            <div class="flex items-center justify-between p-4 bg-gradient-to-r from-gray-800 to-gray-900 rounded-lg border border-gray-700 mb-3">
                <div class="flex items-center space-x-3">
                    <div class="drag-handle cursor-move p-2 text-gray-400 hover:text-white transition-colors">
                        <i class="fas fa-grip-vertical"></i>
                    </div>
                    <i class="fas fa-folder text-yellow-400 text-lg"></i>
                    <div>
                        <h4 class="font-semibold text-white">${category.charAt(0).toUpperCase() + category.slice(1)}</h4>
                        <p class="text-xs text-gray-400">${categoryLinks.length} link${categoryLinks.length !== 1 ? 's' : ''} in this category</p>
                    </div>
                </div>
                <div class="flex items-center space-x-2">
                    <span class="px-2 py-1 bg-gray-700 rounded text-xs text-gray-300 capitalize">${category}</span>
                    <button type="button" onclick="removeCategory('${category}')" class="p-2 text-red-400 hover:text-red-300 transition-colors rounded-lg hover:bg-red-900/20">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `;
        
        // Add drag handle for category
        const categoryDragHandle = categoryHeader.querySelector('.drag-handle');
        categoryDragHandle.addEventListener('mousedown', (e) => startCategoryDrag(e, category));
        
        list.appendChild(categoryHeader);
        
        // Links in this category
        categoryLinks.forEach((link, index) => {
            const globalIndex = navigationLinks.findIndex(l => l.id === link.id);
            const linkElement = createNavLinkElement(link, globalIndex, category);
            list.appendChild(linkElement);
        });
    });
    
    updateNavigationLinksHiddenField();
}

function createNavLinkElement(link, index, category) {
    const linkElement = document.createElement('div');
    const categoryColor = category === 'server' ? 'green' : 'blue';
    
    linkElement.className = `nav-link-item bg-gray-800/50 border border-gray-700 rounded-lg p-4 mb-3 transition-all duration-200 hover:border-${categoryColor}-500/30`;
    linkElement.setAttribute('data-id', link.id);
    linkElement.setAttribute('data-category', category);
    
    linkElement.innerHTML = `
        <div class="flex items-start space-x-4">
            {{-- Drag Handle --}}
            <div class="drag-handle cursor-move pt-3 text-gray-500 hover:text-gray-300 transition-colors">
                <i class="fas fa-grip-vertical"></i>
            </div>
            
            {{-- Icon and Status --}}
            <div class="flex-shrink-0">
                <div class="w-12 h-12 rounded-lg bg-gray-700 flex items-center justify-center relative">
                    <i class="fas fa-${link.icon || 'link'} text-${categoryColor}-400 text-lg"></i>
                    ${!link.enabled ? '<div class="absolute -top-1 -right-1 w-3 h-3 bg-gray-500 rounded-full border-2 border-gray-800"></div>' : ''}
                    ${link.requires_root ? '<div class="absolute -bottom-1 -right-1 w-3 h-3 bg-red-500 rounded-full border-2 border-gray-800"></div>' : ''}
                </div>
            </div>
            
            {{-- Form Fields --}}
            <div class="flex-1 grid grid-cols-1 lg:grid-cols-2 gap-4">
                {{-- Basic Info --}}
                <div class="space-y-3">
                    <div>
                        <label class="block text-xs font-medium text-gray-400 mb-1">Link Name</label>
                        <input type="text" 
                               value="${link.name || ''}" 
                               placeholder="Dashboard, Settings, etc."
                               class="w-full px-3 py-2 text-sm bg-gray-900 border border-gray-600 rounded focus:border-${categoryColor}-500 focus:ring-1 focus:ring-${categoryColor}-500 transition-colors nav-link-name"
                               oninput="updateNavLinkField(${index}, 'name', this.value)">
                    </div>
                    
                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="block text-xs font-medium text-gray-400 mb-1">Icon</label>
                            <input type="text" 
                                   value="${link.icon || ''}" 
                                   placeholder="home, cog, user..."
                                   class="w-full px-3 py-2 text-sm bg-gray-900 border border-gray-600 rounded focus:border-${categoryColor}-500 focus:ring-1 focus:ring-${categoryColor}-500 transition-colors nav-link-icon"
                                   oninput="updateNavLinkField(${index}, 'icon', this.value)">
                        </div>
                        
                        <div>
                            <label class="block text-xs font-medium text-gray-400 mb-1">Category</label>
                            <select class="w-full px-3 py-2 text-sm bg-gray-900 border border-gray-600 rounded focus:border-${categoryColor}-500 focus:ring-1 focus:ring-${categoryColor}-500 transition-colors nav-link-category"
                                    onchange="updateNavLinkField(${index}, 'category', this.value)">
                                <option value="main" ${link.category === 'main' ? 'selected' : ''}>Main</option>
                                <option value="server" ${link.category === 'server' ? 'selected' : ''}>Server</option>
                            </select>
                        </div>
                    </div>
                </div>
                
                {{-- URL and Settings --}}
                <div class="space-y-3">
                    <div>
                        <label class="block text-xs font-medium text-gray-400 mb-1">URL</label>
                        <input type="text" 
                               value="${link.link || ''}" 
                               placeholder="/dashboard, /admin, /server/{id}..."
                               class="w-full px-3 py-2 text-sm bg-gray-900 border border-gray-600 rounded focus:border-${categoryColor}-500 focus:ring-1 focus:ring-${categoryColor}-500 transition-colors nav-link-url"
                               oninput="updateNavLinkField(${index}, 'link', this.value)">
                    </div>
                    
                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="block text-xs font-medium text-gray-400 mb-1">Target</label>
                            <select class="w-full px-3 py-2 text-sm bg-gray-900 border border-gray-600 rounded focus:border-${categoryColor}-500 focus:ring-1 focus:ring-${categoryColor}-500 transition-colors nav-link-target"
                                    onchange="updateNavLinkField(${index}, 'target', this.value)">
                                <option value="_self" ${link.target === '_self' ? 'selected' : ''}>Same Tab</option>
                                <option value="_blank" ${link.target === '_blank' ? 'selected' : ''}>New Tab</option>
                            </select>
                        </div>
                        
                        <div class="flex items-center justify-end space-x-4 pt-6">
                            <label class="flex items-center space-x-2 cursor-pointer">
                                <input type="checkbox" ${link.enabled ? 'checked' : ''} 
                                       class="nav-link-enabled h-4 w-4 rounded bg-gray-800 border-gray-600 text-${categoryColor}-600 focus:ring-${categoryColor}-500"
                                       onchange="updateNavLinkField(${index}, 'enabled', this.checked)">
                                <span class="text-xs text-gray-300">Enabled</span>
                            </label>
                            
                            <label class="flex items-center space-x-2 cursor-pointer">
                                <input type="checkbox" ${link.requires_root ? 'checked' : ''}
                                       class="nav-link-requires-root h-4 w-4 rounded bg-gray-800 border-gray-600 text-red-600 focus:ring-red-500"
                                       onchange="updateNavLinkField(${index}, 'requires_root', this.checked)">
                                <span class="text-xs text-gray-300">Admin Only</span>
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            
            {{-- Actions --}}
            <div class="flex flex-col space-y-2 pt-1">
                <button type="button" 
                        onclick="moveNavLinkUp(${index})" 
                        class="p-2 text-gray-400 hover:text-white transition-colors ${index === 0 ? 'opacity-30 cursor-not-allowed' : ''}"
                        ${index === 0 ? 'disabled' : ''}>
                    <i class="fas fa-chevron-up"></i>
                </button>
                <button type="button" 
                        onclick="moveNavLinkDown(${index})" 
                        class="p-2 text-gray-400 hover:text-white transition-colors ${index === navigationLinks.length - 1 ? 'opacity-30 cursor-not-allowed' : ''}"
                        ${index === navigationLinks.length - 1 ? 'disabled' : ''}>
                    <i class="fas fa-chevron-down"></i>
                </button>
                <button type="button" 
                        onclick="removeNavLink(${index})" 
                        class="p-2 text-red-400 hover:text-red-300 transition-colors">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
        
        {{-- Live Preview --}}
        <div class="mt-3 pt-3 border-t border-gray-700">
            <div class="flex items-center justify-between">
                <span class="text-xs text-gray-400">Live Preview:</span>
                <div class="flex items-center space-x-3 px-4 py-2 bg-gray-900 rounded-lg">
                    <i class="fas fa-${link.icon || 'link'} text-${categoryColor}-400"></i>
                    <span class="text-sm text-gray-300">${link.name || 'New Link'}</span>
                    ${link.requires_root ? '<span class="px-2 py-1 bg-red-500/20 text-red-400 rounded text-xs">Admin</span>' : ''}
                    ${!link.enabled ? '<span class="px-2 py-1 bg-gray-500/20 text-gray-400 rounded text-xs">Disabled</span>' : ''}
                    <span class="px-2 py-1 bg-${categoryColor}-500/20 text-${categoryColor}-400 rounded text-xs capitalize">${link.category}</span>
                </div>
            </div>
        </div>
    `;
    
    // Add drag functionality
    const dragHandle = linkElement.querySelector('.drag-handle');
    dragHandle.addEventListener('mousedown', (e) => startNavLinkDrag(e, index));
    
    return linkElement;
}

function updateNavLinkField(index, field, value) {
    if (navigationLinks[index]) {
        navigationLinks[index][field] = value;
        
        // Update live preview in real-time
        const linkElement = document.querySelector(`[data-id="${navigationLinks[index].id}"]`);
        if (linkElement) {
            const previewElement = linkElement.querySelector('.text-gray-300');
            const iconElement = linkElement.querySelector('.fa-link, .fa-home, .fa-cog, .fa-user, .fa-terminal, .fa-folder, .fa-database, .fa-clock, .fa-users, .fa-archive, .fa-network-wired, .fa-sliders-h, .fa-chart-bar');
            
            if (field === 'name' && previewElement) {
                previewElement.textContent = value || 'New Link';
            }
            if (field === 'icon' && iconElement) {
                iconElement.className = `fas fa-${value || 'link'} text-${navigationLinks[index].category === 'server' ? 'green' : 'blue'}-400`;
            }
            if (field === 'category') {
                // Update the entire element with new category color
                const newIndex = navigationLinks.findIndex(l => l.id === navigationLinks[index].id);
                const newElement = createNavLinkElement(navigationLinks[index], newIndex, value);
                linkElement.parentNode.replaceChild(newElement, linkElement);
            }
        }
        
        updateNavigationLinksHiddenField();
    }
}

function addNavLink() {
    const newLink = {
        id: 'nav-' + Date.now(),
        type: 'link',
        name: 'New Navigation Link',
        icon: 'link',
        link: '/',
        target: '_self',
        enabled: true,
        order: navigationLinks.length,
        category: 'main',
        requires_root: false
    };
    
    navigationLinks.push(newLink);
    renderNavigationLinks();
    
    // Focus the name input after a short delay
    setTimeout(() => {
        const newInputs = document.querySelectorAll('.nav-link-name');
        if (newInputs.length > 0) {
            newInputs[newInputs.length - 1].focus();
        }
    }, 100);
    
    showNavNotification('New navigation link added!');
}

function addNavCategory() {
    const categoryName = prompt('Enter category name:');
    if (!categoryName) return;
    
    const newLink = {
        id: 'cat-' + Date.now(),
        type: 'link',
        name: categoryName.charAt(0).toUpperCase() + categoryName.slice(1),
        icon: 'folder',
        link: '#',
        target: '_self',
        enabled: true,
        order: navigationLinks.length,
        category: categoryName.toLowerCase(),
        requires_root: false
    };
    
    navigationLinks.push(newLink);
    renderNavigationLinks();
    showNavNotification(`"${categoryName}" category added!`);
}

function removeNavLink(index) {
    if (navigationLinks[index]) {
        const linkName = navigationLinks[index].name || 'Unnamed Link';
        if (confirm(`Remove "${linkName}"?`)) {
            navigationLinks.splice(index, 1);
            // Reorder remaining links
            navigationLinks.forEach((link, idx) => {
                link.order = idx;
            });
            renderNavigationLinks();
            showNavNotification('Navigation link removed');
        }
    }
}

function removeCategory(category) {
    const categoryLinks = navigationLinks.filter(link => link.category === category);
    if (categoryLinks.length > 0) {
        if (confirm(`Remove "${category}" category and all ${categoryLinks.length} links within it?`)) {
            navigationLinks = navigationLinks.filter(link => link.category !== category);
            // Reorder remaining links
            navigationLinks.forEach((link, idx) => {
                link.order = idx;
            });
            renderNavigationLinks();
            showNavNotification(`"${category}" category removed`);
        }
    }
}

function toggleNavLinkEnabled(index) {
    navigationLinks[index].enabled = !navigationLinks[index].enabled;
    renderNavigationLinks();
    showNavNotification(`Link ${navigationLinks[index].enabled ? 'enabled' : 'disabled'}`);
}

function moveNavLinkUp(index) {
    if (index <= 0) return;
    
    // Swap the links
    const temp = navigationLinks[index];
    navigationLinks[index] = navigationLinks[index - 1];
    navigationLinks[index - 1] = temp;
    
    // Update orders
    navigationLinks.forEach((link, idx) => {
        link.order = idx;
    });
    
    renderNavigationLinks();
    showNavNotification('Link moved up');
}

function moveNavLinkDown(index) {
    if (index >= navigationLinks.length - 1) return;
    
    // Swap the links
    const temp = navigationLinks[index];
    navigationLinks[index] = navigationLinks[index + 1];
    navigationLinks[index + 1] = temp;
    
    // Update orders
    navigationLinks.forEach((link, idx) => {
        link.order = idx;
    });
    
    renderNavigationLinks();
    showNavNotification('Link moved down');
}

// ---- Drag and Drop Functions ----
function startNavLinkDrag(e, index) {
    dragSourceIndex = index;
    isDragging = true;
    
    const item = e.target.closest('.nav-link-item');
    if (item) {
        item.style.opacity = '0.6';
        item.style.cursor = 'grabbing';
        item.classList.add('dragging');
    }
    
    document.addEventListener('mousemove', handleNavLinkDragMove);
    document.addEventListener('mouseup', stopNavLinkDrag);
    e.preventDefault();
}

function handleNavLinkDragMove(e) {
    if (!isDragging) return;
    
    // Visual feedback during drag
    const draggingElement = document.querySelector('.nav-link-item.dragging');
    if (draggingElement) {
        draggingElement.style.transform = 'rotate(2deg)';
    }
}

function stopNavLinkDrag(e) {
    if (!isDragging) return;
    
    document.removeEventListener('mousemove', handleNavLinkDragMove);
    document.removeEventListener('mouseup', stopNavLinkDrag);
    
    const items = document.querySelectorAll('.nav-link-item');
    items.forEach(item => {
        item.style.opacity = '1';
        item.style.cursor = 'default';
        item.style.transform = 'none';
        item.classList.remove('dragging');
    });
    
    if (dragSourceIndex === null) return;
    
    // Find the drop target
    const dragEndIndex = Array.from(items).findIndex(item => {
        const rect = item.getBoundingClientRect();
        return e.clientY >= rect.top && e.clientY <= rect.bottom;
    });
    
    if (dragEndIndex !== -1 && dragEndIndex !== dragSourceIndex) {
        // Move the item in the array
        const [movedItem] = navigationLinks.splice(dragSourceIndex, 1);
        navigationLinks.splice(dragEndIndex, 0, movedItem);
        
        // Update orders
        navigationLinks.forEach((link, idx) => {
            link.order = idx;
        });
        
        renderNavigationLinks();
        showNavNotification('Link position updated');
    }
    
    dragSourceIndex = null;
    isDragging = false;
}

function startCategoryDrag(e, category) {
    // For category dragging, we'll move all links in that category
    const categoryLinks = navigationLinks.filter(link => link.category === category);
    if (categoryLinks.length === 0) return;
    
    // Implementation for category dragging would be more complex
    // For now, we'll show a message that category dragging is coming soon
    showNavNotification('Category drag & drop coming soon!');
}

function updateNavigationLinksHiddenField() {
    const input = document.getElementById('navigation_links_input');
    if (input) {
        input.value = JSON.stringify(navigationLinks);
    }
}

function resetNavLinks() {
    if (confirm('Are you sure you want to reset all navigation links to default? This cannot be undone.')) {
        // Default navigation links structure (same as before)
        navigationLinks = [
            {
                id: 'dashboard',
                type: 'link',
                name: 'Dashboard',
                icon: 'home',
                link: '/',
                target: '_self',
                enabled: true,
                order: 0,
                category: 'main'
            },
            {
                id: 'admin',
                type: 'link',
                name: 'Admin',
                icon: 'cogs',
                link: '/admin',
                target: '_self',
                enabled: true,
                order: 1,
                category: 'main',
                requires_root: true
            },
            // ... include all your default navigation links
        ];
        renderNavigationLinks();
        showNavNotification('Navigation links reset to default');
    }
}

function saveNavigationLinks() {
    updateNavigationLinksHiddenField();
    
    // Show saving indicator
    const saveBtn = document.querySelector('#navigationLinksForm button[type="submit"]');
    const originalText = saveBtn.innerHTML;
    saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Saving...';
    saveBtn.disabled = true;
    
    setTimeout(() => {
        document.getElementById('navigationLinksForm').submit();
    }, 500);
}

function showNavNotification(message) {
    // Create a subtle notification
    const notification = document.createElement('div');
    notification.className = 'fixed bottom-4 right-4 bg-gray-800 border-l-4 border-purple-500 text-white px-4 py-2 rounded-lg shadow-lg z-50 transform translate-x-full transition-transform duration-300';
    notification.innerHTML = `
        <div class="flex items-center space-x-2">
            <i class="fas fa-check-circle text-purple-400"></i>
            <span class="text-sm">${message}</span>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 10);
    
    // Animate out and remove
    setTimeout(() => {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 2000);
}

// Initialize navigation links when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Navigation links wiring
    const btnAddNavLink = document.getElementById('btnAddNavLink');
    if (btnAddNavLink) btnAddNavLink.addEventListener('click', addNavLink);

    const btnAddNavCategory = document.getElementById('btnAddNavCategory');
    if (btnAddNavCategory) btnAddNavCategory.addEventListener('click', addNavCategory);

    const btnResetNavLinks = document.getElementById('btnResetNavLinks');
    if (btnResetNavLinks) btnResetNavLinks.addEventListener('click', resetNavLinks);

    const btnPreviewNavChanges = document.getElementById('btnPreviewNavChanges');
    if (btnPreviewNavChanges) btnPreviewNavChanges.addEventListener('click', function() {
        switchTab('panel-preview');
    });

    // Initialize navigation links
    if (Array.isArray(@json($navigation_links ?? []))) {
        navigationLinks = @json($navigation_links ?? []);
    }
    renderNavigationLinks();
});

// ---- Quick Links Functions ----
let quickLinks = @json($quick_links ?? []);
let quickLinksEnabled = @json($quick_links_enabled ?? true);

function renderQuickLinks() {
    const list = document.getElementById('quickLinksList');
    const emptyState = document.getElementById('quickLinksEmpty');
    
    if (!list) return;
    
    list.innerHTML = '';
    
    if (!quickLinks || quickLinks.length === 0) {
        if (emptyState) emptyState.classList.remove('hidden');
        list.classList.add('hidden');
        updateQuickLinksHiddenField();
        return;
    }
    
    if (emptyState) emptyState.classList.add('hidden');
    list.classList.remove('hidden');
    
    quickLinks.forEach((link, index) => {
        const linkElement = document.createElement('div');
        linkElement.className = 'quick-link-item bg-gray-800/50 border border-gray-700 rounded-lg p-4 transition-all duration-200 hover:border-gray-600';
        linkElement.innerHTML = `
            <div class="flex items-start space-x-4">
                {{-- Drag Handle --}}
                <div class="drag-handle cursor-move pt-3 text-gray-500 hover:text-gray-300 transition-colors">
                    <i class="fas fa-grip-vertical"></i>
                </div>
                
                {{-- Icon Preview --}}
                <div class="flex-shrink-0">
                    <div class="w-10 h-10 rounded-lg bg-gray-700 flex items-center justify-center">
                        <i class="fas fa-${link.icon || 'link'} text-primary-400"></i>
                    </div>
                </div>
                
                {{-- Form Fields --}}
                <div class="flex-1 grid grid-cols-1 md:grid-cols-2 gap-3">
                    {{-- Title --}}
                    <div>
                        <label class="block text-xs font-medium text-gray-400 mb-1">Title</label>
                        <input type="text" 
                               value="${link.title || ''}" 
                               placeholder="Link title..."
                               class="w-full px-3 py-2 text-sm bg-gray-900 border border-gray-600 rounded focus:border-primary-500 focus:ring-1 focus:ring-primary-500 transition-colors quick-link-title"
                               oninput="updateQuickLinkField(${index}, 'title', this.value)">
                    </div>
                    
                    {{-- URL --}}
                    <div>
                        <label class="block text-xs font-medium text-gray-400 mb-1">URL</label>
                        <input type="url" 
                               value="${link.url || ''}" 
                               placeholder="https://example.com"
                               class="w-full px-3 py-2 text-sm bg-gray-900 border border-gray-600 rounded focus:border-primary-500 focus:ring-1 focus:ring-primary-500 transition-colors quick-link-url"
                               oninput="updateQuickLinkField(${index}, 'url', this.value)">
                    </div>
                    
                    {{-- Icon --}}
                    <div>
                        <label class="block text-xs font-medium text-gray-400 mb-1">Icon</label>
                        <div class="flex space-x-2">
                            <input type="text" 
                                   value="${link.icon || ''}" 
                                   placeholder="link, discord, github..."
                                   class="flex-1 px-3 py-2 text-sm bg-gray-900 border border-gray-600 rounded focus:border-primary-500 focus:ring-1 focus:ring-primary-500 transition-colors quick-link-icon"
                                   oninput="updateQuickLinkField(${index}, 'icon', this.value)">
                        </div>
                    </div>
                    
                    {{-- Target --}}
                    <div>
                        <label class="block text-xs font-medium text-gray-400 mb-1">Target</label>
                        <select class="w-full px-3 py-2 text-sm bg-gray-900 border border-gray-600 rounded focus:border-primary-500 focus:ring-1 focus:ring-primary-500 transition-colors quick-link-target"
                                onchange="updateQuickLinkField(${index}, 'target', this.value)">
                            <option value="_self" ${link.target === '_self' ? 'selected' : ''}>Same Tab</option>
                            <option value="_blank" ${link.target === '_blank' ? 'selected' : ''}>New Tab</option>
                        </select>
                    </div>
                </div>
                
                {{-- Actions --}}
                <div class="flex flex-col space-y-2 pt-1">
                    <button type="button" 
                            onclick="moveQuickLinkUp(${index})" 
                            class="p-2 text-gray-400 hover:text-white transition-colors ${index === 0 ? 'opacity-30 cursor-not-allowed' : ''}"
                            ${index === 0 ? 'disabled' : ''}>
                        <i class="fas fa-chevron-up"></i>
                    </button>
                    <button type="button" 
                            onclick="moveQuickLinkDown(${index})" 
                            class="p-2 text-gray-400 hover:text-white transition-colors ${index === quickLinks.length - 1 ? 'opacity-30 cursor-not-allowed' : ''}"
                            ${index === quickLinks.length - 1 ? 'disabled' : ''}>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    <button type="button" 
                            onclick="removeQuickLink(${index})" 
                            class="p-2 text-red-400 hover:text-red-300 transition-colors">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
            
            {{-- Live Preview --}}
            <div class="mt-3 pt-3 border-t border-gray-700">
                <div class="flex items-center justify-between">
                    <span class="text-xs text-gray-400">Live Preview:</span>
                    <div class="flex items-center space-x-2 px-3 py-1 bg-gray-900 rounded-lg">
                        <i class="fas fa-${link.icon || 'link'} text-primary-400 text-sm"></i>
                        <span class="text-sm text-gray-300">${link.title || 'New Link'}</span>
                    </div>
                </div>
            </div>
        `;
        
        list.appendChild(linkElement);
    });
    
    updateQuickLinksHiddenField();
}

function updateQuickLinkField(index, field, value) {
    if (quickLinks[index]) {
        quickLinks[index][field] = value;
        updateQuickLinksHiddenField();
    }
}

function addQuickLink() {
    const newLink = {
        title: 'New Quick Link',
        url: 'https://example.com',
        icon: 'link',
        target: '_self'
    };
    
    quickLinks.push(newLink);
    renderQuickLinks();
    
    setTimeout(() => {
        const newInputs = document.querySelectorAll('.quick-link-title');
        if (newInputs.length > 0) {
            newInputs[newInputs.length - 1].focus();
        }
    }, 100);
    
    showQuickNotification('New quick link added! Start editing...');
}

function removeQuickLink(index) {
    if (quickLinks[index]) {
        const linkTitle = quickLinks[index].title || 'Untitled Link';
        if (confirm(`Remove "${linkTitle}"?`)) {
            quickLinks.splice(index, 1);
            renderQuickLinks();
            showQuickNotification('Quick link removed');
        }
    }
}

function moveQuickLinkUp(index) {
    if (index <= 0) return;
    
    const temp = quickLinks[index];
    quickLinks[index] = quickLinks[index - 1];
    quickLinks[index - 1] = temp;
    
    renderQuickLinks();
    showQuickNotification('Link moved up');
}

function moveQuickLinkDown(index) {
    if (index >= quickLinks.length - 1) return;
    
    const temp = quickLinks[index];
    quickLinks[index] = quickLinks[index + 1];
    quickLinks[index + 1] = temp;
    
    renderQuickLinks();
    showQuickNotification('Link moved down');
}

function updateQuickLinksHiddenField() {
    const input = document.getElementById('quick_links_input');
    if (input) {
        // Clean the data before saving - remove empty links
        const cleanedLinks = quickLinks.filter(link => 
            link && link.title && link.title.trim() && link.url && link.url.trim()
        );
        
        input.value = JSON.stringify(cleanedLinks);
    }
}

function showQuickNotification(message) {
    const notification = document.createElement('div');
    notification.className = 'fixed bottom-4 right-4 bg-gray-800 border-l-4 border-primary-500 text-white px-4 py-2 rounded-lg shadow-lg z-50 transform translate-x-full transition-transform duration-300';
    notification.innerHTML = `
        <div class="flex items-center space-x-2">
            <i class="fas fa-check-circle text-primary-400"></i>
            <span class="text-sm">${message}</span>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 10);
    
    setTimeout(() => {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 2000);
}

// Initialize quick links when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Quick links wiring
    const btnAddQuickLink = document.getElementById('btnAddQuickLink');
    if (btnAddQuickLink) btnAddQuickLink.addEventListener('click', addQuickLink);

    // Initialize quick links
    if (Array.isArray(@json($quick_links ?? []))) {
        quickLinks = @json($quick_links ?? []);
    }
    renderQuickLinks();
});

function updateNavigationLinksHiddenField() {
    const input = document.getElementById('navigation_links_input');
    if (input) {
        input.value = JSON.stringify(navigationLinks);
    }
}

function saveNavigationLinks() {
    updateNavigationLinksHiddenField();
    document.getElementById('navigationLinksForm').submit();
}

// ---- Loading Screen ----
function hideLoadingScreen() {
    const loadingScreen = document.getElementById('loadingScreen');
    if (loadingScreen) {
        loadingScreen.style.opacity = '0';
        setTimeout(() => {
            loadingScreen.style.display = 'none';
        }, 500);
    }
}

// ---- Nest Background Functions ----
function updateGradientOpacityValue(value) {
    const valueElement = document.getElementById('gradientOpacityValue');
    if (valueElement) {
        valueElement.textContent = Math.round(value * 100) + '%';
    }
}

function clearNestBackground(nestId) {
    const urlInput = document.querySelector(`input[name="nest_backgrounds[${nestId}]"]`);
    const fileInput = document.getElementById(`nestBackgroundFile${nestId}`);
    
    if (urlInput) urlInput.value = '';
    if (fileInput) fileInput.value = '';
    
    // Show confirmation message
    alert('Nest background cleared. Remember to save changes.');
}

// ---- Fix: Enhanced clearLogo function ----
function clearLogo(which) {
    // Default logo URLs
    const defaultLogos = {
        small: 'https://i.ibb.co/VWPqZtZ6/image-2.png',
        large: 'https://img.imgdd.com/2c676b89-56af-40f7-9f8c-35f433c2dcb9.png'
    };

    // Clear the file input
    const fileInput = document.getElementById(which + 'LogoFile');
    if (fileInput) fileInput.value = '';
    
    // Set the URL input to the default value
    const urlInput = document.getElementById(which + '_logo_url');
    if (urlInput) {
        urlInput.value = defaultLogos[which];
        // Also trigger the input event to update the preview
        urlInput.dispatchEvent(new Event('input'));
    }
    
    // Update the logo preview with the default image
    const preview = document.getElementById(which + 'LogoPreview');
    const previewContainer = preview ? preview.parentElement : null;
    
    if (preview) {
        preview.src = defaultLogos[which];
        preview.style.display = 'block';
        
        // Hide the placeholder if it exists
        const placeholder = previewContainer ? previewContainer.querySelector('.text-center') : null;
        if (placeholder) {
            placeholder.style.display = 'none';
        }
    }
    
    // Show confirmation
    showQuickNotification(`${which === 'small' ? 'Small' : 'Large'} logo reset to default!`);
}

// ---- preview functions (background) ----
function updatePreview(url) {
    const preview = document.getElementById('livePreview');
    if (!preview) return;
    if (url) {
        preview.style.backgroundImage = `url('${url}')`;
        const p = document.getElementById('previewUrl');
        if (p) p.textContent = url.length > 50 ? url.substring(0,50) + '...' : url;
    }
}

function previewImage(input) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const lp = document.getElementById('livePreview');
            if (lp) lp.style.backgroundImage = `url('${e.target.result}')`;
            const p = document.getElementById('previewUrl');
            if (p) p.textContent = 'Local file: ' + input.files[0].name;
        }
        reader.readAsDataURL(input.files[0]);
    }
}

// ---- logo preview helpers ----
function previewLogo(input, which) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const el = document.getElementById(which === 'small' ? 'smallLogoPreview' : 'largeLogoPreview');
            if (el) {
                el.src = e.target.result;
                el.style.display = 'block';
            }
        }
        reader.readAsDataURL(input.files[0]);
    }
}

function updateLogoPreview(which, url) {
    const el = document.getElementById(which === 'small' ? 'smallLogoPreview' : 'largeLogoPreview');
    if (!el) return;
    if (url && url.length) {
        el.src = url;
        el.style.display = 'block';
    } else {
        el.style.display = 'none';
    }
}

// ---- panel preview helpers ----
let currentScale = 1;

function resetToDefault() {
    const bgUrl = document.getElementById('backgroundUrl');
    const bgFile = document.getElementById('backgroundFile');
    const lp = document.getElementById('livePreview');
    const p = document.getElementById('previewUrl');
    if (bgUrl) bgUrl.value = '';
    if (bgFile) bgFile.value = '';
    if (lp) lp.style.backgroundImage = '';
    if (p) p.textContent = 'Using default background';
}

function refreshPanelPreview() {
    const frame = document.getElementById('panelPreviewFrame');
    const loading = document.getElementById('frameLoading');
    if (frame && loading) {
        loading.classList.remove('hidden');
        frame.src = frame.src + (frame.src.includes('?') ? '&' : '?') + 't=' + new Date().getTime();
    }
}

function frameLoaded() {
    const loading = document.getElementById('frameLoading');
    if (loading) loading.classList.add('hidden');
}

function setPreviewScale(scale) {
    currentScale = scale;
    const frame = document.getElementById('panelPreviewFrame');
    if (frame) frame.style.transform = `scale(${scale})`;
    const dims = document.getElementById('frameDimensions');
    if (dims) dims.textContent = `Scale: ${scale * 100}%`;
}

function fitToScreen() {
    const container = document.querySelector('#panelPreviewFrame')?.parentElement;
    const frame = document.getElementById('panelPreviewFrame');
    if (!container || !frame) return;
    const containerWidth = container.clientWidth;
    const frameWidth = frame.scrollWidth || frame.clientWidth;
    const scale = Math.min(1, containerWidth / frameWidth * 0.95);
    setPreviewScale(scale);
}

function openPanelInNewTab() {
    const frame = document.getElementById('panelPreviewFrame');
    if (frame) window.open(frame.src, '_blank');
}

// ---- tabs + event wiring ----
function switchTab(tabName) {
    // Update URL parameter without page reload
    const url = new URL(window.location);
    url.searchParams.set('tab', tabName);
    window.history.replaceState({}, '', url);
    
    // Update tab buttons
    document.querySelectorAll('[data-tab]').forEach(tab => {
        if (tab.getAttribute('data-tab') === tabName) {
            tab.classList.add('tab-active', 'text-white');
            tab.classList.remove('text-gray-400');
        } else {
            tab.classList.remove('tab-active', 'text-white');
            tab.classList.add('text-gray-400');
        }
    });
    
    // Update tab content
    document.querySelectorAll('.tab-content').forEach(content => {
        if (content.id === tabName + '-tab') {
            content.classList.remove('hidden');
        } else {
            content.classList.add('hidden');
        }
    });
    
    // Handle special tab behaviors
    if (tabName === 'background') {
        const sp = document.getElementById('simplePreview');
        if (sp) sp.classList.remove('hidden');
    } else {
        const sp = document.getElementById('simplePreview');
        if (sp) sp.classList.add('hidden');
        if (tabName === 'panel-preview') {
            refreshPanelPreview();
        }
    }
}

document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded, initializing theme settings');
    
    // Hide loading screen after a short delay
    setTimeout(hideLoadingScreen, 800);
    
    // Initialize with the correct tab from URL
    switchTab(activeTabParam);
    
    // Initialize navigation links
    if (Array.isArray(initialNavigationLinks) && initialNavigationLinks.length) {
        navigationLinks = initialNavigationLinks.slice();
    }
    renderNavigationLinks();

    // Initialize gradient opacity
    updateGradientOpacityValue(@json($nest_gradient_opacity ?? 0.15));

    // Navigation links wiring
    const btnAddNavLink = document.getElementById('btnAddNavLink');
    if (btnAddNavLink) btnAddNavLink.addEventListener('click', addNavLink);

    const btnAddNavCategory = document.getElementById('btnAddNavCategory');
    if (btnAddNavCategory) btnAddNavCategory.addEventListener('click', addNavCategory);

    const btnResetNavLinks = document.getElementById('btnResetNavLinks');
    if (btnResetNavLinks) btnResetNavLinks.addEventListener('click', resetNavLinks);

    const btnPreviewNavChanges = document.getElementById('btnPreviewNavChanges');
    if (btnPreviewNavChanges) btnPreviewNavChanges.addEventListener('click', function() {
        switchTab('panel-preview');
    });
	
    // Choose file button
    const btnChooseBackground = document.getElementById('btnChooseBackground');
    const backgroundFile = document.getElementById('backgroundFile');
    if (btnChooseBackground && backgroundFile) {
        btnChooseBackground.addEventListener('click', function() { backgroundFile.click(); });
    }

    // Upload logo buttons
    const btnUploadSmallLogo = document.getElementById('btnUploadSmallLogo');
    const smallFile = document.getElementById('smallLogoFile');
    if (btnUploadSmallLogo && smallFile) btnUploadSmallLogo.addEventListener('click', () => smallFile.click());

    const btnUploadLargeLogo = document.getElementById('btnUploadLargeLogo');
    const largeFile = document.getElementById('largeLogoFile');
    if (btnUploadLargeLogo && largeFile) btnUploadLargeLogo.addEventListener('click', () => largeFile.click());

    // Preview button
    const btnPreview = document.getElementById('btnPreviewChanges');
    if (btnPreview) btnPreview.addEventListener('click', function() {
        const val = document.getElementById('backgroundUrl') ? document.getElementById('backgroundUrl').value : '';
        if (val) updatePreview(val);
    });

    // Nest preview button
    const btnPreviewNest = document.getElementById('btnPreviewNestChanges');
    if (btnPreviewNest) btnPreviewNest.addEventListener('click', function() {
        // Switch to panel preview tab to see the changes
        switchTab('panel-preview');
    });

    // Tab handlers
    document.querySelectorAll('[data-tab]').forEach(tab => {
        tab.addEventListener('click', function() {
            const tabName = this.getAttribute('data-tab');
            switchTab(tabName);
        });
    });

    // Panel preview controls
    const btnRefresh = document.getElementById('btnRefreshPreview2');
    if (btnRefresh) btnRefresh.addEventListener('click', refreshPanelPreview);

    const btnOpen = document.getElementById('btnOpenNewTab2');
    if (btnOpen) btnOpen.addEventListener('click', openPanelInNewTab);

    // Panel preview small controls
    const btnFit = document.getElementById('btnFitToScreen');
    if (btnFit) btnFit.addEventListener('click', fitToScreen);

    // scale buttons in panel-preview
    document.querySelectorAll('#panel-preview-tab [data-scale]').forEach(btn => {
        btn.addEventListener('click', function() {
            const s = parseFloat(this.getAttribute('data-scale'));
            setPreviewScale(s);
        });
    });

    // Initialize preview scale and initial previews
    setPreviewScale(1);

    if (initialBackground) {
        const lp = document.getElementById('livePreview');
        if (lp) {
            lp.style.backgroundImage = `url('${initialBackground}')`;
            const p = document.getElementById('previewUrl');
            if (p) p.textContent = initialBackground.length > 50 ? initialBackground.substring(0,50) + '...' : initialBackground;
        }
    }
});
</script>
@endsection