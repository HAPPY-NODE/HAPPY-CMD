<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>{{ config('app.name', 'Pterodactyl') }} - @yield('title')</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="_token" content="{{ csrf_token() }}">

    {{-- Favicons --}}
    <link rel="apple-touch-icon" sizes="180x180" href="/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" href="/favicons/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="/favicons/favicon-16x16.png" sizes="16x16">
    <link rel="manifest" href="/favicons/manifest.json">
    <link rel="mask-icon" href="/favicons/safari-pinned-tab.svg" color="#bc6e3c">
    <link rel="shortcut icon" href="/favicons/favicon.ico">
    <meta name="msapplication-config" content="/favicons/browserconfig.xml">
    <meta name="theme-color" content="#0e4688">

    {{-- TailwindCSS with custom config --}}
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: {
                            50: '#f0f9ff',
                            100: '#e0f2fe',
                            500: '#0ea5e9',
                            600: '#0284c7',
                            700: '#0369a1',
                            900: '#0c4a6e',
                        }
                    },
                    animation: {
                        'fade-in': 'fadeIn 0.5s ease-in-out',
                        'slide-down': 'slideDown 0.3s ease-out',
                        'pulse-slow': 'pulse 3s infinite',
                        'bounce-in': 'bounceIn 0.6s ease-out',
                        'float': 'float 3s ease-in-out infinite',
                        'gradient-shift': 'gradientShift 3s ease infinite',
                        'particle-float': 'particleFloat 6s ease-in-out infinite',
                    }
                }
            }
        }
    </script>

    {{-- Font Awesome Icons --}}
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    {{-- Custom Styles --}}
    <style>
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        @keyframes bounceIn {
            0% { opacity: 0; transform: scale(0.3); }
            50% { opacity: 1; transform: scale(1.05); }
            70% { transform: scale(0.9); }
            100% { opacity: 1; transform: scale(1); }
        }

        /* New Loading Screen Animations */
        @keyframes float {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            50% { transform: translateY(-20px) rotate(5deg); }
        }

        @keyframes gradientShift {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        @keyframes particleFloat {
            0% { transform: translateY(0px) translateX(0px) rotate(0deg); opacity: 0; }
            10% { opacity: 1; }
            90% { opacity: 1; }
            100% { transform: translateY(-100px) translateX(20px) rotate(180deg); opacity: 0; }
        }

        @keyframes orbit {
            0% { transform: rotate(0deg) translateX(40px) rotate(0deg); }
            100% { transform: rotate(360deg) translateX(40px) rotate(-360deg); }
        }

        @keyframes pulseGlow {
            0%, 100% { box-shadow: 0 0 20px rgba(14, 165, 233, 0.4); }
            50% { box-shadow: 0 0 40px rgba(14, 165, 233, 0.8), 0 0 60px rgba(139, 92, 246, 0.4); }
        }

        @keyframes textShine {
            0% { background-position: -200% center; }
            100% { background-position: 200% center; }
        }

        @keyframes dash {
            0% { stroke-dashoffset: 1000; }
            100% { stroke-dashoffset: 0; }
        }

/* Enhanced Animations */
@keyframes gradient-x {
    0%, 100% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
}

.animate-gradient-x {
    background-size: 200% 200%;
    animation: gradient-x 3s ease infinite;
}

/* Enhanced Glass Effect */
.glass-effect {
    background: rgba(255, 255, 255, 0.03);
    backdrop-filter: blur(20px);
    border: 1px solid rgba(255, 255, 255, 0.08);
}

/* Gradient Border Enhancement */
.gradient-border {
    background: #000000;
    padding: 2px;
    border-radius: 1rem;
    transition: all 0.3s ease;
}

.gradient-border-hover {
    background: linear-gradient(45deg, rgba(59, 130, 246, 0.5), rgba(168, 85, 247, 0.5), rgba(6, 182, 212, 0.5));
    box-shadow: 0 0 30px rgba(59, 130, 246, 0.2);
}

/* Settings Card Enhancements */
.settings-card {
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    position: relative;
    overflow: hidden;
}

.settings-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.05), transparent);
    transition: left 0.6s;
}

.settings-card:hover::before {
    left: 100%;
}

.settings-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.4);
}

/* Tab Enhancements */
.tab-button {
    background: transparent;
    border: none;
    position: relative;
    overflow: hidden;
}

.tab-button::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.1), transparent);
    transition: left 0.6s;
}

.tab-button:hover::before {
    left: 100%;
}

.tab-button.active {
    background: #3b82f633;
    backdrop-filter: blur(10px);
}

/* Input Enhancements */
input, select, textarea {
    transition: all 0.3s ease;
}

input:focus, select:focus, textarea:focus {
    transform: translateY(-1px);
    box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.3);
}

/* Custom Scrollbar */
::-webkit-scrollbar {
    width: 8px;
}

::-webkit-scrollbar-track {
    background: rgb(28 41 70);
}

::-webkit-scrollbar-thumb {
    background: #0ea5e9;
    border-radius: 6px;
}

::-webkit-scrollbar-thumb:hover {
    background: #0284c7;;
}

/* Pulse Animation for Interactive Elements */
@keyframes pulse-glow {
    0%, 100% { box-shadow: 0 0 5px rgba(59, 130, 246, 0.4); }
    50% { box-shadow: 0 0 20px rgba(59, 130, 246, 0.8); }
}

.pulse-glow {
    animation: pulse-glow 2s ease-in-out infinite;
}

/* Smooth transitions for all interactive elements */
button, a, input, select {
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

/* Enhanced file upload area */
.border-dashed:hover {
    border-style: solid;
    transform: scale(1.02);
}

/* Status indicators */
.status-indicator {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    display: inline-block;
    margin-right: 8px;
}

.status-online { background: #10B981; }
.status-offline { background: #EF4444; }
.status-loading { background: #F59E0B; }

        input[type="range"] {
            -webkit-appearance: none;
            height: 6px;
            border-radius: 3px;
            background: #374151;
            outline: none;
        }

        input[type="range"]::-webkit-slider-thumb {
            -webkit-appearance: none;
            width: 18px;
            height: 18px;
            border-radius: 50%;
            background: #0ea5e9;
            cursor: pointer;
            transition: all 0.2s;
        }

        input[type="range"]::-webkit-slider-thumb:hover {
            background: #0284c7;
            transform: scale(1.1);
        }
        
        /* New Sleek Loading Screen Styles */
        #loadingScreen {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(-45deg, #0c0f1d, #1a1f3a, #0f172a, #1e293b);
            background-size: 400% 400%;
            animation: gradientShift 8s ease infinite;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 9999;
            transition: opacity 0.8s cubic-bezier(0.4, 0, 0.2, 1);
            overflow: hidden;
        }

        .loading-container {
            text-align: center;
            position: relative;
            z-index: 10;
        }

        .logo-container {
            position: relative;
            width: 120px;
            height: 120px;
            margin: 0 auto 2rem;
        }

        .logo-main {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #0ea5e9, #8b5cf6);
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto;
            animation: float 3s ease-in-out infinite, pulseGlow 2s ease-in-out infinite;
            position: relative;
            z-index: 2;
        }

        .logo-main i {
            font-size: 2.5rem;
            color: white;
        }

        .orbit-ring {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            border: 2px dashed rgba(14, 165, 233, 0.3);
            border-radius: 50%;
            animation: orbit 8s linear infinite;
        }

        .orbit-dot {
            position: absolute;
            top: 50%;
            left: 50%;
            width: 8px;
            height: 8px;
            background: #0ea5e9;
            border-radius: 50%;
            transform: translate(-50%, -50%);
        }

        .loading-title {
            font-size: 2.5rem;
            font-weight: 800;
            margin-bottom: 1rem;
            background: linear-gradient(90deg, #0ea5e9, #8b5cf6, #0ea5e9);
            background-size: 200% auto;
            background-clip: text;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: textShine 3s linear infinite;
        }

        .loading-subtitle {
            font-size: 1.1rem;
            color: #94a3b8;
            margin-bottom: 2rem;
            font-weight: 300;
        }

        .progress-container {
            width: 300px;
            height: 4px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            margin: 2rem auto;
            overflow: hidden;
        }

        .progress-bar {
            height: 100%;
            background: linear-gradient(90deg, #0ea5e9, #8b5cf6);
            border-radius: 10px;
            width: 0%;
            animation: loadingProgress 2s ease-in-out infinite;
            position: relative;
        }

        .progress-bar::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.4), transparent);
            animation: shimmer 1.5s ease-in-out infinite;
        }

        @keyframes loadingProgress {
            0% { width: 0%; }
            50% { width: 70%; }
            100% { width: 100%; }
        }

        @keyframes shimmer {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
        }

        .loading-stats {
            display: flex;
            justify-content: center;
            gap: 2rem;
            margin-top: 2rem;
            opacity: 0.8;
        }

        .stat-item {
            text-align: center;
        }

        .stat-number {
            font-size: 1.5rem;
            font-weight: 700;
            color: #0ea5e9;
        }

        .stat-label {
            font-size: 0.8rem;
            color: #94a3b8;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        /* Floating particles */
        .particle {
            position: absolute;
            width: 4px;
            height: 4px;
            background: rgba(14, 165, 233, 0.6);
            border-radius: 50%;
            animation: particleFloat 6s ease-in-out infinite;
        }

        .particle:nth-child(1) { left: 10%; animation-delay: 0s; }
        .particle:nth-child(2) { left: 20%; animation-delay: 1s; }
        .particle:nth-child(3) { left: 30%; animation-delay: 2s; }
        .particle:nth-child(4) { left: 40%; animation-delay: 3s; }
        .particle:nth-child(5) { left: 50%; animation-delay: 4s; }
        .particle:nth-child(6) { left: 60%; animation-delay: 5s; }
        .particle:nth-child(7) { left: 70%; animation-delay: 6s; }
        .particle:nth-child(8) { left: 80%; animation-delay: 7s; }
        .particle:nth-child(9) { left: 90%; animation-delay: 8s; }

        /* Responsive design */
        @media (max-width: 768px) {
            .loading-title {
                font-size: 2rem;
            }
            
            .logo-container {
                width: 100px;
                height: 100px;
            }
            
            .logo-main {
                width: 60px;
                height: 60px;
            }
            
            .logo-main i {
                font-size: 2rem;
            }
            
            .progress-container {
                width: 250px;
            }
        }

        /* Modal styles */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.7);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
        }
        
        .modal-overlay.active {
            opacity: 1;
            visibility: visible;
        }
        
        .modal-content {
            background: #1e293b;
            border-radius: 12px;
            padding: 0;
            width: 90%;
            max-width: 500px;
            transform: scale(0.7);
            transition: transform 0.3s ease;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
        }
        
        .modal-overlay.active .modal-content {
            transform: scale(1);
        }
        
        /* Improved navigation links styles */
        .nav-link-item {
            background: rgba(30, 41, 59, 0.5);
            border: 1px solid rgba(71, 85, 105, 0.3);
            border-radius: 0.5rem;
            transition: all 0.2s ease;
        }
        
        .nav-link-item:hover {
            background: rgba(30, 41, 59, 0.7);
            border-color: rgba(99, 102, 241, 0.3);
        }
        
        .nav-link-item.dragging {
            opacity: 0.5;
            transform: scale(0.98);
        }
        
        .nav-link-item.category-header {
            background: linear-gradient(135deg, rgba(99, 102, 241, 0.1), rgba(168, 85, 247, 0.1));
            border-color: rgba(99, 102, 241, 0.2);
        }
        
        .drag-handle {
            cursor: grab;
        }
        
        .drag-handle:active {
            cursor: grabbing;
        }
        
        /* Background image for the page */
        body {
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
        }
		
		body::before {
			content: '';
			position: fixed;
			top: 0;
			left: 0;
			right: 0;
			bottom: 0;
			background: linear-gradient(to bottom, 
				rgba(0, 0, 0, 0.3) 0%, 
				rgba(0, 0, 0, 0.5) 40%, 
				rgba(18, 21, 36, 0.95) 100%),
				url('{{ $background ?? 'https://images.unsplash.com/photo-1687392946859-cebb261f01f5?fm=jpg&q=60&w=3000' }}') no-repeat center center;
			background-size: cover;
			z-index: -1;
			filter: blur(6px);
			transform: scale(1.05);
		}
		
		/* Quick Links Styles */
		.quick-link-item {
			transition: all 0.3s ease;
		}

		.quick-link-item:hover {
			transform: translateY(-1px);
			box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
		}

		.drag-handle {
			transition: all 0.2s ease;
		}

		.drag-handle:hover {
			transform: scale(1.1);
		}

		/* Custom checkbox styling */
		input[type="checkbox"]:checked + div {
			background-color: #0ea5e9;
		}

		input[type="checkbox"]:checked + div > div {
			transform: translateX(100%);
		}
				
		/* Navigation Links Styles */
		.nav-link-item {
			transition: all 0.3s ease;
		}

		.nav-link-item:hover {
			transform: translateY(-1px);
			box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
		}

		.nav-link-item.dragging {
			opacity: 0.6;
			transform: rotate(2deg);
			cursor: grabbing !important;
		}

		.category-group {
			transition: all 0.3s ease;
		}

		.drag-handle {
			transition: all 0.2s ease;
		}

		.drag-handle:hover {
			transform: scale(1.1);
		}

		/* Category color indicators */
		.bg-blue-500 { background-color: #3b82f6; }
		.bg-green-500 { background-color: #10b981; }
		.bg-red-500 { background-color: #ef4444; }

		.text-blue-400 { color: #60a5fa; }
		.text-green-400 { color: #34d399; }
		.text-red-400 { color: #f87171; }

		.border-blue-500\/30 { border-color: rgba(59, 130, 246, 0.3); }
		.border-green-500\/30 { border-color: rgba(16, 185, 129, 0.3); }

		.focus\\:border-blue-500:focus { border-color: #3b82f6; }
		.focus\\:border-green-500:focus { border-color: #10b981; }

		.focus\\:ring-blue-500:focus { --tw-ring-color: rgba(59, 130, 246, 0.5); }
		.focus\\:ring-green-500:focus { --tw-ring-color: rgba(16, 185, 129, 0.5); }

		.text-blue-600 { color: #2563eb; }
		.text-green-600 { color: #059669; }
		.text-red-600 { color: #dc2626; }

		.bg-blue-500\\/20 { background-color: rgba(59, 130, 246, 0.2); }
		.bg-green-500\\/20 { background-color: rgba(16, 185, 129, 0.2); }
		.bg-red-500\\/20 { background-color: rgba(239, 68, 68, 0.2); }
    </style>

    @stack('head')
</head>
<body class="min-h-screen text-gray-100 font-sans">
    {{-- New Sleek Loading Screen --}}
    <div id="loadingScreen">
        <!-- Animated background particles -->
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        
        <div class="loading-container">
            <!-- Animated Logo -->
            <div class="logo-container">
                <div class="orbit-ring"></div>
                <div class="orbit-dot"></div>
                <div class="logo-main">
                    <i class="fas fa-palette"></i>
                </div>
            </div>
            
            <!-- Animated Title -->
            <h1 class="loading-title">Theme Customization</h1>
            <p class="loading-subtitle">Initializing your theme editor</p>
            
            <!-- Progress Bar -->
            <div class="progress-container">
                <div class="progress-bar"></div>
            </div>
            
            <!-- Loading Stats -->
            <div class="loading-stats">
                <div class="stat-item">
                    <div class="stat-number" id="loadedModules">0%</div>
                    <div class="stat-label">Modules</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number" id="loadedAssets">0%</div>
                    <div class="stat-label">Assets</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number" id="loadedUI">0%</div>
                    <div class="stat-label">Interface</div>
                </div>
            </div>
        </div>
    </div>

    @yield('content')

    {{-- Navigation Link Modal --}}
    <div id="navLinkModal" class="modal-overlay">
        <div class="modal-content">
            <div class="glass-effect rounded-t-xl p-4 border-b border-gray-700">
                <h3 class="text-lg font-semibold" id="modalTitle">Edit Navigation Link</h3>
            </div>
            <div class="p-6">
                <form id="navLinkForm">
                    <div class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium mb-2">Link Name</label>
                            <input type="text" id="linkName" class="w-full px-3 py-2 rounded-lg bg-gray-800 border border-gray-600 focus:border-primary-500 focus:ring-2 focus:ring-primary-500/20 transition-all" required>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium mb-2">Icon (FontAwesome name)</label>
                            <input type="text" id="linkIcon" class="w-full px-3 py-2 rounded-lg bg-gray-800 border border-gray-600 focus:border-primary-500 focus:ring-2 focus:ring-primary-500/20 transition-all" placeholder="home, user, cog, etc.">
                            <p class="text-xs text-gray-400 mt-1">Leave empty for default "link" icon</p>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium mb-2">URL</label>
                            <input type="text" id="linkUrl" class="w-full px-3 py-2 rounded-lg bg-gray-800 border border-gray-600 focus:border-primary-500 focus:ring-2 focus:ring-primary-500/20 transition-all" required>
                        </div>
                        
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium mb-2">Category</label>
                                <select id="linkCategory" class="w-full px-3 py-2 rounded-lg bg-gray-800 border border-gray-600 focus:border-primary-500 focus:ring-2 focus:ring-primary-500/20 transition-all">
                                    <option value="main">Main Navigation</option>
                                    <option value="server">Server Navigation</option>
                                </select>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium mb-2">Target</label>
                                <select id="linkTarget" class="w-full px-3 py-2 rounded-lg bg-gray-800 border border-gray-600 focus:border-primary-500 focus:ring-2 focus:ring-primary-500/20 transition-all">
                                    <option value="_self">Same Tab</option>
                                    <option value="_blank">New Tab</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="flex items-center justify-between">
                            <div class="flex items-center space-x-4">
                                <label class="flex items-center">
                                    <input type="checkbox" id="linkEnabled" class="rounded bg-gray-800 border-gray-600 text-primary-600 focus:ring-primary-500">
                                    <span class="ml-2 text-sm">Enabled</span>
                                </label>
                                
                                <label class="flex items-center">
                                    <input type="checkbox" id="linkRequiresRoot" class="rounded bg-gray-800 border-gray-600 text-primary-600 focus:ring-primary-500">
                                    <span class="ml-2 text-sm">Admin Only</span>
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <div class="flex justify-end space-x-3 mt-6">
                        <button type="button" id="cancelNavLink" class="px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded-lg transition-colors">Cancel</button>
                        <button type="submit" class="px-4 py-2 bg-primary-600 hover:bg-primary-500 rounded-lg transition-colors">Save Link</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    {{-- Global scripts --}}
    <script src="/js/keyboard.polyfill.js" type="application/javascript"></script>
    <script>keyboardeventKeyPolyfill.polyfill();</script>

    {{-- jQuery & other vendor libs --}}
    {!! Theme::js('vendor/jquery/jquery.min.js?t={cache-version}') !!}
    {!! Theme::js('vendor/sweetalert/sweetalert.min.js?t={cache-version}') !!}
    {!! Theme::js('vendor/bootstrap-notify/bootstrap-notify.min.js?t={cache-version}') !!}

    <script>
    // Enhanced loading screen functionality
    let loadingProgress = {
        modules: 0,
        assets: 0,
        ui: 0
    };

    function updateLoadingProgress() {
        // Simulate progressive loading
        const intervals = setInterval(() => {
            if (loadingProgress.modules < 100) {
                loadingProgress.modules = Math.min(loadingProgress.modules + Math.random() * 15, 100);
                loadingProgress.assets = Math.min(loadingProgress.assets + Math.random() * 12, 100);
                loadingProgress.ui = Math.min(loadingProgress.ui + Math.random() * 10, 100);
                
                document.getElementById('loadedModules').textContent = Math.round(loadingProgress.modules) + '%';
                document.getElementById('loadedAssets').textContent = Math.round(loadingProgress.assets) + '%';
                document.getElementById('loadedUI').textContent = Math.round(loadingProgress.ui) + '%';
                
                if (loadingProgress.modules === 100 && loadingProgress.assets === 100 && loadingProgress.ui === 100) {
                    clearInterval(intervals);
                    setTimeout(hideLoadingScreen, 500);
                }
            }
        }, 150);
    }

    function hideLoadingScreen() {
        const loadingScreen = document.getElementById('loadingScreen');
        if (loadingScreen) {
            loadingScreen.style.opacity = '0';
            setTimeout(() => {
                loadingScreen.style.display = 'none';
            }, 800);
        }
    }

    // Start loading progress when DOM is ready
    document.addEventListener('DOMContentLoaded', function() {
        setTimeout(updateLoadingProgress, 300);
        
        // Fallback in case something goes wrong
        setTimeout(hideLoadingScreen, 5000);
    });

    // Add a fun Easter egg - click on the logo to show a message
    document.addEventListener('DOMContentLoaded', function() {
        const logo = document.querySelector('.logo-main');
        if (logo) {
            logo.addEventListener('click', function() {
                const messages = [
                    "Looking good! 🎨",
                    "Theme master in the making! ✨",
                    "Customization level: Expert 🚀",
                    "Your panel will look amazing! 🌟"
                ];
                const randomMessage = messages[Math.floor(Math.random() * messages.length)];
                
                // Create a floating message
                const messageEl = document.createElement('div');
                messageEl.textContent = randomMessage;
                messageEl.style.position = 'fixed';
                messageEl.style.top = '50%';
                messageEl.style.left = '50%';
                messageEl.style.transform = 'translate(-50%, -50%)';
                messageEl.style.background = 'rgba(14, 165, 233, 0.9)';
                messageEl.style.color = 'white';
                messageEl.style.padding = '10px 20px';
                messageEl.style.borderRadius = '20px';
                messageEl.style.zIndex = '10000';
                messageEl.style.fontWeight = 'bold';
                messageEl.style.animation = 'fadeIn 0.3s, slideDown 0.3s';
                
                document.body.appendChild(messageEl);
                
                setTimeout(() => {
                    messageEl.style.opacity = '0';
                    messageEl.style.transform = 'translate(-50%, -60%)';
                    setTimeout(() => {
                        document.body.removeChild(messageEl);
                    }, 300);
                }, 2000);
            });
        }
    });
    </script>
	
<script>
// Enhanced tab switching with animations
function switchTab(tabName) {
    const url = new URL(window.location);
    url.searchParams.set('tab', tabName);
    window.history.replaceState({}, '', url);
	
    // Update tab buttons
    document.querySelectorAll('.tab-button').forEach(tab => {
        if (tab.getAttribute('data-tab') === tabName) {
            tab.classList.add('active');
        } else {
            tab.classList.remove('active');
        }
    });
    
    // Update tab content with fade animations
    document.querySelectorAll('.tab-content').forEach(content => {
        if (content.id === tabName + '-tab') {
            content.style.display = 'block';
            setTimeout(() => {
                content.style.opacity = '1';
                content.style.transform = 'translateY(0)';
            }, 50);
        } else {
            content.style.opacity = '0';
            content.style.transform = 'translateY(20px)';
            setTimeout(() => {
                content.style.display = 'none';
            }, 300);
        }
    });
}

// Initialize tabs with enhanced styling
document.addEventListener('DOMContentLoaded', function() {
    // Add initial styles for tab content
    document.querySelectorAll('.tab-content').forEach(content => {
        content.style.transition = 'all 0.3s ease';
    });
    
    // Add hover effects to all interactive elements
    document.querySelectorAll('button, a, input, select').forEach(element => {
        element.style.transition = 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)';
    });
});
</script>

    @stack('scripts')
</body>
</html>