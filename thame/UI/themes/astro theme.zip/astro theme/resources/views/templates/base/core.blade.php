@extends('templates/wrapper', [
    'css' => ['body' => 'text-neutral-100 font-sans'],
])

@section('container')
    <style>
        :root {
            --sidebar-width: 280px; /* Default sidebar width */
        }
        
        body {
            position: relative;
            min-height: 100vh;
            overflow-x: hidden;
            transition: margin-left 0.3s ease-in-out;
        }
        
        /* When sidebar is collapsed */
        body.sidebar-collapsed {
            --sidebar-width: 80px;
        }
        
        /* Apply the margin with transition */
        #app {
            margin-left: var(--sidebar-width);
            transition: margin-left 0.3s ease-in-out;
        }
        
        /* For mobile devices, don't apply the margin */
        @media (max-width: 768px) {
            #app {
                margin-left: 0 !important;
            }
        }
        
		body::before {
			content: '';
			position: fixed;
			top: 0;
			left: 0;
			right: 0;
			bottom: 0;
			background: linear-gradient(to bottom, 
				rgba(0, 0, 0, 0.3) 0%, 
				rgba(0, 0, 0, 0.5) 40%, 
				rgba(18, 21, 36, 0.95) 100%),
				url('{{ $theme_background }}') no-repeat center center;
			background-size: cover;
			z-index: -1;
			filter: blur(6px);
			transform: scale(1.05);
		}
        
        /* Optional: Add a subtle animation to the background */
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        body::before {
            animation: fadeIn 0.8s ease-in;
        }
        
        /* Ensure content stays above the background */
        #modal-portal,
        #app {
            position: relative;
            z-index: 1;
        }
    </style>

    <div id="modal-portal"></div>

    {{-- Main application content --}}
    <div id="app" class="px-4 pt-1">
        {{-- React content will be injected here --}}
    </div>

    <script>
        // Initialize sidebar state from localStorage
        document.addEventListener('DOMContentLoaded', function() {
            const isCollapsed = localStorage.getItem('sidebar-collapsed') === 'true';
            if (isCollapsed) {
                document.body.classList.add('sidebar-collapsed');
                document.documentElement.style.setProperty('--sidebar-width', '80px');
            } else {
                document.body.classList.remove('sidebar-collapsed');
                document.documentElement.style.setProperty('--sidebar-width', '280px');
            }
        });
    </script>
@endsection