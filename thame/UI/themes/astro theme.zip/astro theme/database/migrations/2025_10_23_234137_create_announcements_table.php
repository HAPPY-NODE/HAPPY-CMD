<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('announcements')) {
            Schema::create('announcements', function (Blueprint $table) {
                $table->id();
                $table->string('title');
                $table->text('content');
                $table->enum('type', ['info', 'warning', 'success', 'error', 'primary'])->default('info');
                $table->boolean('is_active')->default(true);
                $table->boolean('is_dismissible')->default(true);
                $table->timestamp('starts_at')->nullable();
                $table->timestamp('ends_at')->nullable();
                $table->json('target_nodes')->nullable();
                $table->json('target_users')->nullable();
                $table->enum('target_scope', ['all', 'nodes', 'users'])->default('all');
                $table->integer('display_order')->default(0);
                $table->unsignedBigInteger('created_by');
                $table->timestamps();
                
                $table->index(['is_active', 'starts_at', 'ends_at']);
                $table->index('display_order');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('announcements');
    }
};