<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMinecraftPluginsTable extends Migration
{
	public function up()
	{
		if (!Schema::hasTable('minecraft_plugins')) {
			Schema::create('minecraft_plugins', function (Blueprint $table) {
				$table->id();
				$table->unsignedBigInteger('server_id');
				$table->string('name');
				$table->string('plugin_id')->nullable();
				$table->string('version_id')->nullable();
				$table->string('file_name');
				$table->string('version')->default('Unknown');
				$table->text('description')->nullable();
				$table->text('download_url')->nullable();
				$table->timestamp('installed_at')->useCurrent();
				$table->timestamps();

				$table->index('server_id');
				$table->index(['server_id', 'name']);
			});

			Schema::table('minecraft_plugins', function (Blueprint $table) {
				$table->foreign('server_id')
					->references('id')
					->on('servers')
					->onDelete('cascade');
			});
		}
	}

    public function down()
    {
        Schema::table('minecraft_plugins', function (Blueprint $table) {
            $table->dropForeign(['server_id']);
        });
        
        Schema::dropIfExists('minecraft_plugins');
    }
}