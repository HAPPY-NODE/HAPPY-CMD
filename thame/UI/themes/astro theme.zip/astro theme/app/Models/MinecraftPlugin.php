<?php

namespace Pterodactyl\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class MinecraftPlugin extends Model
{
    protected $table = 'minecraft_plugins';

    protected $fillable = [
        'server_id',
        'name',
        'plugin_id',
        'version_id',
        'file_name',
        'version',
        'description',
        'download_url',
        'installed_at'
    ];

    protected $casts = [
        'installed_at' => 'datetime'
    ];

    /**
     * Get the server that owns the plugin
     */
    public function server(): BelongsTo
    {
        return $this->belongsTo(Server::class);
    }
}