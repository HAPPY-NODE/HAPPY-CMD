<?php

namespace Pterodactyl\Services\Modules;

use Illuminate\Support\Facades\File;
use Illuminate\Support\Collection;

class ModuleService
{
    protected $modulesPath;
    protected $modules = [];

    public function __construct()
    {
        $this->modulesPath = base_path('modules');
        $this->loadModules();
    }

    /**
     * Load all modules from the modules directory
     */
    public function loadModules(): void
    {
        $this->modules = [];

        if (!File::exists($this->modulesPath)) {
            File::makeDirectory($this->modulesPath, 0755, true);
            return;
        }

        $moduleFiles = File::glob($this->modulesPath . '/*.module');

        foreach ($moduleFiles as $file) {
            $moduleData = $this->parseModuleFile($file);
            if ($moduleData) {
                $this->modules[$moduleData['name']] = $moduleData;
            }
        }
    }

    /**
     * Parse a module file and extract its data
     */
    protected function parseModuleFile(string $filePath): ?array
    {
        try {
            $content = File::get($filePath);
            $data = json_decode($content, true);

            if (json_last_error() !== JSON_ERROR_NONE) {
                \Log::error('Invalid JSON in module file: ' . $filePath);
                return null;
            }

            // Validate required fields
            $required = ['name', 'description', 'version', 'icon'];
            foreach ($required as $field) {
                if (!isset($data[$field])) {
                    \Log::warning("Module file {$filePath} missing required field: {$field}");
                    return null;
                }
            }

            // Add filename and path
            $data['filename'] = File::name($filePath);
            $data['filepath'] = $filePath;

            return $data;

        } catch (\Exception $e) {
            \Log::error('Error reading module file: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Get all loaded modules
     */
    public function getModules(): Collection
    {
        return collect($this->modules);
    }

    /**
     * Get a specific module by name
     */
    public function getModule(string $name): ?array
    {
        return $this->modules[$name] ?? null;
    }

    /**
     * Check if a module exists
     */
    public function hasModule(string $name): bool
    {
        return isset($this->modules[$name]);
    }

    /**
     * Get modules count
     */
    public function getModulesCount(): int
    {
        return count($this->modules);
    }
}