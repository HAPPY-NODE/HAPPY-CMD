<?php

namespace Pterodactyl\Services\Minecraft;

use Pterodactyl\Models\Server;
use Pterodactyl\Repositories\Wings\DaemonFileRepository;
use Pterodactyl\Models\MinecraftPlugin;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class PluginService
{
    private $modrinthApiUrl = 'https://api.modrinth.com/v2';
    private $daemonFileRepository;

    public function __construct(DaemonFileRepository $daemonFileRepository)
    {
        $this->daemonFileRepository = $daemonFileRepository;
    }

    /**
     * Check if server supports plugins - REMOVED RESTRICTIONS
     */
    public function supportsPlugins(Server $server): bool
    {
        // Allow all server types to use plugins
        return true;
    }

    /**
     * Get loader from egg name
     */
    public function getLoaderFromEgg(string $eggName): string
    {
        $mapping = [
            'minecraft-paper' => 'paper',
            'minecraft-sponge' => 'sponge',
            'minecraft-purpur' => 'purpur',
            'minecraft-folia' => 'folia',
            'minecraft-magma' => 'magma',
            'minecraft-mohist' => 'mohist',
            'minecraft-catmc' => 'catmc',
            'minecraft-airplane' => 'airplane',
            'minecraft-tuinity' => 'tuinity'
        ];

        return $mapping[$eggName] ?? 'paper';
    }

    /**
     * Get server version from server model
     */
    public function getServerVersion(Server $server): ?string
    {
        // Try multiple possible locations for version data
        return $server->egg->version ??
               $server->version ??
               $this->extractVersionFromDockerImage($server->egg->docker_image ?? '');
    }

    private function extractVersionFromDockerImage(string $dockerImage): ?string
    {
        // Extract version from docker image name like "java:17" or "openjdk:8"
        if (preg_match('/:(\d+(?:\.\d+)?)/', $dockerImage, $matches)) {
            return $matches[1];
        }
        return null;
    }

    /**
     * Search plugins from Modrinth (UPDATED to support frontend filters + pagination)
     *
     * @param string $query         Search query string (empty = featured-style results)
     * @param string|null $serverVersion  Server game version to filter by (optional)
     * @param string $loader        Loader fallback (paper, sponge, etc.)
     * @param int $page             Page number (1-based)
     * @param int $perPage          Results per page (limit)
     * @param string $sort          Sort key: relevance|downloads|follows|newest|updated
     * @param string $category      Category/filter from frontend (e.g. 'paper', 'spigot')
     *
     * @return array
     */
    public function searchPlugins(
        string $query,
        ?string $serverVersion = null,
        string $loader = 'paper',
        int $page = 1,
        int $perPage = 24,
        string $sort = 'relevance',
        string $category = ''
    ): array {
        try {
            // Normalize paging values and cap limit to a reasonable maximum to avoid abusing the API.
            $perPage = max(1, min(100, (int)$perPage)); // cap at 100
            $page = max(1, (int)$page);
            $offset = ($page - 1) * $perPage;

            // Prepare facets: prefer project_type:plugin
            $categoryToUse = $category !== '' ? $category : $loader;

            $primaryFacets = [
                ['project_type:plugin'],
            ];

            // Add versions facet if provided
            if ($serverVersion) {
                $primaryFacets[] = ["versions:{$serverVersion}"];
            }

            // Add category/loader facet if provided
            if (!empty($categoryToUse)) {
                $primaryFacets[] = ["categories:{$categoryToUse}"];
            }

            $params = [
                'facets' => json_encode($primaryFacets),
                'limit' => $perPage,
                'offset' => $offset,
            ];

            // Omit 'query' when empty (Modrinth returns broader/featured-like results)
            if ($query !== '') {
                $params['query'] = $query;
            }

            // Only set sort when not relevance (relevance is default)
            if (!empty($sort) && $sort !== 'relevance') {
                $params['sort'] = $sort;
            }

            $response = Http::timeout(30)
                ->withHeaders([
                    'User-Agent' => 'PterodactylPanel/1.0',
                    'Accept' => 'application/json',
                ])
                ->get("{$this->modrinthApiUrl}/search", $params);

            if ($response->successful()) {
                $data = $response->json();

                // Standardize keys (Modrinth returns 'hits' and 'total_hits')
                $hits = $data['hits'] ?? [];
                $totalHits = $data['total_hits'] ?? ($data['total'] ?? 0);

                // If no query provided, sort by downloads for featured on the returned hits
                if (empty($query) && is_array($hits)) {
                    usort($hits, function ($a, $b) {
                        return ($b['downloads'] ?? 0) - ($a['downloads'] ?? 0);
                    });
                }

                // Build pagination metadata
                $totalPages = $perPage > 0 ? (int)ceil($totalHits / $perPage) : 0;
                $pagination = [
                    'page' => $page,
                    'per_page' => $perPage,
                    'total_pages' => $totalPages,
                    'total_hits' => $totalHits,
                    'offset' => $offset,
                ];

                return [
                    'success' => true,
                    'data' => [
                        'hits' => $hits,
                        // pass through other helpful fields Modrinth returns (if present)
                        'query' => $data['query'] ?? null,
                        'facets' => $data['facets'] ?? null,
                    ],
                    'pagination' => $pagination,
                ];
            }

            // If primary search failed (non-success HTTP code)
            Log::error('Modrinth search failed: ' . $response->body());

            return [
                'success' => false,
                'error' => 'Failed to fetch plugins from Modrinth: ' . $response->body()
            ];
        } catch (\Exception $e) {
            Log::error('Error searching plugins: ' . $e->getMessage());
            return [
                'success' => false,
                'error' => 'Failed to search plugins: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Get featured plugins
     *
     * Default to a larger page size for featured view so more items are fetched at once.
     *
     * @param string|null $serverVersion
     * @param string $loader
     * @param int $page
     * @param int $perPage
     * @return array
     */
    public function getFeaturedPlugins(?string $serverVersion = null, string $loader = 'paper', int $page = 1, int $perPage = 48): array
    {
        // Use 'relevance' (no sort param) so Modrinth returns broad results, then we prioritize by downloads client-side
        return $this->searchPlugins('', $serverVersion, $loader, $page, $perPage, 'relevance', '');
    }

    /**
     * Get plugin details
     */
    public function getPluginDetails(string $pluginId): array
    {
        try {
            \Log::info("Fetching plugin details for ID: {$pluginId}");

            $response = Http::timeout(30)
                ->withHeaders([
                    'User-Agent' => 'PterodactylPanel/1.0',
                    'Accept' => 'application/json',
                ])
                ->get("{$this->modrinthApiUrl}/project/{$pluginId}");

            \Log::info("Modrinth API response status: " . $response->status());

            if ($response->successful()) {
                $plugin = $response->json();
                \Log::info("Successfully fetched plugin: " . ($plugin['title'] ?? $pluginId));

                // Get versions
                $versionsResponse = Http::timeout(30)
                    ->withHeaders([
                        'User-Agent' => 'PterodactylPanel/1.0',
                        'Accept' => 'application/json',
                    ])
                    ->get("{$this->modrinthApiUrl}/project/{$pluginId}/version");

                $versions = $versionsResponse->successful() ? $versionsResponse->json() : [];
                \Log::info("Found " . count($versions) . " versions");

                // Find compatible version using existing helper
                $serverVersion = null; // caller should provide server version where needed in controllers; keep null here
                $compatibleVersion = $this->getCompatibleVersion($versions, $serverVersion, 'paper');

                return [
                    'success' => true,
                    'plugin' => $plugin,
                    'versions' => $versions,
                    'compatible_version' => $compatibleVersion
                ];
            }

            \Log::error("Failed to fetch plugin details: " . $response->body());
            return [
                'success' => false,
                'error' => 'Plugin not found on Modrinth',
                'status_code' => $response->status()
            ];
        } catch (\Exception $e) {
            \Log::error('Error fetching plugin details: ' . $e->getMessage());
            return [
                'success' => false,
                'error' => 'Failed to fetch plugin details: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Get compatible version for server - FIXED: Accepts null server version
     */
    public function getCompatibleVersion(array $versions, ?string $serverVersion, string $loader = 'paper'): ?array
    {
        $compatibleVersions = [];

        foreach ($versions as $version) {
            // If server version is provided, check compatibility
            if ($serverVersion !== null) {
                // Check if version supports the server version
                if (!in_array($serverVersion, $version['game_versions'] ?? [])) {
                    continue;
                }
            }

            // Check loader compatibility
            $loaders = $version['loaders'] ?? [];
            if (in_array($loader, $loaders) || empty($loaders)) {
                $compatibleVersions[] = $version;
            }
        }

        // If no compatible versions found with server version, try without version filter
        if (empty($compatibleVersions)) {
            foreach ($versions as $version) {
                $loaders = $version['loaders'] ?? [];
                if (in_array($loader, $loaders) || empty($loaders)) {
                    $compatibleVersions[] = $version;
                }
            }
        }

        // Sort by date (newest first)
        usort($compatibleVersions, function ($a, $b) {
            return strtotime($b['date_published']) - strtotime($a['date_published']);
        });

        return $compatibleVersions[0] ?? null;
    }

    /**
     * Download and install plugin using DaemonFileRepository - REMOVED SERVER TYPE CHECK
     */
    public function installPlugin(Server $server, string $versionId, string $pluginName): array
    {
        // REMOVED: Server type compatibility check - now allows all server types

        try {
            // Get version details
            $versionResponse = Http::timeout(30)->get("{$this->modrinthApiUrl}/version/{$versionId}");

            if (!$versionResponse->successful()) {
                return [
                    'success' => false,
                    'error' => 'Failed to fetch version details'
                ];
            }

            $version = $versionResponse->json();
            $downloadUrl = $version['files'][0]['url'] ?? null;

            if (!$downloadUrl) {
                return [
                    'success' => false,
                    'error' => 'No download URL found for this version'
                ];
            }

            // Sanitize filename
            $filename = $this->sanitizeFilename($pluginName) . '.jar';

            // Use DaemonFileRepository to download the plugin directly to the server
            $this->daemonFileRepository->setServer($server)->pull(
                $downloadUrl,
                '/plugins',
                [
                    'filename' => $filename,
                    'use_header' => true,
                    'foreground' => true,
                ]
            );

            // Record installation in database
            MinecraftPlugin::create([
                'server_id' => $server->id,
                'name' => $pluginName,
                'plugin_id' => $version['project_id'] ?? null,
                'version_id' => $versionId,
                'file_name' => $filename,
                'version' => $version['version_number'] ?? 'Unknown',
                'download_url' => $downloadUrl,
                'installed_at' => now()
            ]);

            return [
                'success' => true,
                'message' => 'Plugin installed successfully',
                'file_name' => $filename
            ];
        } catch (\Exception $e) {
            Log::error('Error installing plugin: ' . $e->getMessage());
            return [
                'success' => false,
                'error' => 'Installation failed: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Get installed plugins from database
     */
    public function getInstalledPlugins(Server $server): array
    {
        $plugins = MinecraftPlugin::where('server_id', $server->id)->get();

        $result = [];
        foreach ($plugins as $plugin) {
            $result[] = [
                'name' => $plugin->name,
                'file_name' => $plugin->file_name,
                'version' => $plugin->version,
                'installed_at' => $plugin->installed_at,
                'plugin_id' => $plugin->plugin_id,
                'installed_info' => [
                    'version_id' => $plugin->version_id,
                    'installed_at' => $plugin->installed_at->toISOString()
                ]
            ];
        }

        return $result;
    }

    /**
     * Search plugin by name to find its Modrinth page
     */
    public function findPluginOnline(string $pluginName): array
    {
        return $this->searchPlugins($pluginName, null, 'paper', 1);
    }

    /**
     * Uninstall plugin using DaemonFileRepository - REMOVED SERVER TYPE CHECK
     */
    public function uninstallPlugin(Server $server, string $pluginName): array
    {
        try {
            \Log::info("Attempting to uninstall plugin: {$pluginName} from server: {$server->id}");

            // Find the plugin in database
            $plugin = MinecraftPlugin::where('server_id', $server->id)
                ->where('name', $pluginName)
                ->first();

            if (!$plugin) {
                \Log::warning("Plugin not found in database: {$pluginName}");
                return [
                    'success' => false,
                    'error' => 'Plugin not found in database'
                ];
            }

            \Log::info("Found plugin in database, file name: {$plugin->file_name}");

            // Delete the file from server using DaemonFileRepository
            $filePath = 'plugins/' . $plugin->file_name; // Remove leading slash
            \Log::info("Deleting file from server: {$filePath}");

            // Use the correct method signature: deleteFiles(?string $root, array $files)
            $this->daemonFileRepository->setServer($server)->deleteFiles('/', [$filePath]);

            \Log::info("File deleted successfully, removing from database");

            // Remove from database
            $plugin->delete();

            \Log::info("Plugin uninstalled successfully: {$pluginName}");

            return [
                'success' => true,
                'message' => 'Plugin uninstalled successfully'
            ];

        } catch (\Exception $e) {
            \Log::error('Error uninstalling plugin: ' . $e->getMessage());
            return [
                'success' => false,
                'error' => 'Failed to uninstall plugin: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Sanitize filename
     */
    private function sanitizeFilename(string $filename): string
    {
        return preg_replace('/[^a-zA-Z0-9_-]/', '_', $filename);
    }
}
