<?php

namespace Pterodactyl\Services\Minecraft;

use Pterodactyl\Models\Server;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class ServerPingerService
{
    /**
     * Ping Minecraft server to get real-time information
     */
    public function pingServer(Server $server): array
    {
        try {
            // Get server allocation (IP and port)
            $allocation = $server->allocation;
            $node = $server->node;
            
            if (!$allocation || !$node) {
                throw new \Exception('Server allocation or node not found');
            }

            $ip = $allocation->ip;
            $port = $allocation->port;
            
            \Log::info("Pinging Minecraft server: {$ip}:{$port}");

            // Use Minecraft Server Status API (mcapi.us) or similar service
            $serverInfo = $this->pingWithMcApi($ip, $port);
            
            if ($serverInfo['online']) {
                return [
                    'online' => true,
                    'version' => $this->extractVersionFromResponse($serverInfo),
                    'software' => $this->detectServerSoftware($serverInfo),
                    'players' => $serverInfo['players']['now'] ?? 0,
                    'max_players' => $serverInfo['players']['max'] ?? 0,
                    'motd' => $this->extractMotd($serverInfo),
                    'raw_response' => $serverInfo
                ];
            } else {
                throw new \Exception('Server is offline or not responding');
            }

        } catch (\Exception $e) {
            \Log::warning('Server ping failed: ' . $e->getMessage());
            
            // Fallback to server model data
            return [
                'online' => false,
                'version' => $server->egg->version ?? $server->version ?? 'Unknown',
                'software' => $this->getSoftwareFromEgg($server->egg->name ?? 'Unknown'),
                'players' => 0,
                'max_players' => 0,
                'motd' => 'Server offline',
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Ping server using mcapi.us service - FIXED RESPONSE HANDLING
     */
    private function pingWithMcApi(string $ip, int $port): array
    {
        $response = Http::timeout(10)->get("https://mcapi.us/server/status", [
            'ip' => $ip,
            'port' => $port
        ]);

        if ($response->successful()) {
            $data = $response->json();
            
            // Log the full response for debugging
            \Log::info("MCAPI Response: " . json_encode($data));
            
            return $data;
        }

        throw new \Exception('MCAPI request failed: ' . $response->status());
    }

    /**
     * Extract version from response - FIXED VERSION EXTRACTION
     */
    private function extractVersionFromResponse(array $serverInfo): string
    {
        // MCAPI returns version in different possible locations
        $version = $serverInfo['server']['name'] ?? 
                  $serverInfo['version'] ?? 
                  $serverInfo['server']['version'] ?? 
                  'Unknown';
        
        return $this->extractVersionFromString($version);
    }

    /**
     * Extract clean version from version string
     */
    private function extractVersionFromString(string $versionString): string
    {
        // Extract version like "1.20.1" from strings like "Paper 1.20.1" or "git-Paper-100 (MC: 1.20.1)"
        if (preg_match('/(\d+\.\d+(?:\.\d+)?)/', $versionString, $matches)) {
            return $matches[1];
        }
        
        return $versionString;
    }

    /**
     * Extract MOTD from response - FIXED MOTD EXTRACTION
     */
    private function extractMotd(array $serverInfo): string
    {
        // MCAPI returns MOTD in different formats
        $motd = $serverInfo['motd'] ?? 
               $serverInfo['description'] ?? 
               $serverInfo['server']['description'] ?? 
               '';
        
        // If MOTD is an array (like from description), extract text
        if (is_array($motd)) {
            return $motd['text'] ?? implode(' ', $motd);
        }
        
        return $motd;
    }

    /**
     * Detect server software from ping response - IMPROVED DETECTION
     */
    private function detectServerSoftware(array $serverInfo): string
    {
        $version = $serverInfo['server']['name'] ?? $serverInfo['version'] ?? '';
        $motd = $this->extractMotd($serverInfo);
        $rawResponse = json_encode($serverInfo);

        $combined = $version . ' ' . $motd . ' ' . $rawResponse;

        // Detect common server software
        $detectionPatterns = [
            'Paper' => ['Paper', 'git-Paper'],
            'Spigot' => ['Spigot', 'git-Spigot'],
            'Bukkit' => ['Bukkit', 'git-Bukkit'],
            'Forge' => ['Forge', 'fml', 'FML'],
            'Fabric' => ['Fabric'],
            'Vanilla' => ['Vanilla', 'Minecraft Server'],
            'Sponge' => ['Sponge'],
            'Purpur' => ['Purpur'],
            'Magma' => ['Magma'],
            'Mohist' => ['Mohist'],
            'CatServer' => ['CatServer'],
            'Airplane' => ['Airplane'],
            'Tuinity' => ['Tuinity'],
            'Folía' => ['Folía'],
            'BungeeCord' => ['BungeeCord'],
            'Waterfall' => ['Waterfall'],
            'Velocity' => ['Velocity']
        ];

        foreach ($detectionPatterns as $software => $patterns) {
            foreach ($patterns as $pattern) {
                if (stripos($combined, $pattern) !== false) {
                    return $software;
                }
            }
        }

        return 'Unknown';
    }

    /**
     * Get software name from egg name as fallback
     */
    private function getSoftwareFromEgg(string $eggName): string
    {
        $mapping = [
            'minecraft-paper' => 'Paper',
            'minecraft-sponge' => 'Sponge', 
            'minecraft-purpur' => 'Purpur',
            'minecraft-folia' => 'Folía',
            'minecraft-magma' => 'Magma',
            'minecraft-mohist' => 'Mohist',
            'minecraft-catmc' => 'CatServer',
            'minecraft-airplane' => 'Airplane',
            'minecraft-tuinity' => 'Tuinity',
            'minecraft-spigot' => 'Spigot',
            'minecraft-bukkit' => 'Bukkit',
            'minecraft-forge' => 'Forge',
            'minecraft-fabric' => 'Fabric',
            'minecraft-vanilla' => 'Vanilla',
            'minecraft-bungeecord' => 'BungeeCord',
            'minecraft-waterfall' => 'Waterfall',
            'minecraft-velocity' => 'Velocity'
        ];

        return $mapping[$eggName] ?? 'Unknown';
    }

    /**
     * Alternative: Use direct Minecraft server ping with a proper library
     */
    private function pingWithMinecraftPing(string $ip, int $port): array
    {
        try {
            // You can install a proper Minecraft ping library via composer
            // For example: composer require xpaw/php-minecraft-query
            // This is a simplified fallback
            
            $socket = @fsockopen($ip, $port, $errno, $errstr, 5);
            
            if (!$socket) {
                throw new \Exception("Direct connection failed: $errstr");
            }

            // Set non-blocking and timeout
            stream_set_blocking($socket, false);
            stream_set_timeout($socket, 5);

            // Send handshake packet (simplified)
            $packet = pack('c', 0xFE) . pack('c', 0x01);
            fwrite($socket, $packet);
            
            // Read response
            $response = fread($socket, 2048);
            fclose($socket);

            if ($response) {
                // Parse the response (simplified)
                $data = explode("\x00", $response);
                return [
                    'online' => true,
                    'version' => $data[2] ?? 'Unknown',
                    'motd' => $data[3] ?? '',
                    'players' => intval($data[4] ?? 0),
                    'max_players' => intval($data[5] ?? 0)
                ];
            }

            throw new \Exception('No response from server');

        } catch (\Exception $e) {
            throw new \Exception('Direct ping failed: ' . $e->getMessage());
        }
    }
}