<?php

namespace Pterodactyl\Providers;

use Pterodactyl\Services\Modules\ModuleService;
use Illuminate\Support\ServiceProvider;

class ModuleServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     */
    public function register(): void
    {
        $this->app->singleton(ModuleService::class, function ($app) {
            return new ModuleService();
        });
    }

    /**
     * Bootstrap services.
     */
    public function boot(): void
    {
        // Publish configuration if needed
        $this->publishes([
            __DIR__.'/../../config/modules.php' => config_path('modules.php'),
        ], 'modules-config');
    }
}