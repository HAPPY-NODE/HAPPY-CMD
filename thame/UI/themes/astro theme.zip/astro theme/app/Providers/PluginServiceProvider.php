<?php

namespace Pterodactyl\Providers;

use Pterodactyl\Services\Minecraft\PluginService;
use Pterodactyl\Services\Minecraft\ServerPingerService;
use Pterodactyl\Repositories\Wings\DaemonFileRepository;
use Illuminate\Support\ServiceProvider;

class PluginServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        // Register the PluginService with DaemonFileRepository dependency
        $this->app->bind(PluginService::class, function ($app) {
            return new PluginService($app->make(DaemonFileRepository::class));
        });

        // Register the ServerPingerService
        $this->app->singleton(ServerPingerService::class, function ($app) {
            return new ServerPingerService();
        });
    }

    public function boot(): void
    {
        //
    }
}