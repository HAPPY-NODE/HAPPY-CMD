<?php

namespace Pterodactyl\Http\Controllers\Api\Client;

use Pterodactyl\Models\Server;
use Illuminate\Http\JsonResponse;

class ServerNestController extends ClientApiController
{
    /**
     * Return the nest ID and egg ID for a given server.
     */
    public function index(Server $server): JsonResponse
    {
        $this->authorize('view', $server);

        $egg = $server->egg;

        return response()->json([
            'object' => 'server_nest_info',
            'attributes' => [
                'nest_id' => $egg->nest_id ?? null,
                'egg_id' => $egg->id ?? null,
            ]
        ]);
    }
}
