<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Pterodactyl\Models\User;
use Pterodactyl\Models\Node;
use Illuminate\Routing\Controller;

class AnnouncementsController extends Controller
{
    /**
     * Display announcements management page
     */
    public function index()
    {
        \Log::info('AnnouncementsController: index method called');
        
        $announcements = DB::table('announcements')
            ->orderBy('display_order')
            ->orderBy('created_at', 'desc')
            ->get();

        \Log::info('Found announcements count: ' . $announcements->count());

        $nodes = Node::all(['id', 'name']);
        $users = User::all(['id', 'username', 'email']);

        $themeSettings = DB::table('theme')->where('key', 'theme.background_image')->first();
        $announcementsEnabled = $themeSettings->announcements_enabled ?? true;

        return view('admin.announcements', [
            'announcements' => $announcements,
            'nodes' => $nodes,
            'users' => $users,
            'announcements_enabled' => $announcementsEnabled,
        ]);
    }

	/**
	 * Create or update an announcement
	 */
	public function store(Request $request)
	{
		\Log::info('=== ANNOUNCEMENT STORE METHOD CALLED ===');
		\Log::info('Request data:', $request->all());

		$request->validate([
			'title' => 'required|string|max:255',
			'content' => 'required|string',
			'type' => 'required|in:info,warning,success,error,primary',
			'is_active' => 'boolean',
			'is_dismissible' => 'boolean',
			'starts_at' => 'nullable|date',
			'ends_at' => 'nullable|date|after:starts_at',
			'target_scope' => 'required|in:all,nodes,users',
			'target_nodes' => 'nullable|array',
			'target_users' => 'nullable|array',
			'display_order' => 'integer|min:0',
		]);

		\Log::info('Validation passed');

		try {
			$data = [
				'title' => $request->title,
				'content' => $request->content,
				'type' => $request->type,
				'is_active' => $request->boolean('is_active', true),
				'is_dismissible' => $request->boolean('is_dismissible', true),
				'starts_at' => $request->starts_at,
				'ends_at' => $request->ends_at,
				'target_scope' => $request->target_scope,
				'target_nodes' => $request->target_scope === 'nodes' ? json_encode($request->target_nodes) : null,
				'target_users' => $request->target_scope === 'users' ? json_encode($request->target_users) : null,
				'display_order' => $request->display_order ?? 0,
				'created_by' => $request->user()->id,
				'updated_at' => now(),
			];

			\Log::info('Prepared data for database:', $data);

			// FIX: Check if ID exists AND has a value (not null or empty)
			if ($request->filled('id')) {
				\Log::info('Updating existing announcement with ID: ' . $request->id);
				DB::table('announcements')->where('id', $request->id)->update($data);
				$message = 'Announcement updated successfully.';
			} else {
				\Log::info('Creating new announcement');
				$data['created_at'] = now();
				$newId = DB::table('announcements')->insertGetId($data);
				\Log::info('New announcement created with ID: ' . $newId);
				$message = 'Announcement created successfully.';
			}

			\Log::info('Database operation completed successfully');

			// Return JSON response for AJAX requests
			return response()->json([
				'success' => true,
				'message' => $message,
				'data' => $data
			]);

		} catch (\Exception $e) {
			\Log::error('Error saving announcement: ' . $e->getMessage());
			\Log::error('Stack trace: ' . $e->getTraceAsString());

			return response()->json([
				'success' => false,
				'message' => 'Failed to save announcement: ' . $e->getMessage()
			], 500);
		}
	}
	
    /**
     * Delete an announcement
     */
    public function destroy($id)
    {
        \Log::info('Deleting announcement with ID: ' . $id);
        
        try {
            DB::table('announcements')->where('id', $id)->delete();
            \Log::info('Announcement deleted successfully');
            
            return redirect()->route('admin.announcements')->with('success', 'Announcement deleted successfully.');
        } catch (\Exception $e) {
            \Log::error('Error deleting announcement: ' . $e->getMessage());
            return redirect()->route('admin.announcements')->with('error', 'Failed to delete announcement.');
        }
    }

    /**
     * Toggle announcements system
     */
    public function toggleSystem(Request $request)
    {
        \Log::info('Toggle announcements system called', $request->all());

        $request->validate([
            'announcements_enabled' => 'required|boolean',
        ]);

        try {
            DB::table('theme')->updateOrInsert(
                ['key' => 'theme.background_image'],
                [
                    'announcements_enabled' => $request->announcements_enabled,
                    'updated_at' => now(),
                ]
            );

            \Log::info('Announcements system toggled to: ' . ($request->announcements_enabled ? 'enabled' : 'disabled'));

            return response()->json(['success' => true]);
        } catch (\Exception $e) {
            \Log::error('Error toggling announcements system: ' . $e->getMessage());
            return response()->json(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }

    /**
     * Get announcement data for editing
     */
    public function edit($id)
    {
        \Log::info('Editing announcement with ID: ' . $id);
        
        $announcement = DB::table('announcements')->where('id', $id)->first();
        
        if (!$announcement) {
            \Log::warning('Announcement not found with ID: ' . $id);
            return response()->json(['error' => 'Announcement not found'], 404);
        }

        \Log::info('Found announcement for editing:', (array)$announcement);
        return response()->json($announcement);
    }

	/**
	 * API: Get active announcements for current user
	 */
	public function getActive(Request $request)
	{
		\Log::info('getActive announcements called for user: ' . ($request->user() ? $request->user()->id : 'unknown'));

		$user = $request->user();
		
		if (!$user) {
			\Log::info('No authenticated user, returning empty announcements');
			return response()->json([]);
		}

		$now = now();

		\Log::info('Current time: ' . $now);

		$announcements = DB::table('announcements')
			->where('is_active', true)
			->where(function ($query) use ($now) {
				$query->whereNull('starts_at')->orWhere('starts_at', '<=', $now);
			})
			->where(function ($query) use ($now) {
				$query->whereNull('ends_at')->orWhere('ends_at', '>=', $now);
			})
			->orderBy('display_order')
			->orderBy('created_at', 'desc')
			->get();

		\Log::info('Found ' . $announcements->count() . ' active announcements');

		$filteredAnnouncements = $announcements->filter(function ($announcement) use ($user) {
			if ($announcement->target_scope === 'all') {
				\Log::info('Announcement ' . $announcement->id . ' is for all users');
				return true;
			}

			if ($announcement->target_scope === 'nodes') {
				$targetNodes = json_decode($announcement->target_nodes, true) ?? [];
				\Log::info('Checking nodes for announcement ' . $announcement->id . ', target nodes: ' . json_encode($targetNodes));
				
				// FIXED: Use the correct column name for user ID in servers table
				// In Pterodactyl, the servers table uses 'owner_id' for the user
				try {
					$userNodeIds = DB::table('servers')
						->where('owner_id', $user->id) // Changed from 'user_id' to 'owner_id'
						->pluck('node_id')
						->toArray();
					
					\Log::info('User node IDs: ' . json_encode($userNodeIds));
					
					$hasMatchingNode = count(array_intersect($targetNodes, $userNodeIds)) > 0;
					\Log::info('User has matching node: ' . ($hasMatchingNode ? 'yes' : 'no'));
					
					return $hasMatchingNode;
				} catch (\Exception $e) {
					\Log::error('Error checking user nodes: ' . $e->getMessage());
					// If there's an error, show the announcement to be safe
					return true;
				}
			}

			if ($announcement->target_scope === 'users') {
				$targetUsers = json_decode($announcement->target_users, true) ?? [];
				\Log::info('Checking users for announcement ' . $announcement->id . ', target users: ' . json_encode($targetUsers));
				
				$isTargeted = in_array($user->id, $targetUsers);
				\Log::info('User is targeted: ' . ($isTargeted ? 'yes' : 'no'));
				
				return $isTargeted;
			}

			return false;
		});

		\Log::info('After filtering: ' . $filteredAnnouncements->count() . ' announcements for user');

		return response()->json($filteredAnnouncements);
	}
}