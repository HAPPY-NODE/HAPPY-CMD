<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\Modules\ModuleService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class ModulesController extends Controller
{
    protected $moduleService;

    public function __construct(ModuleService $moduleService)
    {
        $this->moduleService = $moduleService;
    }

    /**
     * Display all modules in admin theme editor
     */
    public function index(): View
    {
        $modules = $this->moduleService->getModules()->sortBy('name');

        return view('admin.modules.index', [
            'modules' => $modules
        ]);
    }

    /**
     * Get modules data via AJAX
     */
    public function getModules(): JsonResponse
    {
        $modules = $this->moduleService->getModules();

        return response()->json([
            'success' => true,
            'modules' => $modules->values(),
            'count' => $modules->count()
        ]);
    }

    /**
     * Get specific module data
     */
    public function getModule(string $name): JsonResponse
    {
        $module = $this->moduleService->getModule($name);

        if (!$module) {
            return response()->json([
                'success' => false,
                'message' => 'Module not found'
            ], 404);
        }

        return response()->json([
            'success' => true,
            'module' => $module
        ]);
    }

    /**
     * Refresh modules list
     */
    public function refresh(): JsonResponse
    {
        $this->moduleService->loadModules();

        return response()->json([
            'success' => true,
            'message' => 'Modules refreshed successfully',
            'count' => $this->moduleService->getModulesCount()
        ]);
    }
}