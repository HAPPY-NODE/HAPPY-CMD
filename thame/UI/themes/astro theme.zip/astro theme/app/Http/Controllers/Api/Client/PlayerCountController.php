<?php

namespace Pterodactyl\Http\Controllers\Api\Client;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Cache;
use Illuminate\Http\JsonResponse;
use Pterodactyl\Models\Server;
use Pterodactyl\Http\Controllers\Controller;

class PlayerCountController extends Controller
{
    public function index(Request $request, Server $server): JsonResponse
    {
        $allocation = $server->allocation;
        if (!$allocation) {
            return response()->json(['players' => [
                'online' => 0,
                'max' => 0,
                'list' => []
            ]]);
        }

        $endpoint = ($allocation->ip_alias ?? $allocation->ip) . ':' . $allocation->port;
        $cacheKey = "server:players:{$endpoint}";

        $result = Cache::remember($cacheKey, 30, function () use ($endpoint) {
            // Try all supported APIs regardless of game type
            $apis = [
                'minecraft' => [
                    'mcstatus' => "https://api.mcstatus.io/v2/status/java/{$endpoint}",
                    'mcsrvstat' => "https://api.mcsrvstat.us/2/{$endpoint}",
                ],
                'rust' => [
                    'rustlegacy_players' => "https://api.rustlegacy.eu/?getdata=serverinfo&players={$endpoint}",
                    'rustlegacy_maxplayers' => "https://api.rustlegacy.eu/?getdata=serverinfo&maxplayers={$endpoint}",
                ]
            ];

            foreach ($apis as $game => $gameApis) {
                try {
                    if ($game === 'minecraft') {
                        // Try mcstatus.io
                        $response = Http::timeout(3)->get($gameApis['mcstatus']);
                        if ($response->successful()) {
                            $data = $response->json();
                            return [
                                'online' => (int) ($data['players']['online'] ?? 0),
                                'max' => (int) ($data['players']['max'] ?? 0),
                                'list' => $data['players']['list'] ?? []
                            ];
                        }

                        // Try mcsrvstat.us
                        $response = Http::timeout(3)->get($gameApis['mcsrvstat']);
                        if ($response->successful()) {
                            $data = $response->json();
                            return [
                                'online' => (int) ($data['players']['online'] ?? 0),
                                'max' => (int) ($data['players']['max'] ?? 0),
                                'list' => $data['players']['list'] ?? []
                            ];
                        }
                    } elseif ($game === 'rust') {
                        // Try RustLegacy API
                        $players = (int) Http::timeout(3)->get($gameApis['rustlegacy_players'])->body();
                        $maxplayers = (int) Http::timeout(3)->get($gameApis['rustlegacy_maxplayers'])->body();
                        
                        if ($players >= 0 && $maxplayers > 0) {
                            return [
                                'online' => $players,
                                'max' => $maxplayers,
                                'list' => []
                            ];
                        }
                    }
                } catch (\Exception $e) {
                    // Continue to next API if this one fails
                    continue;
                }
            }

            // Fallback to empty response if all APIs fail
            return [
                'online' => 0,
                'max' => 0,
                'list' => []
            ];
        });

        return response()->json(['players' => $result]);
    }
}