<?php

namespace Pterodactyl\Http\Controllers\Api\Client\Servers;

use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Models\Server;
use Pterodactyl\Services\Minecraft\PluginService;
use Pterodactyl\Services\Minecraft\ServerPingerService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class PluginController extends Controller
{
    protected PluginService $pluginService;
    protected ServerPingerService $serverPingerService;

    public function __construct(PluginService $pluginService, ServerPingerService $serverPingerService)
    {
        $this->pluginService = $pluginService;
        $this->serverPingerService = $serverPingerService;
    }

    /**
     * Display plugins page
     */
    public function index(Server $server): View
    {
        $installedPlugins = $this->pluginService->getInstalledPlugins($server);

        return view('api.client.servers.plugins', [
            'server' => $server,
            'installedPlugins' => $installedPlugins
        ]);
    }

    /**
     * Search plugins
     */
    public function search(Request $request, Server $server): JsonResponse
    {
        try {
            $query = $request->get('q', '');
            $page = $request->get('page', 1);
            
            // Use the server pinger to get real server version
            $serverInfo = $this->serverPingerService->pingServer($server);
            $serverVersion = $serverInfo['version'] ?? $this->pluginService->getServerVersion($server);
            
            // Get loader from server type
            $loader = $this->pluginService->getLoaderFromEgg($server->egg->name ?? '');

            $result = $this->pluginService->searchPlugins($query, $serverVersion, $loader, $page);

            return response()->json($result);
        } catch (\Exception $e) {
            \Log::error('Search plugins error: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'error' => 'Search failed: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get plugin details
     */
    public function show(Server $server, string $pluginId): JsonResponse
    {
        try {
            $result = $this->pluginService->getPluginDetails($pluginId);

            if ($result['success']) {
                // Determine loader from server egg name
                $loader = $this->pluginService->getLoaderFromEgg($server->egg->name ?? '');
                
                // Use the server pinger to get real server version
                $serverInfo = $this->serverPingerService->pingServer($server);
                $serverVersion = $serverInfo['version'] ?? $this->pluginService->getServerVersion($server);
                
                // Find compatible version
                $compatibleVersion = $this->pluginService->getCompatibleVersion(
                    $result['versions'] ?? [],
                    $serverVersion,
                    $loader
                );

                $result['compatible_version'] = $compatibleVersion;
            }

            return response()->json($result);
        } catch (\Exception $e) {
            \Log::error('Show plugin error: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'error' => 'Failed to get plugin details'
            ], 500);
        }
    }

    /**
     * Install plugin
     */
    public function install(Request $request, Server $server): JsonResponse
    {
        try {
            $request->validate([
                'version_id' => 'required|string',
                'plugin_name' => 'required|string'
            ]);

            $result = $this->pluginService->installPlugin(
                $server,
                $request->version_id,
                $request->plugin_name
            );

            return response()->json($result);
        } catch (\Exception $e) {
            \Log::error('Install plugin error: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'error' => 'Installation failed: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Uninstall plugin
     */
    public function uninstall(Server $server, string $pluginName): JsonResponse
    {
        try {
            $result = $this->pluginService->uninstallPlugin($server, $pluginName);
            return response()->json($result);
        } catch (\Exception $e) {
            \Log::error('Uninstall plugin error: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'error' => 'Uninstall failed: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Find plugin online
     */
    public function findOnline(Request $request, Server $server): JsonResponse
    {
        try {
            $pluginName = $request->get('name', '');

            if (empty($pluginName)) {
                return response()->json([
                    'success' => false,
                    'error' => 'Plugin name is required'
                ]);
            }

            $result = $this->pluginService->findPluginOnline($pluginName);
            return response()->json($result);
        } catch (\Exception $e) {
            \Log::error('Find online plugin error: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'error' => 'Search failed'
            ], 500);
        }
    }

    /**
     * Get installed plugins
     */
    public function installed(Server $server): JsonResponse
    {
        try {
            $plugins = $this->pluginService->getInstalledPlugins($server);

            return response()->json([
                'success' => true,
                'plugins' => $plugins
            ]);
        } catch (\Exception $e) {
            \Log::error('Get installed plugins error: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'error' => 'Failed to load installed plugins',
                'plugins' => []
            ], 500);
        }
    }

    /**
     * Get featured plugins
     */
    public function featured(Server $server): JsonResponse
    {
        try {
            // Use the server pinger to get real server version
            $serverInfo = $this->serverPingerService->pingServer($server);
            $serverVersion = $serverInfo['version'] ?? $this->pluginService->getServerVersion($server);
            $loader = $this->pluginService->getLoaderFromEgg($server->egg->name ?? '');
            
            $result = $this->pluginService->getFeaturedPlugins($serverVersion, $loader);

            return response()->json($result);
        } catch (\Exception $e) {
            \Log::error('Featured plugins error: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'error' => 'Failed to load featured plugins'
            ], 500);
        }
    }

    /**
     * Get server information via ping
     */
    public function serverInfo(Server $server): JsonResponse
    {
        try {
            $serverInfo = $this->serverPingerService->pingServer($server);
            
            return response()->json([
                'success' => true,
                'server_info' => $serverInfo
            ]);
        } catch (\Exception $e) {
            \Log::error('Server info error: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'error' => 'Failed to fetch server information: ' . $e->getMessage()
            ], 500);
        }
    }
}