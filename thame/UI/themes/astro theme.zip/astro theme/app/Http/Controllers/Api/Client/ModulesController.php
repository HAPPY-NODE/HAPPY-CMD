<?php

namespace Pterodactyl\Http\Controllers\Api\Client;

use Pterodactyl\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\File;

class ModulesController extends Controller
{
    /**
     * Check if a specific module is available
     */
    public function checkModule(string $module): JsonResponse
    {
        $moduleFile = base_path("modules/{$module}.module");
        
        $available = File::exists($moduleFile);
        
        return response()->json([
            'available' => $available,
            'module' => $module
        ]);
    }
}