<?php

namespace Pterodactyl\Http\Controllers\Api\Client;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Http\JsonResponse;
use Pterodactyl\Models\Server;
use Pterodactyl\Http\Controllers\Controller;

class ServerMetaController extends Controller
{
    /**
     * Return normalized server metadata useful for the frontend header.
     *
     * Example response:
     * {
     *   "eggName": "Paper",
     *   "nodeName": "node-1",
     *   "location": "Falken (eu-west)",
     *   "version": "1.19.3",
     *   "eggFeatures": { ... } | null
     * }
     */
    public function index(Request $request, Server $server): JsonResponse
    {
        // cache short-term to avoid DB churn on repeated client requests
        $cacheKey = 'server:meta:' . $server->uuid;

        $payload = Cache::remember($cacheKey, 30, function () use ($server) {
            // Eager load the relationships we care about to avoid N+1 problems.
            // node.location is loaded so we can read the location info from the node's relation.
            $server->loadMissing(['egg', 'node.location']);

            $egg = $server->egg;
            $node = $server->node;
            $nodeLocation = $node && $node->relationLoaded('location') ? $node->location : null;

            // Some panels/storage variants use different attribute names for version.
            $version = $server->version ?? $server->installed_version ?? $server->getAttribute('version') ?? null;

            // Egg features may be stored under features, feature_limits, egg_features, etc.
            $eggFeatures = null;
            if ($egg) {
                if (isset($egg->features) && is_array($egg->features)) {
                    $eggFeatures = $egg->features;
                } elseif (isset($egg->feature_limits) && is_array($egg->feature_limits)) {
                    $eggFeatures = $egg->feature_limits;
                } elseif (isset($egg->egg_features) && is_array($egg->egg_features)) {
                    $eggFeatures = $egg->egg_features;
                } elseif (isset($egg->attributes) && is_array($egg->attributes) && (isset($egg->attributes['features']) || isset($egg->attributes['feature_limits']))) {
                    $eggFeatures = $egg->attributes['features'] ?? $egg->attributes['feature_limits'] ?? null;
                }
            }

            return [
                'eggName'    => $egg->name ?? null,
                'nodeName'   => $node->name ?? null,
                'location'   => $nodeLocation->short ?? $nodeLocation->long ?? $nodeLocation->description ?? null,
                'version'    => $version,
                'eggFeatures'=> $eggFeatures,
            ];
        });

        return response()->json($payload);
    }
}
