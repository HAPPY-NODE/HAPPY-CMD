<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Routing\Controller;
use Pterodactyl\Models\User;
use Pterodactyl\Models\Node;

class ThemeController extends Controller
{
    /**
     * Show the theme blade page.
     */
    public function index()
    {
        $row = DB::table('theme')->where('key', 'theme.background_image')->first();

        // fallback values
        $background = $row->value ?? null;
        $smallLogo = $row->small_logo ?? null;
        $largeLogo = $row->large_logo ?? null;
        $quickLinksEnabled = isset($row->quick_links_enabled) ? (bool)$row->quick_links_enabled : true;
        $quickLinks = $row->quick_links ? json_decode($row->quick_links, true) : [];
        
        // NEW: Nest backgrounds and gradient opacity
        $nestBackgrounds = $row->nest_backgrounds ? json_decode($row->nest_backgrounds, true) : [];
        $nestGradientOpacity = $row->nest_gradient_opacity ?? 0.15;

        // NEW: Navigation links
        $navigationLinks = $row->navigation_links ? json_decode($row->navigation_links, true) : [];

        // NEW: Announcements enabled
        $announcementsEnabled = isset($row->announcements_enabled) ? (bool)$row->announcements_enabled : true;

        // Get available nests for the form
        $nests = DB::table('nests')->get(['id', 'name']);

        // NEW: Get announcements for the announcements tab
        $announcements = DB::table('announcements')
            ->orderBy('display_order')
            ->orderBy('created_at', 'desc')
            ->get();

        // NEW: Get nodes and users for announcements targeting
        $nodes = Node::all(['id', 'name']);
        $users = User::all(['id', 'username', 'email']);

        return view('admin.theme', [
            'background' => $background,
            'presets' => $this->presets(),
            'small_logo' => $smallLogo,
            'large_logo' => $largeLogo,
            'quick_links_enabled' => $quickLinksEnabled,
            'quick_links' => $quickLinks,
            'nest_backgrounds' => $nestBackgrounds,
            'nest_gradient_opacity' => $nestGradientOpacity,
            'navigation_links' => $navigationLinks,
            'announcements_enabled' => $announcementsEnabled,
            'announcements' => $announcements, // Add this line
            'nodes' => $nodes, // Add this line
            'users' => $users, // Add this line
            'nests' => $nests,
        ]);
    }

    /**
     * Update settings (background, logos, quick links, nest backgrounds, navigation links).
     */
    public function update(Request $request)
    {
        \Log::info('Theme update request received', $request->all());
        
        $request->validate([
            'background_file' => 'nullable|file|image|max:5120',
            'background_url'  => 'nullable|url|max:2048',
            'small_logo_file' => 'nullable|file|image|max:2048',
            'small_logo_url'  => 'nullable|url|max:2048',
            'large_logo_file' => 'nullable|file|image|max:4096',
            'large_logo_url'  => 'nullable|url|max:2048',
            'use_default'     => 'nullable|boolean',
            'quick_links_enabled' => 'nullable|boolean',
            'quick_links'     => 'nullable',
            'active_tab'      => 'nullable|string',
            // NEW: Nest background validation
            'nest_backgrounds' => 'nullable|array',
            'nest_backgrounds.*' => 'nullable|url',
            'nest_gradient_opacity' => 'nullable|numeric|min:0|max:1',
            'nest_background_file' => 'nullable|array',
            'nest_background_file.*' => 'nullable|file|image|max:5120',
            // NEW: Navigation links validation
            'navigation_links' => 'nullable',
            // NEW: Announcements enabled
            'announcements_enabled' => 'nullable|boolean',
        ]);

        // Prepare updates array
        $updates = [
            'updated_at' => now(),
        ];

        \Log::info('Quick links data received:', [
            'quick_links' => $request->input('quick_links'),
            'quick_links_enabled' => $request->input('quick_links_enabled')
        ]);

        // Handle reset to default
        if ($request->boolean('use_default')) {
            $updates = array_merge($updates, [
                'value' => null,
                'background_image' => null,
                'background_source' => 'default',
            ]);

            DB::table('theme')->updateOrInsert(['key' => 'theme.background_image'], $updates);
            
            $activeTab = $request->input('active_tab', 'background');
            return redirect()->route('admin.theme', ['tab' => $activeTab])->with('success', 'Background reset to default.');
        }

        // === BACKGROUND ===
        if ($request->hasFile('background_file')) {
            $file = $request->file('background_file');
            $filename = 'background_' . time() . '_' . Str::random(8) . '.' . $file->getClientOriginalExtension();
            $path = $file->storeAs('panel_theme_backgrounds', $filename, 'public');
            $backgroundUrl = Storage::disk('public')->url($path);
            $updates['value'] = $backgroundUrl;
            $updates['background_image'] = $backgroundUrl;
            $updates['background_source'] = 'upload';
        } elseif ($request->filled('background_url')) {
            $backgroundUrl = $request->input('background_url');
            if (!$this->isValidImageUrl($backgroundUrl)) {
                $activeTab = $request->input('active_tab', 'background');
                return redirect()->route('admin.theme', ['tab' => $activeTab])->with('warning', 'Provided background URL is not a valid image.');
            }
            $updates['value'] = $backgroundUrl;
            $updates['background_image'] = $backgroundUrl;
            $updates['background_source'] = 'external';
        }

        // === SMALL LOGO ===
        if ($request->hasFile('small_logo_file')) {
            $file = $request->file('small_logo_file');
            $filename = 'logo_small_' . time() . '_' . Str::random(6) . '.' . $file->getClientOriginalExtension();
            $path = $file->storeAs('panel_logos', $filename, 'public');
            $smallUrl = Storage::disk('public')->url($path);
            $updates['small_logo'] = $smallUrl;
        } elseif ($request->filled('small_logo_url')) {
            $smallUrl = $request->input('small_logo_url');
            if (!$this->isValidImageUrl($smallUrl)) {
                $activeTab = $request->input('active_tab', 'background');
                return redirect()->route('admin.theme', ['tab' => $activeTab])->with('warning', 'Provided small logo URL is not a valid image.');
            }
            $updates['small_logo'] = $smallUrl;
        }

        // === LARGE LOGO ===
        if ($request->hasFile('large_logo_file')) {
            $file = $request->file('large_logo_file');
            $filename = 'logo_large_' . time() . '_' . Str::random(6) . '.' . $file->getClientOriginalExtension();
            $path = $file->storeAs('panel_logos', $filename, 'public');
            $largeUrl = Storage::disk('public')->url($path);
            $updates['large_logo'] = $largeUrl;
        } elseif ($request->filled('large_logo_url')) {
            $largeUrl = $request->input('large_logo_url');
            if (!$this->isValidImageUrl($largeUrl)) {
                $activeTab = $request->input('active_tab', 'background');
                return redirect()->route('admin.theme', ['tab' => $activeTab])->with('warning', 'Provided large logo URL is not a valid image.');
            }
            $updates['large_logo'] = $largeUrl;
        }

        // === QUICK LINKS ===
        $updates['quick_links_enabled'] = $request->boolean('quick_links_enabled', false);

        if ($request->filled('quick_links')) {
            $raw = $request->input('quick_links');
            $decoded = is_string($raw) ? json_decode($raw, true) : $raw;

            if (!is_array($decoded)) {
                $activeTab = $request->input('active_tab', 'background');
                return redirect()->route('admin.theme', ['tab' => $activeTab])->with('warning', 'Quick links must be a JSON array.');
            }

            $validatedLinks = [];
            foreach ($decoded as $item) {
                if (!is_array($item)) continue;
                
                $title = trim($item['title'] ?? '');
                $url = trim($item['url'] ?? '');
                $icon = trim($item['icon'] ?? '');
                $target = trim($item['target'] ?? '_self');
                $rel = trim($item['rel'] ?? '');

                if ($title === '' || $url === '') continue;
                if (!filter_var($url, FILTER_VALIDATE_URL)) continue;

                $validatedLinks[] = [
                    'title' => $title,
                    'url' => $url,
                    'icon' => $icon ?: 'link',
                    'target' => $target ?: '_self',
                    'rel' => $rel ?: 'noopener noreferrer',
                ];
            }

            $updates['quick_links'] = json_encode($validatedLinks);
        }

        // === NEST BACKGROUNDS ===
        if ($request->filled('nest_backgrounds')) {
            $nestBackgrounds = $request->input('nest_backgrounds');
            $validatedNestBackgrounds = [];
            
            foreach ($nestBackgrounds as $nestId => $backgroundUrl) {
                if (!empty($backgroundUrl)) {
                    if (!$this->isValidImageUrl($backgroundUrl)) {
                        $activeTab = $request->input('active_tab', 'background');
                        return redirect()->route('admin.theme', ['tab' => $activeTab])->with('warning', "Invalid image URL for nest {$nestId}.");
                    }
                    $validatedNestBackgrounds[$nestId] = $backgroundUrl;
                }
            }
            
            $updates['nest_backgrounds'] = json_encode($validatedNestBackgrounds);
        }

        // Handle nest background file uploads
        if ($request->hasFile('nest_background_file')) {
            $nestBackgrounds = $updates['nest_backgrounds'] ? json_decode($updates['nest_backgrounds'], true) : [];
            
            foreach ($request->file('nest_background_file') as $nestId => $file) {
                if ($file) {
                    $filename = 'nest_' . $nestId . '_' . time() . '_' . Str::random(8) . '.' . $file->getClientOriginalExtension();
                    $path = $file->storeAs('panel_nest_backgrounds', $filename, 'public');
                    $backgroundUrl = Storage::disk('public')->url($path);
                    $nestBackgrounds[$nestId] = $backgroundUrl;
                }
            }
            
            $updates['nest_backgrounds'] = json_encode($nestBackgrounds);
        }

        // === NEST GRADIENT OPACITY ===
        if ($request->filled('nest_gradient_opacity')) {
            $updates['nest_gradient_opacity'] = floatval($request->input('nest_gradient_opacity'));
        }

        // === NAVIGATION LINKS ===
        if ($request->filled('navigation_links')) {
            $raw = $request->input('navigation_links');
            $decoded = is_string($raw) ? json_decode($raw, true) : $raw;

            if (!is_array($decoded)) {
                $activeTab = $request->input('active_tab', 'background');
                return redirect()->route('admin.theme', ['tab' => $activeTab])->with('warning', 'Navigation links must be a JSON array.');
            }

            $validatedLinks = [];
            foreach ($decoded as $item) {
                if (!is_array($item)) continue;
                
                $id = trim($item['id'] ?? '');
                $type = trim($item['type'] ?? 'link');
                $name = trim($item['name'] ?? '');
                $icon = trim($item['icon'] ?? '');
                $link = trim($item['link'] ?? '');
                $target = trim($item['target'] ?? '_self');
                $enabled = (bool)($item['enabled'] ?? true);
                $order = (int)($item['order'] ?? 0);
                $category = trim($item['category'] ?? 'main');
                $requiresRoot = (bool)($item['requires_root'] ?? false);

                if ($id === '' || $name === '') continue;

                $validatedLinks[] = [
                    'id' => $id,
                    'type' => $type,
                    'name' => $name,
                    'icon' => $icon,
                    'link' => $link,
                    'target' => $target,
                    'enabled' => $enabled,
                    'order' => $order,
                    'category' => $category,
                    'requires_root' => $requiresRoot,
                ];
            }

            $updates['navigation_links'] = json_encode($validatedLinks);
        }

        // === ANNOUNCEMENTS ENABLED ===
        if ($request->has('announcements_enabled')) {
            $updates['announcements_enabled'] = $request->boolean('announcements_enabled');
        }

        // Only update if we have actual changes (not just updated_at)
        if (count($updates) > 1) {
            DB::table('theme')->updateOrInsert(
                ['key' => 'theme.background_image'],
                $updates
            );

            $activeTab = $request->input('active_tab', 'background');
            return redirect()->route('admin.theme', ['tab' => $activeTab])->with('success', 'Theme settings updated.');
        }

        $activeTab = $request->input('active_tab', 'background');
        return redirect()->route('admin.theme', ['tab' => $activeTab])->with('warning', 'No changes detected.');
    }

    /**
     * API endpoint that returns JSON for the current theme settings.
     */
    public function getSettings()
    {
        $row = DB::table('theme')->where('key', 'theme.background_image')->first();

        $background = $row->value ?? null;
        $smallLogo = $row->small_logo ?? null;
        $largeLogo = $row->large_logo ?? null;
        $quickLinksEnabled = isset($row->quick_links_enabled) ? (bool)$row->quick_links_enabled : true;
        $quickLinks = $row->quick_links ? json_decode($row->quick_links, true) : [];
        
        // NEW: Include nest backgrounds and gradient opacity in API response
        $nestBackgrounds = $row->nest_backgrounds ? json_decode($row->nest_backgrounds, true) : [];
        $nestGradientOpacity = $row->nest_gradient_opacity ?? 0.15;

        // NEW: Include navigation links in API response
        $navigationLinks = $row->navigation_links ? json_decode($row->navigation_links, true) : [];

        // NEW: Include announcements enabled in API response
        $announcementsEnabled = isset($row->announcements_enabled) ? (bool)$row->announcements_enabled : true;

        return response()->json([
            'background' => $background,
            'small_logo' => $smallLogo,
            'large_logo' => $largeLogo,
            'quick_links_enabled' => $quickLinksEnabled,
            'quick_links' => $quickLinks,
            'source' => $row->background_source ?? 'default',
            'nest_backgrounds' => $nestBackgrounds,
            'nest_gradient_opacity' => $nestGradientOpacity,
            'navigation_links' => $navigationLinks,
            'announcements_enabled' => $announcementsEnabled,
        ]);
    }

    /**
     * API endpoint for React component (public access)
     */
    public function theme()
    {
        $row = DB::table('theme')->where('key', 'theme.background_image')->first();

        $background = $row->value ?? null;
        $smallLogo = $row->small_logo ?? null;
        $largeLogo = $row->large_logo ?? null;
        $quickLinksEnabled = isset($row->quick_links_enabled) ? (bool)$row->quick_links_enabled : true;
        $quickLinks = $row->quick_links ? json_decode($row->quick_links, true) : [];
        
        // NEW: Include nest backgrounds and gradient opacity
        $nestBackgrounds = $row->nest_backgrounds ? json_decode($row->nest_backgrounds, true) : [];
        $nestGradientOpacity = $row->nest_gradient_opacity ?? 0.15;

        // NEW: Include navigation links
        $navigationLinks = $row->navigation_links ? json_decode($row->navigation_links, true) : [];

        // NEW: Include announcements enabled
        $announcementsEnabled = isset($row->announcements_enabled) ? (bool)$row->announcements_enabled : true;

        return response()->json([
            'background' => $background,
            'small_logo' => $smallLogo,
            'large_logo' => $largeLogo,
            'quick_links_enabled' => $quickLinksEnabled,
            'quick_links' => $quickLinks,
            'nest_backgrounds' => $nestBackgrounds,
            'nest_gradient_opacity' => $nestGradientOpacity,
            'navigation_links' => $navigationLinks,
            'announcements_enabled' => $announcementsEnabled,
        ]);
    }

    /**
     * Basic image URL validation.
     */
    private function isValidImageUrl($url)
    {
        if (!filter_var($url, FILTER_VALIDATE_URL)) return false;

        $headers = @get_headers($url, 1);
        if (!$headers) return false;

        $contentType = $headers['Content-Type'] ?? '';
        if (is_array($contentType)) {
            $contentType = end($contentType);
        }

        return Str::contains($contentType, ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml']);
    }

    /**
     * Provide a small set of preset backgrounds.
     */
    private function presets()
    {
        return [
            ['name' => 'Space', 'image' => 'https://images.unsplash.com/photo-1446776877081-d282a0f896e2?auto=format&fit=crop&w=2000&q=80'],
            ['name' => 'Mountains', 'image' => 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?auto=format&fit=crop&w=2000&q=80'],
            ['name' => 'Ocean', 'image' => 'https://images.unsplash.com/photo-1505142468610-359e7d316be0?auto=format&fit=crop&w=2000&q=80'],
            ['name' => 'Forest', 'image' => 'https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=2000&q=80'],
            ['name' => 'Abstract', 'image' => 'https://images.unsplash.com/photo-1550684376-efcbd6e3f031?auto=format&fit=crop&w=2000&q=80'],
            ['name' => 'Gradient', 'image' => 'https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?auto=format&fit=crop&w=2000&q=80']
        ];
    }

    /**
     * Toggle announcements system
     */
    public function toggleAnnouncements(Request $request)
    {
        $request->validate([
            'announcements_enabled' => 'required|boolean',
        ]);

        DB::table('theme')->updateOrInsert(
            ['key' => 'theme.background_image'],
            [
                'announcements_enabled' => $request->announcements_enabled,
                'updated_at' => now(),
            ]
        );

        return response()->json(['success' => true]);
    }
}