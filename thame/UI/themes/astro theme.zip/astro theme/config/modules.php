<?php

return [
    'path' => base_path('modules'),
    'auto_discover' => true,
    'cache' => [
        'enabled' => true,
        'duration' => 3600, // 1 hour
    ],
    'required_fields' => [
        'name',
        'description', 
        'version',
        'icon'
    ]
];