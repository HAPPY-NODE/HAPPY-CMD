const colors = require('tailwindcss/colors');

// Blue-themed gray scale
const blueGray = {
    50: 'hsl(210, 50%, 98%)',
    100: 'hsl(210, 40%, 96%)',
    200: 'hsl(210, 38%, 90%)',
    300: 'hsl(210, 36%, 80%)',
    400: 'hsl(210, 34%, 65%)',
    500: 'hsl(210, 32%, 50%)',
    600: 'hsl(210, 30%, 40%)',
    700: 'hsl(210, 28%, 30%)',
    800: 'hsl(210, 26%, 22%)',
    900: 'hsl(210, 24%, 16%)',
};

module.exports = {
    content: [
        './resources/scripts/**/*.{js,ts,tsx}',
        './resources/views/**/*.blade.php',
    ],
    theme: {
        extend: {
            fontFamily: {
                header: ['"IBM Plex Sans"', '"Roboto"', 'system-ui', 'sans-serif'],
            },
            colors: {
                black: '#131a20',
                primary: colors.blue,
                gray: blueGray, // Replaced with blue-themed gray
                neutral: blueGray, // Also updated to maintain consistency
                cyan: colors.cyan,
                darkblue: '#111321',
                // Extended blue palette for additional options
                blue: {
                    50: 'hsl(210, 50%, 98%)',
                    100: 'hsl(210, 40%, 96%)',
                    200: 'hsl(210, 38%, 90%)',
                    300: 'hsl(210, 36%, 80%)',
                    400: 'hsl(210, 34%, 65%)',
                    500: 'hsl(210, 32%, 50%)',
                    600: 'hsl(210, 30%, 40%)',
                    700: 'hsl(210, 28%, 30%)',
                    800: 'hsl(210, 26%, 22%)',
                    900: 'hsl(210, 24%, 16%)',
                }
            },
            fontSize: {
                '2xs': '0.625rem',
            },
            transitionDuration: {
                250: '250ms',
            },
            borderColor: theme => ({
                default: theme('colors.gray.400', 'currentColor'),
            }),
        },
    },
    plugins: [
        require('@tailwindcss/line-clamp'),
        require('@tailwindcss/forms')({
            strategy: 'class',
        }),
    ]
};