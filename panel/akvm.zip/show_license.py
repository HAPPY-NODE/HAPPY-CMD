#!/usr/bin/env python3
"""HAPPY NODE AKVM — show the Install ID and matching License Key for a given install dir.

Usage:
    python show_license.py [/path/to/akvm]

If no directory is given, defaults to the directory this script lives in.
"""
import os
import sys
import sqlite3
import hmac
import hashlib

LICENSE_SECRET = "akvm-9f3c7a1e-59b2-4d8a-b6ce-2f0a7e4c1d6b-do-not-share"


def main():
    inst = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(__file__))
    db = os.path.join(inst, "akvm.db")
    if not os.path.exists(db):
        print(f"ERROR: database not found at {db}", file=sys.stderr)
        sys.exit(1)

    con = sqlite3.connect(db)
    iid = None
    for row in con.execute("SELECT value FROM settings WHERE key='license_install_id'"):
        iid = row[0]

    if not iid:
        iid = os.urandom(6).hex()
        con.execute(
            "INSERT OR REPLACE INTO settings (key,value,updated_at) "
            "VALUES ('license_install_id',?,CURRENT_TIMESTAMP)",
            (iid,),
        )
        con.commit()

    digest = hmac.new(LICENSE_SECRET.encode("utf-8"), iid.encode("utf-8"), hashlib.sha256).hexdigest().upper()
    groups = [digest[i:i + 5] for i in range(0, 20, 5)]
    key = "AKVM-%s-%s-%s-%s" % tuple(groups)

    print("Install ID :", iid)
    print("License Key:", key)
    print("Enter this key on the License page to activate.")


if __name__ == "__main__":
    main()
