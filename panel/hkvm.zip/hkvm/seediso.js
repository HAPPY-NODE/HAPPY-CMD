'use strict';
// seediso.js — pure-Node NoCloud seed ISO writer (ISO9660 + Joliet, volid "cidata")
// Zero dependencies. Fallback jab VPS pe genisoimage/mkisofs/xorriso/cloud-localds na ho.
// Offsets mirror pycdlib/ECMA-119 (validated against pycdlib reference ISO).
// cloud-init NoCloud: blkid LABEL=cidata + Joliet file names (user-data, meta-data, network-config)

const fs = require('fs');
const path = require('path');

const SECTOR = 2048;

function both16(n) {
    const b = Buffer.alloc(4);
    b.writeUInt16LE(n & 0xffff, 0);
    b.writeUInt16BE(n & 0xffff, 2);
    return b;
}

function both32(n) {
    const b = Buffer.alloc(8);
    b.writeUInt32LE(n >>> 0, 0);
    b.writeUInt32BE(n >>> 0, 4);
    return b;
}

function ucs2be(str) {
    const b = Buffer.alloc(str.length * 2);
    for (let i = 0; i < str.length; i++) b.writeUInt16BE(str.charCodeAt(i), i * 2);
    return b;
}

function ucs2Spaces(len) {
    const b = Buffer.alloc(len);
    for (let i = 0; i + 1 < len; i += 2) { b[i] = 0x00; b[i + 1] = 0x20; }
    return b;
}

function fillUcs2Spaces(buf, start, end) {
    for (let i = start; i + 1 < end; i += 2) { buf[i] = 0x00; buf[i + 1] = 0x20; }
}

function vdDate(d) {
    // 17-byte ASCII: YYYYMMDDHHMMSScc + GMT offset byte (0 = UTC)
    const p = (n) => String(n).padStart(2, '0');
    const s = `${d.getUTCFullYear()}${p(d.getUTCMonth() + 1)}${p(d.getUTCDate())}` +
        `${p(d.getUTCHours())}${p(d.getUTCMinutes())}${p(d.getUTCSeconds())}00`;
    const b = Buffer.alloc(17, 0);
    b.write(s, 0, 'ascii');
    b[16] = 0x00;
    return b;
}

function vdDateUnset() {
    const b = Buffer.alloc(17, 0x30);
    b[16] = 0x00;
    return b;
}

function dirDate(d) {
    // 7-byte binary: YY MM DD HH MM SS TZ (YY = year - 1900)
    const b = Buffer.alloc(7, 0);
    b[0] = d.getUTCFullYear() - 1900;
    b[1] = d.getUTCMonth() + 1;
    b[2] = d.getUTCDate();
    b[3] = d.getUTCHours();
    b[4] = d.getUTCMinutes();
    b[5] = d.getUTCSeconds();
    b[6] = 0x00; // UTC
    return b;
}

function dirRecord(extent, size, flags, nameBuf, dt) {
    const nameLen = nameBuf.length;
    const pad = (nameLen % 2 === 0) ? 1 : 0;
    const total = 33 + nameLen + pad;
    const b = Buffer.alloc(total);
    b[0] = total;
    b[1] = 0;                        // extended attr record length
    both32(extent).copy(b, 2);
    both32(size).copy(b, 10);
    dt.copy(b, 18);                  // 7-byte recording date
    b[25] = flags;
    b[26] = 0;                       // unit size
    b[27] = 0;                       // interleave gap
    both16(1).copy(b, 28);           // volume sequence number
    b[32] = nameLen;
    nameBuf.copy(b, 33);
    return b;
}

function pathEntry(extent, nameLenBytes, big) {
    const b = Buffer.alloc(8 + nameLenBytes + (nameLenBytes % 2 ? 1 : 0));
    b[0] = nameLenBytes;
    b[1] = 0;
    if (big) { b.writeUInt32BE(extent >>> 0, 2); b.writeUInt16BE(1, 6); }
    else { b.writeUInt32LE(extent >>> 0, 2); b.writeUInt16LE(1, 6); }
    return b; // root identifier = 0x00 / 0x0000 already zero-filled
}

function padTo(buf, size) {
    if (buf.length === size) return buf;
    if (buf.length > size) throw new Error(`sector overflow (${buf.length} > ${size})`);
    const b = Buffer.alloc(size, 0);
    buf.copy(b);
    return b;
}

function fillDescriptorCommon(b, type, totalSectors, ptSize, lptLba, mptLba, rootLba, dt, isJoliet) {
    b[0] = type;
    b.write('CD001', 1, 'ascii');
    b[6] = 1;                        // version
    b[7] = 0;                        // flags
    if (isJoliet) {
        fillUcs2Spaces(b, 8, 40);    // system identifier (UCS-2 spaces)
        ucs2be('cidata').copy(b, 40);
        fillUcs2Spaces(b, 52, 72);   // vol id pad (UCS-2 spaces)
        b[88] = 0x25; b[89] = 0x2F; b[90] = 0x40; // escape: '%/@' = UCS-2 Level 1
    } else {
        b.fill(0x20, 8, 40);         // system identifier
        b.write('cidata', 40, 'ascii');
        b.fill(0x20, 46, 72);        // vol id pad
        // 88-119 escape_sequences = zeros for PVD
    }
    both32(totalSectors).copy(b, 80); // volume space size
    both16(1).copy(b, 120);           // volume set size
    both16(1).copy(b, 124);           // volume sequence number
    both16(SECTOR).copy(b, 128);      // logical block size
    b.writeUInt32LE(ptSize, 132);     // path table size (LE)
    b.writeUInt32BE(ptSize, 136);     // path table size (BE)
    b.writeUInt32LE(lptLba, 140);     // L path table location (LE)
    b.writeUInt32LE(0, 144);          // optional L (0)
    b.writeUInt32BE(mptLba, 148);     // M path table location (BE)
    b.writeUInt32BE(0, 152);          // optional M (0)
    dirRecord(rootLba, SECTOR, 2, Buffer.from([0x00]), dirDate(dt)).copy(b, 156);
    if (isJoliet) {
        fillUcs2Spaces(b, 190, 813);  // vol set / publisher / preparer / app / file ids (UCS-2)
    } else {
        b.fill(0x20, 190, 813);       // same fields, ASCII spaces
    }
    vdDate(dt).copy(b, 813);          // creation
    vdDate(dt).copy(b, 830);          // modification
    vdDateUnset().copy(b, 847);       // expiration (unset)
    vdDate(dt).copy(b, 864);          // effective
    b[881] = 1;                       // file structure version
    b[882] = 0;
}

function buildSeedIso(seedDir, outFile) {
    const wanted = ['meta-data', 'network-config', 'user-data'];
    const files = [];
    for (const n of wanted) {
        const p = path.join(seedDir, n);
        if (fs.existsSync(p)) files.push({ name: n, data: fs.readFileSync(p) });
    }
    if (!files.some(f => f.name === 'user-data')) throw new Error('seed user-data nahi mila');
    if (!files.some(f => f.name === 'meta-data')) throw new Error('seed meta-data nahi mila');

    const LBA = { pvd: 16, svd: 17, term: 18, lpt: 19, mpt: 20, jlpt: 21, jmpt: 22, isoroot: 23, jolroot: 24 };
    const now = new Date();

    let next = 25;
    for (const f of files) {
        f.extent = next;
        next += Math.max(1, Math.ceil(f.data.length / SECTOR));
    }
    const totalSectors = next;
    const dt = dirDate(now);

    // ---- root directories ----
    const isoChild = files
        .map(f => {
            const id = `${f.name.toUpperCase()}.;1`;
            return { id, buf: dirRecord(f.extent, f.data.length, 0, Buffer.from(id, 'ascii'), dt) };
        })
        .sort((a, b) => Buffer.compare(Buffer.from(a.id, 'ascii'), Buffer.from(b.id, 'ascii')));
    const isoRootData = Buffer.concat([
        dirRecord(LBA.isoroot, SECTOR, 2, Buffer.from([0x00]), dt),
        dirRecord(LBA.isoroot, SECTOR, 2, Buffer.from([0x01]), dt),
        ...isoChild.map(c => c.buf),
    ]);

    const jolChild = files
        .map(f => ({ id: f.name, buf: dirRecord(f.extent, f.data.length, 0, ucs2be(f.name), dt) }))
        .sort((a, b) => Buffer.compare(Buffer.from(a.id, 'ascii'), Buffer.from(b.id, 'ascii')));
    const jolRootData = Buffer.concat([
        dirRecord(LBA.jolroot, SECTOR, 2, Buffer.from([0x00]), dt),
        dirRecord(LBA.jolroot, SECTOR, 2, Buffer.from([0x01]), dt),
        ...jolChild.map(c => c.buf),
    ]);
    if (isoRootData.length > SECTOR || jolRootData.length > SECTOR) throw new Error('seed dir ek sector me fit nahi');

    const ptSize = 10; // single root entry: 8 + name + pad = 10

    // ---- descriptors ----
    const pvd = Buffer.alloc(SECTOR, 0);
    fillDescriptorCommon(pvd, 1, totalSectors, ptSize, LBA.lpt, LBA.mpt, LBA.isoroot, now, false);

    const svd = Buffer.alloc(SECTOR, 0);
    fillDescriptorCommon(svd, 2, totalSectors, ptSize, LBA.jlpt, LBA.jmpt, LBA.jolroot, now, true);

    const term = Buffer.alloc(SECTOR, 0);
    term[0] = 0xFF;
    term.write('CD001', 1, 'ascii');
    term[6] = 1;

    // ---- path tables ----
    const lpt = padTo(pathEntry(LBA.isoroot, 1, false), SECTOR);
    const mpt = padTo(pathEntry(LBA.isoroot, 1, true), SECTOR);
    const jlpt = padTo(pathEntry(LBA.jolroot, 2, false), SECTOR);
    const jmpt = padTo(pathEntry(LBA.jolroot, 2, true), SECTOR);

    // ---- assemble ----
    const img = Buffer.alloc(totalSectors * SECTOR, 0);
    pvd.copy(img, LBA.pvd * SECTOR);
    svd.copy(img, LBA.svd * SECTOR);
    term.copy(img, LBA.term * SECTOR);
    lpt.copy(img, LBA.lpt * SECTOR);
    mpt.copy(img, LBA.mpt * SECTOR);
    jlpt.copy(img, LBA.jlpt * SECTOR);
    jmpt.copy(img, LBA.jmpt * SECTOR);
    padTo(isoRootData, SECTOR).copy(img, LBA.isoroot * SECTOR);
    padTo(jolRootData, SECTOR).copy(img, LBA.jolroot * SECTOR);
    for (const f of files) f.data.copy(img, f.extent * SECTOR);

    fs.writeFileSync(outFile, img);
    return { size: img.length, sectors: totalSectors, files: files.map(f => f.name) };
}

module.exports = { buildSeedIso };

if (require.main === module) {
    const [sd, out] = process.argv.slice(2);
    console.log(JSON.stringify(buildSeedIso(sd, out)));
}
